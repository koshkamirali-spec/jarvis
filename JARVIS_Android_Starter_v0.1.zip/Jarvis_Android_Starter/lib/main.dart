import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

void main() => runApp(const JarvisApp());

class JarvisApp extends StatelessWidget {
  const JarvisApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'J.A.R.V.I.S',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF050A12),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF00BFFF),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const JarvisHome(),
    );
  }
}

class JarvisHome extends StatefulWidget {
  const JarvisHome({super.key});

  @override
  State<JarvisHome> createState() => _JarvisHomeState();
}

class _JarvisHomeState extends State<JarvisHome> {
  final stt.SpeechToText _speech = stt.SpeechToText();
  final FlutterTts _tts = FlutterTts();
  bool _available = false;
  bool _listening = false;
  String _heard = 'برای شروع، دکمه میکروفون را بزنید.';
  String _status = 'آماده به کار';

  @override
  void initState() {
    super.initState();
    _initVoice();
  }

  Future<void> _initVoice() async {
    _available = await _speech.initialize(
      onStatus: (status) {
        if (!mounted) return;
        setState(() {
          _listening = status == 'listening';
          _status = _listening ? 'در حال شنیدن' : 'آماده به کار';
        });
      },
      onError: (error) {
        if (!mounted) return;
        setState(() => _status = 'خطا در تشخیص صدا');
      },
    );
    await _tts.setLanguage('fa-IR');
    await _tts.setSpeechRate(0.46);
    if (mounted) setState(() {});
  }

  Future<void> _speak(String text) async {
    await _tts.stop();
    await _tts.speak(text);
  }

  Future<void> _listen() async {
    if (!_available) {
      await _speak('تشخیص گفتار در این دستگاه در دسترس نیست.');
      return;
    }
    if (_listening) {
      await _speech.stop();
      return;
    }
    setState(() => _status = 'در حال شنیدن');
    await _speech.listen(
      localeId: 'fa_IR',
      listenFor: const Duration(seconds: 12),
      pauseFor: const Duration(seconds: 3),
      onResult: (result) {
        if (!mounted) return;
        setState(() => _heard = result.recognizedWords);
        if (result.finalResult) _handleCommand(result.recognizedWords);
      },
    );
  }

  Future<void> _handleCommand(String command) async {
    final text = command.toLowerCase();
    String response;
    if (text.contains('سلام')) {
      response = 'سلام. من جارویس هستم. چطور می‌توانم کمک کنم؟';
    } else if (text.contains('ساعت')) {
      final now = TimeOfDay.now();
      response = 'ساعت ${now.format(context)} است.';
    } else if (text.contains('خطر')) {
      response = 'حالت آزمایشی اضطراری شناسایی شد. این نسخه هنوز با پلیس یا مخاطبین تماس نمی‌گیرد. برای کمک فوری از شماره اضطراری محل خود استفاده کنید.';
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('حالت آزمایشی: هیچ تماس یا پیامی ارسال نشد.')),
        );
      }
    } else {
      response = 'متوجه شدم: $command. این فرمان هنوز به جارویس اضافه نشده است.';
    }
    await _speak(response);
    if (mounted) setState(() => _status = 'آماده به کار');
  }

  @override
  void dispose() {
    _speech.stop();
    _tts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('J.A.R.V.I.S', style: TextStyle(letterSpacing: 3, fontWeight: FontWeight.bold)),
        centerTitle: true,
        backgroundColor: const Color(0xFF071525),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(
            children: [
              const Spacer(),
              Container(
                width: 210,
                height: 210,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const RadialGradient(
                    colors: [Color(0xFF123B5A), Color(0xFF071525), Color(0xFF050A12)],
                  ),
                  border: Border.all(color: const Color(0xFF00BFFF), width: 2),
                  boxShadow: [
                    BoxShadow(color: const Color(0xFF00BFFF).withOpacity(0.25), blurRadius: 35, spreadRadius: 5),
                  ],
                ),
                child: Icon(
                  _listening ? Icons.graphic_eq : Icons.memory,
                  size: 82,
                  color: const Color(0xFF55D7FF),
                ),
              ),
              const SizedBox(height: 28),
              Text(_status, style: const TextStyle(color: Color(0xFF55D7FF), fontSize: 18)),
              const SizedBox(height: 14),
              Text(_heard, textAlign: TextAlign.center, style: const TextStyle(fontSize: 16)),
              const Spacer(),
              FilledButton.icon(
                onPressed: _listen,
                icon: Icon(_listening ? Icons.stop : Icons.mic),
                label: Text(_listening ? 'توقف' : 'صحبت با جارویس'),
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF0077A8),
                  foregroundColor: Colors.white,
                  minimumSize: const Size(double.infinity, 58),
                ),
              ),
              const SizedBox(height: 12),
              const Text(
                'نسخه آزمایشی ۰.۱ • برای استفاده از میکروفون باید مجوز بدهید.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white54, fontSize: 11),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
