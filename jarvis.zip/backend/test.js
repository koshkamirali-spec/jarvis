// Minimal self-test (no network needed): checks auth, routing and rate limiting.
process.env.DATA_DIR = require('os').tmpdir(); process.env.GEMINI_API_KEY = 'x'; process.env.APP_TOKEN = 't,u';
const { server } = require('./server'); const http = require('http'); const assert = require('assert');
function call(path, headers = {}, method = 'POST') { return new Promise(r => { const q = http.request({ port: server.address().port, path, method, headers }, res => { res.resume(); r(res.statusCode); }); q.end('{}'); }); }
server.listen(0, async () => {
  assert.strictEqual(await call('/health', {}, 'GET'), 200);
  assert.strictEqual(await call('/nope'), 404);
  assert.strictEqual(await call('/gemini'), 401);
  assert.strictEqual(await call('/gemini?model=bad%20model', { 'x-app-token': 't' }), 400);
  const put = (m, body) => new Promise(r => { const q = http.request({ port: server.address().port, path: '/sync', method: m, headers: { 'x-app-token': 't' } }, res => { const c = []; res.on('data', d => c.push(d)); res.on('end', () => r([res.statusCode, Buffer.concat(c).toString()])); }); q.end(body); });
  assert.strictEqual((await put('PUT', 'blob123'))[0], 200); assert.deepStrictEqual(await put('GET'), [200, 'blob123']);
  assert.strictEqual(await call('/sync', {}, 'GET'), 401);
  assert.strictEqual(await call('/sync', { 'x-app-token': 'u' }, 'GET'), 404); // second account has its own (empty) backup
  console.log('backend tests passed'); server.close();
});
