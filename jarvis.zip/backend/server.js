// J.A.R.V.I.S backend: keeps your Gemini API key on the server. Zero dependencies (Node >= 18).
// POST /gemini?model=gemini-2.5-flash  with the standard Gemini generateContent JSON body.
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const KEY = process.env.GEMINI_API_KEY, TOKENS = (process.env.APP_TOKEN || '').split(',').map(x => x.trim()).filter(Boolean), PORT = process.env.PORT || 8080;
const MODEL_RE = /^[a-z0-9.\-]+$/i, hits = new Map(), LIMIT = Number(process.env.RATE_PER_MIN || 30), MAX_BODY = 25 * 1024 * 1024;

function limited(ip) { const now = Date.now(), a = (hits.get(ip) || []).filter(t => now - t < 60000); a.push(now); hits.set(ip, a); return a.length > LIMIT; }
function send(res, code, obj) { res.writeHead(code, { 'content-type': 'application/json' }); res.end(JSON.stringify(obj)); }

const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://x');
  if (req.method === 'GET' && url.pathname === '/health') return send(res, 200, { ok: true });
  if (url.pathname === '/sync') { // encrypted backup blob (the server never sees the passphrase)
    if (!TOKENS.includes(req.headers['x-app-token'])) return send(res, 401, { error: 'unauthorized' });
    const f = path.join(process.env.DATA_DIR || __dirname, 'sync_' + crypto.createHash('sha256').update(req.headers['x-app-token']).digest('hex').slice(0, 16) + '.bin');
    if (req.method === 'GET') { if (!fs.existsSync(f)) return send(res, 404, { error: 'no backup' }); res.writeHead(200, { 'content-type': 'application/octet-stream' }); return res.end(fs.readFileSync(f)); }
    if (req.method === 'PUT') { const ch = []; let n = 0; req.on('data', c => { n += c.length; if (n > 5 * 1024 * 1024) req.destroy(); else ch.push(c); }); req.on('end', () => { fs.writeFileSync(f, Buffer.concat(ch)); send(res, 200, { ok: true }); }); return; }
    return send(res, 405, { error: 'method' }); }
  if (req.method !== 'POST' || url.pathname !== '/gemini') return send(res, 404, { error: 'not found' });
  if (!KEY || !TOKENS.length) return send(res, 500, { error: 'server not configured (GEMINI_API_KEY, APP_TOKEN)' });
  if (!TOKENS.includes(req.headers['x-app-token'])) return send(res, 401, { error: 'unauthorized' });
  if (limited(req.socket.remoteAddress)) return send(res, 429, { error: 'rate limit' });
  const model = url.searchParams.get('model') || 'gemini-2.5-flash';
  if (!MODEL_RE.test(model)) return send(res, 400, { error: 'bad model' });
  const chunks = []; let size = 0;
  req.on('data', c => { size += c.length; if (size > MAX_BODY) { req.destroy(); } else chunks.push(c); });
  req.on('end', async () => {
    try {
      const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, { method: 'POST', headers: { 'content-type': 'application/json', 'x-goog-api-key': KEY }, body: Buffer.concat(chunks) });
      res.writeHead(r.status, { 'content-type': 'application/json' }); res.end(await r.text());
    } catch (e) { send(res, 502, { error: 'upstream failure' }); }
  });
});
if (require.main === module) server.listen(PORT, () => console.log('JARVIS backend on :' + PORT));
module.exports = { server, limited };
