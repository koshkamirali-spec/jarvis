# Test report (honest)
| Area | Status |
|---|---|
| Backend `node test.js` (health, 404, auth 401, bad model 400, encrypted backup upload/download, two accounts isolated) | ✅ run, passed |
| Android pure logic unit tests (`LogicTest`: calculator, Persian digits, units, step splitting, reminder parsing, language, AI-plan trigger, mode rules/time ranges) | written, run by the GitHub workflow — NOT run by me |
| Kotlin compile / APK build | NOT run (no SDK in my sandbox) |
| Swift compile / IPA build | NOT run |
| On-device tests (voice, camera, safety, notifications, recorder…) | NOT run |
## Manual checklist after first install
Voice: tap Speak → "open camera"; start background listening → "Hey Jarvis, what time is it"; Stop/Continue Jarvis. Brain: set key → ask a question; "remember that I like tea" → Memory list. Camera: take photo → identify. Safety: Test emergency (cancel + prepare), siren, fake call. Notifications: enable access → "read notifications". Finance: add expense → report/chart. Recorder: record → transcribe. Backup: export/import with passphrase.
