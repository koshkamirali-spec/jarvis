# Connecting Gemini
1. Create a key at https://aistudio.google.com/apikey.
2. In the app: Settings → AI → paste the key → Save. It is stored encrypted (Android Keystore / iOS Keychain).
3. Model defaults to `gemini-2.5-flash`; change it in Settings if Google renames models.
4. Safer: put the key on the backend (docs/BACKEND.md) and enter only Backend URL + token in the app.
Web search answers use Gemini "google_search" grounding and show source links.
