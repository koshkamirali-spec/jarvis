# Backend
Zero-dependency Node (>=18) proxy: the phone sends the normal Gemini request, the server adds the key.
```
cd backend
cp .env.example .env        # set GEMINI_API_KEY and a long random APP_TOKEN
export $(cat .env | xargs) && node server.js     # or: docker build -t jarvis-backend . && docker run --env-file .env -p 8080:8080 jarvis-backend
node test.js                # self-test (passes)
```
Put it behind HTTPS (Caddy/nginx/Cloudflare Tunnel). In the app: Backend URL = https://your-host, Backend token = APP_TOKEN. Endpoints: `GET /health`, `POST /gemini?model=...`. Rate limit 30 req/min per IP (RATE_PER_MIN).
