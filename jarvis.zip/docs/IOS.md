# iOS
Sources in `ios/Jarvis`, widget in `ios/JarvisWidget`, share extension in `ios/JarvisShare`, project description `ios/project.yml` (XcodeGen). Build: `cd ios && xcodegen generate && open Jarvis.xcodeproj`, choose your team, run. Or use the GitHub workflow for an unsigned IPA.
Apple limits (see docs/FEATURES.md): no always-on wake word when closed — use "Hey Siri, Ask Jarvis", Shortcuts, the Action Button or the widget; background audio keeps a started voice session alive. The Share extension cannot read the Keychain key unless you add an App Group (needs a signing team).
