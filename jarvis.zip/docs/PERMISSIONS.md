# Permissions (Android)
Microphone (voice, recorder) · Location (weather, save place, emergency link, proximity reminders) · Camera (smart camera) · Contacts (call/message by name) · Notifications (alerts, service notice) · Foreground service: microphone + media projection (screen analysis, one-time consent each time) · Do Not Disturb access (modes/gaming) · Modify system settings (brightness) · Usage access (recent games) · Notification access (read/summarize/reply) · Default assistant role (optional).
Not requested on purpose: draw-over-other-apps (no floating UI), accessibility service, SMS send, call phone, read SMS.
Everything optional can be turned off in Settings → Modules.

Also: Wi-Fi state (Wi-Fi-name mode trigger), Bluetooth (Bluetooth-device mode trigger), Photos/media read (file search; Android 11 uses storage permission), Wake lock (listen with screen off), Ignore battery optimization (keep voice service alive).
