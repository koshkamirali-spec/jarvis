# Using JARVIS outside the app (Android 11)
1. Open JARVIS, give microphone permission, tap **Start background listening**. Allow "ignore battery optimization" when asked.
2. A permanent notification "J.A.R.V.I.S - Say Hey Jarvis" appears. Leave the app.
3. Say "Hey Jarvis" (or "هی جارویس"). JARVIS answers "Yes sir" / "بله قربان", then say your command. "Hey Jarvis, open camera" answers "Yes sir. Opening camera." in one go.
4. "Stop Jarvis" pauses, "Continue Jarvis" resumes, "Stop listening" ends the service.
Notes: start it while the app is visible (Android restriction). Samsung/Xiaomi/Huawei may still kill background apps: lock JARVIS in recent apps and disable battery optimization/auto-start limits for it. Opening other apps by voice from the background shows a tap-to-open notification (Android blocks direct launches). Not tested on a real phone by me.
