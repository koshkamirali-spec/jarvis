# J.A.R.V.I.S — Android (Kotlin) + iOS (Swift) + Backend (Node)
Package id (Android): `com.jarvis.ai`. One app, one shared brain (Gemini), one memory, one settings store.
**Not Flutter**: native Kotlin + Swift were used because they could not be compiled/tested here either way and native gives real access to services. See docs/FEATURES.md for the honest list of what works, what is limited and what is not built.
**Nothing here has been compiled or run on a device by me** (no Android SDK / Xcode / internet in my sandbox). Only the pure logic tests design and the Node backend test were run (backend: passed). Expect to fix a few compile errors on the first build — send me the log.

## 1. Build the APK with GitHub (no PC tools needed)
1. Create a GitHub repository, upload everything in this folder (keep `.github/`).
2. Actions tab → **Build Android APK** runs on push (or "Run workflow"). It runs the unit tests, then builds debug + release APKs.
3. Open the run → Artifacts → `JARVIS-apk` → install `app-debug.apk` (release APK is signed with the debug key: fine for personal use, not for Google Play).
4. First launch: enter your name, allow microphone/location/notifications, then Settings → paste your **Gemini API key** (docs/GEMINI.md) or your Backend URL/token (docs/BACKEND.md).

## 2. iOS
Actions → **Build iOS (unsigned IPA)** → Run workflow → artifact `JARVIS-ios-unsigned`. Unsigned: sign/sideload with your Apple ID (AltStore/Sideloadly) or open `ios/` in Xcode after `xcodegen generate`. See docs/IOS.md.

## 3. Backend (optional, keeps the Gemini key off phones)
`cd backend && cp .env.example .env` → set keys → `node server.js` (Node 18+) or Docker. See docs/BACKEND.md.

## Optional: better wake word
Get a free AccessKey at console.picovoice.ai, paste it in Settings → "Picovoice AccessKey". Then say "Jarvis" (built-in keyword). If the Porcupine dependency ever breaks the build, delete `Wake.kt`, the `Wake.` lines in `ListenService.kt` and the dependency line in `app/build.gradle.kts`; JARVIS then uses Android speech recognition.

## Folders
`app/` Android · `ios/` iOS · `backend/` Node proxy · `docs/` guides · `.github/workflows/` CI
