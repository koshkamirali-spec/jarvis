plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.jarvis.ai"
    compileSdk = 34
    defaultConfig { applicationId = "com.jarvis.ai"; minSdk = 28; targetSdk = 34; versionCode = 2; versionName = "2.0" }
    buildTypes { release { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("debug") } } // dev-signed release; use your own keystore for Play Store
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    lint { abortOnError = false; checkReleaseBuilds = false }
}
dependencies { implementation("androidx.core:core-ktx:1.13.1"); implementation("ai.picovoice:porcupine-android:3.0.2"); testImplementation("junit:junit:4.13.2") }
