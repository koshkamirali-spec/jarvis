package com.jarvis.ai
import org.junit.Assert.*
import org.junit.Test
class LogicTest {
    @Test fun calc() { assertEquals(14.0, Logic.calc("2+3*4")!!, 1e-9); assertEquals(20.0, Logic.calc("(2+3)*4")!!, 1e-9); assertEquals(2.5, Logic.calc("10/4")!!, 1e-9); assertEquals(15.0, Logic.calc("۱۲+۳")!!, 1e-9); assertNull(Logic.calc("2+")) }
    @Test fun extract() { assertEquals("12*3", Logic.extractExpr("what is 12*3 please")) }
    @Test fun units() { assertTrue(Logic.convert("5 km to miles")!!.contains("3.1068")); assertEquals("100 c = 212 f", Logic.convert("100 c to f")); assertNull(Logic.convert("hello")) }
    @Test fun split() { assertEquals(listOf("open camera", "play music"), Logic.split("open camera then play music")); assertEquals(1, Logic.split("hello world").size) }
    @Test fun millis() { assertEquals(600000L, Logic.parseMillis("remind me in 10 minutes")); assertEquals(7200000L, Logic.parseMillis("۲ ساعت")); assertNull(Logic.parseMillis("later")) }
    @Test fun lang() { assertTrue(Logic.isPersian("سلام")); assertFalse(Logic.isPersian("hello")) }
    @Test fun plan() { assertTrue(Logic.wantsPlan("please do the following: open maps")); assertFalse(Logic.wantsPlan("open maps")) }
    @Test fun rules() { assertEquals(ModeRule.Time(22, 6), Logic.parseRule("22-6")); assertEquals(ModeRule.Wifi("Home"), Logic.parseRule("wifi:Home")); assertEquals(ModeRule.Charging, Logic.parseRule("Charging")); assertEquals(ModeRule.Bt("Car"), Logic.parseRule("bt:Car")); assertNull(Logic.parseRule("nonsense"))
        assertTrue(Logic.inRange(23, 22, 6)); assertTrue(Logic.inRange(3, 22, 6)); assertFalse(Logic.inRange(12, 22, 6)); assertTrue(Logic.inRange(9, 8, 17)) }
    @Test fun search() { assertTrue(Logic.needsSearch("latest news")); assertFalse(Logic.needsSearch("open camera")) }
}
