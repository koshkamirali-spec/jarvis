package com.jarvis.ai
import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Base64
import android.widget.*
import org.json.JSONObject
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Passphrase-encrypted backup of everything except API keys/secrets (those stay in the Keystore and must be re-entered). */
object Backup {
    private fun key(pass: String, salt: ByteArray) = SecretKeySpec(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(PBEKeySpec(pass.toCharArray(), salt, 120_000, 256)).encoded, "AES")
    fun export(c: android.content.Context, pass: String): ByteArray {
        val j = JSONObject(); Store.all(c).forEach { (k, v) -> if (!k.startsWith("s_") && !k.startsWith("l_") && v != null) j.put(k, JSONObject().put("t", v.javaClass.simpleName).put("v", v.toString())) }
        Store.allLists(c).forEach { (k, l) -> j.put("l:$k", JSONObject().put("t", "List").put("v", org.json.JSONArray(l).toString())) }
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }; val ci = Cipher.getInstance("AES/GCM/NoPadding"); ci.init(Cipher.ENCRYPT_MODE, key(pass, salt))
        return Base64.encode(salt + ci.iv + ci.doFinal(j.toString().toByteArray()), Base64.NO_WRAP)
    }
    fun import(c: android.content.Context, data: ByteArray, pass: String): Boolean = try {
        val b = Base64.decode(data, Base64.NO_WRAP); val ci = Cipher.getInstance("AES/GCM/NoPadding"); ci.init(Cipher.DECRYPT_MODE, key(pass, b.copyOfRange(0, 16)), GCMParameterSpec(128, b, 16, 12))
        val j = JSONObject(String(ci.doFinal(b, 28, b.size - 28)))
        j.keys().forEach { k -> val o = j.getJSONObject(k); val v = o.getString("v"); when (o.getString("t")) { "List" -> Store.setList(c, k.removePrefix("l:"), org.json.JSONArray(v).let { a -> List(a.length()) { a.getString(it) } }); "Integer" -> Store.setInt(c, k, v.toInt()); "Boolean" -> Store.setBool(c, k, v.toBoolean()); "Long" -> Store.setLong(c, k, v.toLong()); else -> Store.setStr(c, k, v) } }; true
    } catch (e: Exception) { ErrorLog.e(c, "backup", e); false }
}

object Sync {
    private fun con(c: android.content.Context, method: String): java.net.HttpURLConnection? {
        val b = Store.str(c, "backend").trim().trimEnd('/'); if (b.isEmpty()) return null
        return (java.net.URL("$b/sync").openConnection() as java.net.HttpURLConnection).apply { requestMethod = method; connectTimeout = 10000; readTimeout = 20000; setRequestProperty("x-app-token", Store.secret(c, "backend_token")) }
    }
    fun put(c: android.content.Context, data: ByteArray): Boolean = try { val k = con(c, "PUT") ?: return false; k.doOutput = true; k.outputStream.use { it.write(data) }; k.responseCode == 200 } catch (e: Exception) { ErrorLog.e(c, "sync", e); false }
    fun get(c: android.content.Context): ByteArray? = try { val k = con(c, "GET") ?: return null; if (k.responseCode == 200) k.inputStream.use { it.readBytes() } else null } catch (e: Exception) { ErrorLog.e(c, "sync", e); null }
}

object AutoSync {
    fun schedule(c: android.content.Context) {
        if (!Store.bool(c, "auto_sync")) return
        (c.getSystemService(android.content.Context.ALARM_SERVICE) as android.app.AlarmManager).setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 24 * 3_600_000L,
            android.app.PendingIntent.getBroadcast(c, 6001, android.content.Intent(c, SyncReceiver::class.java), android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT))
    }
    fun cancel(c: android.content.Context) = (c.getSystemService(android.content.Context.ALARM_SERVICE) as android.app.AlarmManager).cancel(android.app.PendingIntent.getBroadcast(c, 6001, android.content.Intent(c, SyncReceiver::class.java), android.app.PendingIntent.FLAG_IMMUTABLE))
}
class SyncReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(c: android.content.Context, i: android.content.Intent) {
        val p = Store.secret(c, "sync_pass"); if (p.isBlank() || !Store.bool(c, "auto_sync")) return
        val pr = goAsync(); Thread { try { Sync.put(c, Backup.export(c, p)) } finally { pr.finish() } }.start(); AutoSync.schedule(c)
    }
}

class SettingsActivity : BaseActivity() {
    private val savers = mutableListOf<() -> Unit>()
    override fun onCreate(s: Bundle?) {
        super.onCreate(s); val r = Ui.screen(this, "Settings · تنظیمات")
        fun h(t: String) = r.addView(Ui.text(this, t, 17, Ui.CYAN, true))
        fun field(label: String, key: String, secret: Boolean = false, def: String = "") {
            r.addView(Ui.text(this, label, 12, 0xFF8888AA.toInt())); val e = Ui.edit(this, if (secret && Store.secret(this, key).isNotEmpty()) "•••• saved (type to replace)" else label, if (secret) "" else Store.str(this, key, def))
            if (secret) e.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            r.addView(e); savers.add { val v = e.text.toString().trim(); if (secret) { if (v.isNotEmpty()) Store.setSecret(this, key, v) } else Store.setStr(this, key, v) } }
        fun slider(label: String, key: String, min: Int, max: Int, def: Int) { val cur = Store.int(this, key, def); val tv = Ui.text(this, "$label: $cur", 14); r.addView(tv)
            r.addView(SeekBar(this).apply { this.max = max - min; progress = cur - min; setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener { override fun onProgressChanged(b: SeekBar?, p: Int, u: Boolean) { Store.setInt(this@SettingsActivity, key, p + min); tv.text = "$label: ${p + min}" }; override fun onStartTrackingTouch(b: SeekBar?) {}; override fun onStopTrackingTouch(b: SeekBar?) {} }) }) }
        fun switch(label: String, key: String, def: Boolean) = r.addView(Switch(this).apply { text = label; setTextColor(Ui.WHITE); isChecked = Store.bool(this@SettingsActivity, key, def); setOnCheckedChangeListener { _, v -> Store.setBool(this@SettingsActivity, key, v) } })

        h("AI · هوش مصنوعی"); field("Gemini API key", "gemini", true); field("Model", "model", false, "gemini-2.5-flash"); field("Backend URL (optional, keeps key off the phone)", "backend"); field("Backend token", "backend_token", true)
        h("Language & voice · زبان و صدا"); field("Recognition language tag (fa-IR, en-US; blank = phone)", "lang"); field("Wake phrase", "wake", false, "Hey Jarvis"); field("Picovoice AccessKey (optional: accurate low-battery “Jarvis” wake word)", "picovoice", true)
        field("Reply when called (Persian)", "ack_fa", false, "بله قربان"); field("Reply when called (English)", "ack_en", false, "Yes sir"); switch("Keep listening with screen off (CPU wake lock, uses battery)", "keep_awake", true); switch("Silence the recognizer beep", "mute_beep", true)
        slider("Wake sensitivity (1 strict – 2 loose)", "sens", 1, 2, 1); slider("Speech speed %", "tts_rate", 50, 200, 100); slider("Voice pitch %", "tts_pitch", 50, 200, 100); slider("Voice volume %", "tts_vol", 10, 100, 100)
        r.addView(Ui.button(this, "Test voice") { Speaker.speak(this, if (Lang.fa(this)) "سلام، من جارویس هستم." else "Hello, I'm JARVIS.") })
        h("Appearance · ظاهر"); slider("Text size", "text_size", 12, 24, 16); switch("Glow effects", "glow", true)
        r.addView(Ui.button(this, "Accent color: gold / cyan / purple") { val n = when (Store.str(this, "accent", "gold")) { "gold" -> "cyan"; "cyan" -> "purple"; else -> "gold" }; Store.setStr(this, "accent", n); recreate() })
        switch("Dashboard: clock card", "card_clock", true); switch("Dashboard: weather card", "card_weather", true); switch("Dashboard: battery card", "card_battery", true)
        h("Internet · اینترنت"); switch("Use AI only on Wi-Fi (no mobile data)", "wifi_only", false)
        h("Background & battery · پس‌زمینه و باتری"); slider("Stop listening after idle minutes (0 = never)", "idle_min", 0, 120, 30)
        r.addView(Ui.text(this, "Status: voice service ${if (ListenService.running) "RUNNING – ${ListenService.stateText}" else "off"}", 13))
        r.addView(Ui.button(this, "Battery optimization settings") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) })
        h("Modules · ماژول‌ها (turn off what you don't need)")
        listOf("phone" to "Phone control", "tools" to "Daily tools & memory", "finance" to "Finance", "comms" to "Communication", "web" to "Web assistant", "home" to "Smart home", "location" to "Location", "games" to "Games", "safety" to "Safety & emergency", "vision" to "Smart camera", "files" to "Files", "media" to "Recorder", "screens" to "Voice screen-opening", "modes" to "Modes").forEach { switch(it.second, "mod_${it.first}", true) }
        h("Smart home (Home Assistant)"); field("Home Assistant URL (http://host:8123)", "ha_url"); field("Long-lived access token", "ha_token", true)
        h("Notifications · اعلان‌ها")
        r.addView(Ui.button(this, "Allow JARVIS to read notifications") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) })
        r.addView(Ui.button(this, "Ignored apps (package contains…)") { startActivity(Intent(this, ListActivity::class.java).putExtra("key", "notif_block").putExtra("title", "Ignored notification apps").putExtra("hint", "e.g. facebook")) })
        h("Permissions · مجوزها"); permissions(r)
        h("Security & privacy · امنیت و حریم خصوصی"); switch("Privacy Lock (PIN/fingerprint for Memory, Finance, Safety, lists)", "privacy_lock", false)
        r.addView(Ui.text(this, "API keys and emergency info are encrypted with the Android Keystore. Nothing is sent without your action. Notifications are kept in RAM only.", 12, 0xFF8888AA.toInt()))
        h("Data · اطلاعات")
        r.addView(Ui.button(this, "Memory manager") { startActivity(Intent(this, ListActivity::class.java).putExtra("key", "memory").putExtra("title", "Memory").putExtra("hint", "A fact about you")) })
        r.addView(Ui.button(this, "Clear conversation history") { Store.clearHistory(this); Ui.toast(this, "Cleared") })
        r.addView(Ui.button(this, "Encrypted backup (export)") { Ui.ask(this, "Backup passphrase", "passphrase") { p -> pass = p; startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).setType("*/*").putExtra(Intent.EXTRA_TITLE, "jarvis-backup.jbk"), 201) } })
        r.addView(Ui.button(this, "Restore backup (import)") { Ui.ask(this, "Backup passphrase", "passphrase") { p -> pass = p; startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*"), 202) } })
        r.addView(Ui.button(this, "Sync: upload encrypted backup to my backend") { Ui.ask(this, "Passphrase", "passphrase") { p -> Thread { val ok = Sync.put(this, Backup.export(this, p)); runOnUiThread { Ui.toast(this, if (ok) "Uploaded ✓" else "Failed – check Backend URL/token") } }.start() } })
        r.addView(Ui.button(this, "Sync: download & restore from my backend") { Ui.ask(this, "Passphrase", "passphrase") { p -> Thread { val d = Sync.get(this); val ok = d != null && Backup.import(this, d, p); runOnUiThread { Ui.toast(this, if (ok) "Restored ✓" else "Failed – wrong passphrase or no backup"); if (ok) recreate() } }.start() } })
        r.addView(Switch(this).apply { text = "Daily auto-sync to my backend (needs the passphrase below, stored encrypted)"; setTextColor(Ui.WHITE); isChecked = Store.bool(this@SettingsActivity, "auto_sync"); setOnCheckedChangeListener { _, v -> Store.setBool(this@SettingsActivity, "auto_sync", v); if (v) AutoSync.schedule(this@SettingsActivity) else AutoSync.cancel(this@SettingsActivity) } })
        field("Auto-sync passphrase", "sync_pass", true)
        switch("Ask before remembering preferences (learn what I like)", "learn_prefs", true)
        r.addView(Ui.button(this, "Log out (remove saved keys)") { listOf("gemini", "backend_token", "ha_token").forEach { Store.setSecret(this, it, "") }; Ui.toast(this, "Keys removed") })
        r.addView(Ui.button(this, "Erase ALL data") { AlertDialog.Builder(this).setMessage("Erase everything?").setPositiveButton("Erase") { _, _ -> Store.wipe(this); finishAffinity() }.setNegativeButton("Cancel", null).show() })
        h("System status & recent errors · خطاها"); r.addView(Ui.text(this, Store.list(this, "errors").takeLast(8).joinToString("\n").ifEmpty { "No errors recorded." }, 12))
        r.addView(Ui.button(this, "Save settings") { savers.forEach { it() }; Ui.toast(this, "Saved ✓") })
        r.addView(Ui.button(this, "Modes") { startActivity(Intent(this, ModesActivity::class.java)) })
    }
    private var pass = ""
    private fun permissions(r: LinearLayout) {
        val list = mutableListOf("Microphone" to Manifest.permission.RECORD_AUDIO, "Location" to Manifest.permission.ACCESS_FINE_LOCATION, "Contacts" to Manifest.permission.READ_CONTACTS, "Camera" to Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) list.add("Notifications" to Manifest.permission.POST_NOTIFICATIONS)
        for ((n, p) in list) { val ok = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED; r.addView(Ui.button(this, "$n: ${if (ok) "granted ✓" else "tap to grant"}") { if (!ok) requestPermissions(arrayOf(p), 5) }) }
        r.addView(Ui.button(this, "Do Not Disturb access") { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) })
        r.addView(Ui.button(this, "Modify system settings (brightness)") { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))) })
        r.addView(Ui.button(this, "Usage access (recent games)") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) })
        r.addView(Ui.button(this, "Default assistant") { startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) })
    }
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, d: Intent?) {
        super.onActivityResult(req, res, d); val u = d?.data ?: return; if (res != RESULT_OK) return
        if (req == 201) contentResolver.openOutputStream(u)?.use { it.write(Backup.export(this, pass)) }.also { Ui.toast(this, "Backup saved") }
        if (req == 202) { val ok = contentResolver.openInputStream(u)?.use { Backup.import(this, it.readBytes(), pass) } ?: false; Ui.toast(this, if (ok) "Restored ✓" else "Wrong passphrase or file"); if (ok) recreate() }
    }
}
