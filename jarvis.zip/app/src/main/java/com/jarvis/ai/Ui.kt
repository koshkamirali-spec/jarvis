package com.jarvis.ai
import android.app.Activity
import android.app.AlertDialog
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.sin

/** Holographic theme: black, gold, purple, neon blue. */
object Ui {
    val BG = 0xFF05050D.toInt(); val GOLD = 0xFFFFC857.toInt(); val PURPLE = 0xFF7B2FF7.toInt(); val CYAN = 0xFF00E5FF.toInt(); val CARD = 0xFF12122A.toInt(); val WHITE = 0xFFEDEDF7.toInt()
    fun accent(c: Context) = when (Store.str(c, "accent", "gold")) { "cyan" -> CYAN; "purple" -> 0xFFB388FF.toInt(); else -> GOLD }
    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()
    fun screen(a: Activity, title: String): LinearLayout {
        val sv = ScrollView(a).apply { setBackgroundColor(BG); isFillViewport = true }
        val l = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(a, 16), dp(a, 40), dp(a, 16), dp(a, 24)) }
        sv.addView(l); a.setContentView(sv); l.addView(text(a, title, 22, accent(a), true)); return l
    }
    fun text(c: Context, s: String, size: Int = Store.int(c, "text_size", 16), color: Int = WHITE, bold: Boolean = false) = TextView(c).apply {
        text = s; textSize = size.toFloat(); setTextColor(color); setPadding(0, dp(c, 6), 0, dp(c, 6)); if (bold) setTypeface(typeface, Typeface.BOLD) }
    fun button(c: Context, label: String, onClick: () -> Unit) = Button(c).apply {
        text = label; isAllCaps = false; setTextColor(accent(c)); textSize = 15f
        background = GradientDrawable().apply { setColor(0xFF1E1240.toInt()); setStroke(dp(c, 1), PURPLE); cornerRadius = dp(c, 14).toFloat() }
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(c, 8) }
        setOnClickListener { onClick() } }
    fun card(c: Context) = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(c, 12), dp(c, 8), dp(c, 12), dp(c, 8)); background = GradientDrawable().apply { setColor(CARD); setStroke(dp(c, 1), 0xFF3A2A7A.toInt()); cornerRadius = dp(c, 14).toFloat() } }
    fun edit(c: Context, hint: String, v: String = "") = EditText(c).apply { this.hint = hint; setText(v); setTextColor(WHITE); setHintTextColor(0xFF8888AA.toInt()) }
    fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_SHORT).show()
    fun ask(a: Activity, title: String, hint: String, def: String = "", ok: (String) -> Unit) {
        val e = EditText(a).apply { this.hint = hint; setText(def) }
        AlertDialog.Builder(a).setTitle(title).setView(e).setPositiveButton("OK") { _, _ -> ok(e.text.toString()) }.setNegativeButton("Cancel", null).show()
    }
    fun dateLine(fa: Boolean): String {
        val g = java.text.SimpleDateFormat("EEE d MMM yyyy", java.util.Locale.US).format(java.util.Date()); if (!fa) return g
        val m = listOf("فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"); val p = android.icu.util.PersianCalendar()
        return "${p.get(Calendar.DAY_OF_MONTH)} ${m[p.get(Calendar.MONTH)]} ${p.get(Calendar.YEAR)}"
    }
}

class LogoView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG); private var a = 0f
    override fun onDraw(cv: Canvas) {
        val r = minOf(width, height) / 2f; val cx = width / 2f; val cy = height / 2f
        p.style = Paint.Style.FILL; p.color = Ui.PURPLE; cv.drawCircle(cx, cy, r * 0.82f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.12f; p.color = Ui.GOLD; cv.drawArc(cx - r * 0.9f, cy - r * 0.9f, cx + r * 0.9f, cy + r * 0.9f, a, 280f, false, p)
        p.style = Paint.Style.FILL; p.color = Color.WHITE; p.textSize = r * 1.1f; p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.DEFAULT_BOLD
        cv.drawText("J", cx, cy + r * 0.38f, p); a = (a + 3f) % 360f; postInvalidateOnAnimation()
    }
}

/** Sound wave that reacts to Listening / Thinking / Speaking. */
class HoloView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }; private var t = 0f
    override fun onDraw(cv: Canvas) {
        val n = 28; val w = width.toFloat(); val h = height.toFloat(); val gap = w / n; p.strokeWidth = gap * 0.45f; val glow = Store.bool(context, "glow", true)
        for (i in 0 until n) {
            val ph = t + i * 0.45f
            val amp = when (Brain.state) { Brain.St.LISTENING -> 0.55f + 0.4f * abs(sin(ph * 1.7f)); Brain.St.SPEAKING -> 0.3f + 0.5f * abs(sin(ph)); Brain.St.THINKING -> 0.15f + 0.25f * abs(sin(ph * 0.5f + i * 0.1f)); else -> 0.06f + 0.04f * sin(ph) }
            val bar = h * amp * (0.4f + 0.6f * sin(i * Math.PI / n).toFloat()); p.color = if (i % 2 == 0) Ui.accent(context) else Ui.CYAN
            if (glow) { p.alpha = 60; p.strokeWidth = gap * 0.9f; cv.drawLine(gap * i + gap / 2, h / 2 - bar / 2, gap * i + gap / 2, h / 2 + bar / 2, p); p.alpha = 255; p.strokeWidth = gap * 0.45f }
            cv.drawLine(gap * i + gap / 2, h / 2 - bar / 2, gap * i + gap / 2, h / 2 + bar / 2, p)
        }
        t += 0.12f; postInvalidateOnAnimation()
    }
}

abstract class BaseActivity : Activity() {
    override fun onResume() { super.onResume(); App.visible = true }
    override fun onPause() { super.onPause(); App.visible = false }
}

/** Sensitive screens ask for your phone's PIN/fingerprint when Privacy Lock is on. */
abstract class GuardedActivity : BaseActivity() {
    abstract fun build()
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (Store.bool(this, "privacy_lock") && km.isDeviceSecure) {
            @Suppress("DEPRECATION") startActivityForResult(km.createConfirmDeviceCredentialIntent("JARVIS", "Unlock to continue"), 99)
        } else build()
    }
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, d: Intent?) { if (req == 99) { if (res == RESULT_OK) build() else finish() } else super.onActivityResult(req, res, d) }
}

/** Generic editable list used by tasks, shopping, goals, notes, memory, commands, favorites, contacts... */
class ListActivity : GuardedActivity() {
    private lateinit var key: String; private lateinit var box: LinearLayout
    override fun build() {
        key = intent.getStringExtra("key") ?: "notes"
        val root = Ui.screen(this, intent.getStringExtra("title") ?: key)
        val input = Ui.edit(this, intent.getStringExtra("hint") ?: "Add…")
        root.addView(input)
        root.addView(Ui.button(this, "Add") { val v = input.text.toString().trim(); if (v.isNotEmpty()) { Store.push(this, key, v); input.setText(""); render() } })
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; root.addView(box); render()
    }
    private fun render() {
        box.removeAllViews(); val l = Store.list(this, key)
        if (l.isEmpty()) box.addView(Ui.text(this, "(empty)", 14, 0xFF8888AA.toInt()))
        l.forEachIndexed { i, s ->
            val c = Ui.card(this); c.addView(Ui.text(this, s)); (c.layoutParams as? LinearLayout.LayoutParams)
            c.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = Ui.dp(this@ListActivity, 8) }
            c.setOnClickListener { AlertDialog.Builder(this).setItems(arrayOf("Edit", "Delete")) { _, w ->
                if (w == 0) Ui.ask(this, "Edit", "", s) { v -> Store.replaceAt(this, key, i, v.trim()); render() } else { Store.removeAt(this, key, i); render() } }.show() }
            box.addView(c)
        }
    }
}

class ModesActivity : BaseActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s); val root = Ui.screen(this, "Modes")
        root.addView(Ui.text(this, "Tap to activate. Long-press to set an automatic schedule (e.g. 22-6 means 22:00 to 06:00).", 13, 0xFF8888AA.toInt()))
        val cur = Ui.text(this, "", 15, Ui.CYAN); root.addView(cur)
        fun refresh() { cur.text = "Active: ${Modes.title(this, Modes.current(this), false)}" }
        for (m in Modes.all) root.addView(Ui.button(this, "${Modes.title(this, m, false)} · ${m.fa}${Store.str(this, "auto_${m.id}").let { if (it.isNotBlank()) "  ⏰$it" else "" }}") {
            Modes.set(this, m.id); refresh()
            if (m.dnd && !Modes.dnd(this, true)) { Ui.toast(this, "Allow Do Not Disturb access to silence notifications"); startActivity(Intent(android.provider.Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
            if (m.id == "custom") Ui.ask(this, "Custom mode name", "name", Store.str(this, "custom_name")) { n -> Store.setStr(this, "custom_name", n); Ui.ask(this, "How should JARVIS behave?", "instructions", Store.str(this, "custom_prompt")) { p -> Store.setStr(this, "custom_prompt", p) } }
        }.also { b -> b.setOnLongClickListener {
            val dndNow = Store.str(this, "mode_${m.id}_dnd").let { if (it.isEmpty()) m.dnd else it == "1" }; val readNow = Modes.all.first { x -> x.id == m.id }.let { x -> Store.str(this, "mode_${m.id}_read").let { if (it.isEmpty()) x.readNotifs else it == "1" } }
            AlertDialog.Builder(this).setTitle("${m.title} settings").setItems(arrayOf("Automatic schedule…", "Do-Not-Disturb: ${if (dndNow) "ON" else "off"} (tap to toggle)", "Read messages aloud: ${if (readNow) "ON" else "off"} (tap to toggle)")) { _, w ->
                when (w) { 0 -> Ui.ask(this, "Auto schedule for ${m.title}", "22-6 | wifi:HomeName | charging | bt:CarName (empty = off)", Store.str(this, "auto_${m.id}")) { v -> Store.setStr(this, "auto_${m.id}", v.trim()); recreate() }
                    1 -> { Store.setStr(this, "mode_${m.id}_dnd", if (dndNow) "0" else "1"); Ui.toast(this, "Saved") }
                    else -> { Store.setStr(this, "mode_${m.id}_read", if (readNow) "0" else "1"); Ui.toast(this, "Saved") } } }.show(); true } })
        refresh()
    }
}

object Weather {
    fun fetch(c: Context, cb: (String) -> Unit) {
        val cached = Store.str(c, "w_txt"); if (cached.isNotEmpty() && System.currentTimeMillis() - Store.long(c, "w_ts") < 1_800_000) { cb(cached); return }
        val l = Loc.last(c) ?: run { cb("📍 enable location"); return }
        Thread {
            try {
                val j = JSONObject(Net.get("https://api.open-meteo.com/v1/forecast?latitude=${l.latitude}&longitude=${l.longitude}&current=temperature_2m,weather_code")).getJSONObject("current")
                val icon = when (j.getInt("weather_code")) { 0 -> "☀️"; 1, 2, 3 -> "⛅"; 45, 48 -> "🌫"; in 51..67 -> "🌧"; in 71..77 -> "❄️"; in 80..82 -> "🌦"; in 95..99 -> "⛈"; else -> "🌡" }
                val s = "$icon ${j.getDouble("temperature_2m").toInt()}°C"; Store.setStr(c, "w_txt", s); Store.setLong(c, "w_ts", System.currentTimeMillis()); cb(s)
            } catch (e: Exception) { ErrorLog.e(c, "weather", e); cb("☁ offline") }
        }.start()
    }
}
