package com.jarvis.ai
import android.content.Context
import android.content.Intent
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Web assistant. Searching/news/prices go to Gemini with Google Search grounding (answers include source links). */
object Web {
    private fun text(html: String) = html.replace(Regex("(?is)<(script|style)[^>]*>.*?</\\1>"), " ").replace(Regex("<[^>]+>"), " ").replace(Regex("&[a-z#0-9]+;"), " ").replace(Regex("\\s+"), " ").trim()
    fun page(url: String, n: Int = 7000) = text(Net.get(url)).take(n)
    fun handle(c: Context, t: String, raw: String, fa: Boolean): String? {
        fun has(vararg k: String) = k.any { t.contains(it) }
        fun r(en: String, f: String) = if (fa) f else en
        val urls = Regex("https?://\\S+").findAll(raw).map { it.value }.toList()
        if (urls.isNotEmpty() && has("save page", "bookmark", "ذخیره صفحه")) { Store.push(c, "pages", urls[0]); return r("Page saved.", "صفحه ذخیره شد.") }
        if (has("saved pages", "my pages", "صفحات ذخیره", "صفحه‌های ذخیره")) return Store.list(c, "pages").ifEmpty { listOf(r("No saved pages.", "صفحه‌ای ذخیره نشده.")) }.joinToString("\n")
        if (urls.size >= 2 && has("compare", "مقایسه")) return try { Llm.ask(c, "Compare these two web pages briefly.\n\nA:\n${page(urls[0], 4000)}\n\nB:\n${page(urls[1], 4000)}", withHistory = false, maxTokens = 420) } catch (e: Exception) { ErrorLog.e(c, "web", e); r("Could not load the pages.", "بارگذاری صفحه‌ها ممکن نشد.") }
        if (urls.isNotEmpty() && has("summar", "analy", "translate", "خلاصه", "تحلیل", "ترجمه")) return try {
            val task = if (has("translate", "ترجمه")) "Translate the main content to ${if (fa) "Persian" else "English"}." else if (has("analy", "تحلیل")) "Analyze this page: key points, tone, and reliability warnings." else "Summarize this page in 3 short sentences."
            Llm.ask(c, "$task\n\n${page(urls[0])}", withHistory = false, maxTokens = 420) } catch (e: Exception) { ErrorLog.e(c, "web", e); r("Could not load that page.", "بارگذاری صفحه ممکن نشد.") }
        if (has("search videos", "youtube", "ویدیو", "ویدئو") && has("search", "find", "جستجو", "پیدا")) { val q = raw.replace(Regex("(?i)search videos|search|find|youtube|for|جستجو|ویدیو|ویدئو|پیدا کن"), "").trim()
            Router.open(c, "YouTube", Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(q)}"))); return r("Searching videos for “$q”.", "جستجوی ویدیو برای «$q».") }
        if (has("search images", "image search", "جستجوی تصویر", "جستجوی عکس")) { val q = raw.replace(Regex("(?i)search images|image search|of|for|جستجوی تصویر|جستجوی عکس"), "").trim()
            Router.open(c, "Images", Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?tbm=isch&q=${Uri.encode(q)}"))); return r("Image search for “$q”.", "جستجوی تصویر برای «$q».") }
        if (has("stores near", "shops near", "فروشگاه نزدیک", "مغازه نزدیک")) { val q = raw.replace(Regex("(?i)stores near me|shops near me|stores near|shops near|for|فروشگاه نزدیک|مغازه نزدیک"), "").trim().ifEmpty { "store" }
            Router.open(c, "Maps", Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=${Uri.encode(q)}"))); return r("Showing “$q” nearby on the map.", "«$q» در نزدیکی روی نقشه.") }
        return null
    }
}

/** Smart home through Home Assistant's REST API (your own server). Every action asks for confirmation. */
object Home {
    private fun call(c: Context, path: String, body: String? = null): String {
        val con = URL(Store.str(c, "ha_url").trim().trimEnd('/') + path).openConnection() as HttpURLConnection
        con.setRequestProperty("Authorization", "Bearer " + Store.secret(c, "ha_token")); con.setRequestProperty("content-type", "application/json"); con.connectTimeout = 8000; con.readTimeout = 8000
        if (body != null) { con.requestMethod = "POST"; con.doOutput = true; con.outputStream.use { it.write(body.toByteArray()) } }
        return con.inputStream.bufferedReader().readText()
    }
    private fun entities(c: Context): List<Pair<String, String>> { val a = JSONArray(call(c, "/api/states")); return (0 until a.length()).map { val o = a.getJSONObject(it); o.getString("entity_id") to o.optJSONObject("attributes")?.optString("friendly_name", "").orEmpty() } }
    fun handle(c: Context, t: String, fa: Boolean): String? {
        fun has(vararg k: String) = k.any { t.contains(it) }
        fun r(en: String, f: String) = if (fa) f else en
        val isScene = has("scene ", "سناریوی", "سناریو ")
        val isSwitch = (has("turn on", "turn off", "switch on", "switch off", "روشن کن", "خاموش کن")) && has("light", "lamp", "plug", "fan", "heater", "ac ", "چراغ", "پریز", "پنکه", "کولر", "بخاری", "لامپ")
        if (!isScene && !isSwitch) return null
        if (Store.str(c, "ha_url").isBlank() || Store.secret(c, "ha_token").isBlank()) return r("Smart home needs your Home Assistant URL and token in Settings.", "برای خانه هوشمند آدرس و توکن Home Assistant را در تنظیمات وارد کنید.")
        val name = t.replace(Regex("turn on|turn off|switch on|switch off|scene|run|the|روشن کن|خاموش کن|سناریوی|سناریو"), "").trim()
        val on = !has("turn off", "switch off", "خاموش کن")
        return try {
            val m = entities(c).firstOrNull { (id, fn) -> (fn.lowercase().contains(name) || name.contains(fn.lowercase()) && fn.isNotBlank()) && (if (isScene) id.startsWith("scene.") else id.substringBefore(".") in listOf("light", "switch", "fan", "climate", "input_boolean")) }
                ?: return r("No matching device “$name”.", "دستگاهی به نام «$name» پیدا نشد.")
            Confirm.ask(fa, "${if (isScene) "Run scene" else if (on) "Turn on" else "Turn off"} ${m.second.ifBlank { m.first }}", "${if (isScene) "اجرای سناریو" else if (on) "روشن کردن" else "خاموش کردن"} ${m.second.ifBlank { m.first }}") {
                try { val dom = m.first.substringBefore("."); call(c, "/api/services/$dom/${if (isScene || on) "turn_on" else "turn_off"}", JSONObject().put("entity_id", m.first).toString()); if (fa) "انجام شد." else "Done." } catch (e: Exception) { ErrorLog.e(c, "home", e); if (fa) "اجرا نشد." else "The command failed." } }
        } catch (e: Exception) { ErrorLog.e(c, "home", e); r("Could not reach Home Assistant.", "اتصال به Home Assistant ممکن نشد.") }
    }
}
