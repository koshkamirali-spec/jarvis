package com.jarvis.ai
import android.Manifest
import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Notification memory (RAM only, never written to disk). */
object NotifStore {
    data class N(val app: String, val title: String, val text: String, val msg: Boolean, val time: Long)
    val items = ArrayDeque<N>()
    @Volatile var lastAction: Notification.Action? = null
    @Volatile var lastSender = ""
    var unanswered = 0
    fun digest(n: Int) = synchronized(items) { items.toList().takeLast(n).joinToString(" ; ") { "${it.app}|${it.title}|${it.text.take(80)}" } }
    fun sendReply(c: Context, text: String): Boolean {
        val a = lastAction ?: return false; val ri = a.remoteInputs?.firstOrNull() ?: return false
        val i = Intent(); val b = Bundle(); b.putCharSequence(ri.resultKey, text); RemoteInput.addResultsToIntent(a.remoteInputs, i, b)
        return try { a.actionIntent.send(c, 0, i); unanswered = maxOf(0, unanswered - 1); true } catch (e: Exception) { ErrorLog.e(c, "reply", e); false }
    }
}

/** Needs the user to enable "Notification access" for JARVIS in system settings. */
class JarvisNotifListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName || sbn.isOngoing) return
        if (Store.list(this, "notif_block").any { it.isNotBlank() && sbn.packageName.contains(it.trim(), true) }) return
        val ex = sbn.notification.extras; val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""; val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        if (title.isBlank() && text.isBlank()) return
        val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString() } catch (e: Exception) { sbn.packageName }
        val msg = sbn.notification.category == Notification.CATEGORY_MESSAGE
        synchronized(NotifStore.items) { NotifStore.items.addLast(NotifStore.N(label, title, text, msg, sbn.postTime)); while (NotifStore.items.size > 60) NotifStore.items.removeFirst() }
        if (msg) { NotifStore.unanswered++
            sbn.notification.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true }?.let { NotifStore.lastAction = it; NotifStore.lastSender = title }
            if (Modes.readsNotifs(this) && ListenService.running) Speaker.speak(this, "$title: ${text.take(140)}") }
    }
}

object Comms {
    private fun granted(c: Context) = c.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
    fun findContact(c: Context, name: String): Pair<String, String>? {
        if (!granted(c) || name.isBlank()) return null
        c.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%${name.trim()}%"), null)?.use { if (it.moveToFirst()) return it.getString(0) to it.getString(1) }
        return null
    }
    fun handle(c: Context, t: String, raw: String, fa: Boolean): String? {
        fun has(vararg k: String) = k.any { t.contains(it) }
        fun r(en: String, f: String) = if (fa) f else en
        val noPerm = r("Allow Contacts permission in JARVIS Settings > Permissions.", "مجوز مخاطبین را در تنظیمات جارویس بدهید.")
        if (has("read notifications", "اعلان‌ها را بخوان", "اعلان ها را بخوان")) { if (NotifStore.items.isEmpty()) return r("No recent notifications (enable Notification access in Settings).", "اعلانی نیست (دسترسی اعلان‌ها را در تنظیمات فعال کنید).")
            return synchronized(NotifStore.items) { NotifStore.items.toList().takeLast(5).joinToString(". ") { "${it.app}: ${it.title} ${it.text.take(60)}" } } }
        if (has("unanswered", "پاسخ داده نشده", "پاسخ‌داده‌نشده")) return r("${NotifStore.unanswered} message notifications are waiting for a reply.", "${NotifStore.unanswered} پیام منتظر پاسخ است.")
        if (has("search messages", "جستجوی پیام")) { val q = t.substringAfter("for ").substringAfter("پیام").trim(); val hits = synchronized(NotifStore.items) { NotifStore.items.filter { q.isNotBlank() && (it.text + it.title).lowercase().contains(q) } }
            return if (hits.isEmpty()) r("Nothing found in recent notifications.", "چیزی در اعلان‌های اخیر نبود.") else hits.take(3).joinToString(". ") { "${it.title}: ${it.text.take(60)}" } }
        if (has("reply saying", "reply with", "reply to last", "پاسخ بده", "جواب بده")) { val txt = raw.substringAfter("saying").substringAfter("with").substringAfter("بده").trim(' ', ':', '،')
            if (NotifStore.lastAction == null) return r("No message I can reply to right now.", "پیامی برای پاسخ دادن نیست.")
            return Confirm.ask(fa, "Send to ${NotifStore.lastSender}: “$txt”", "ارسال به ${NotifStore.lastSender}: «$txt»") { if (NotifStore.sendReply(c, txt)) (if (fa) "ارسال شد." else "Sent.") else (if (fa) "ارسال نشد." else "Could not send.") } }
        if (has("find contact", "شماره ", "number of")) { val n = t.replace(Regex("find contact|number of|شماره"), "").trim(); if (!granted(c)) return noPerm; return findContact(c, n)?.let { "${it.first}: ${it.second}" } ?: r("Contact not found.", "مخاطب پیدا نشد.") }
        if (has("call ", "تماس با", "زنگ بزن")) { val n = t.replace(Regex("^(please\\s+)?call\\s+"), "").replace(Regex("تماس با|زنگ بزن به|زنگ بزن"), "").trim()
            val ct = findContact(c, n); Router.open(c, "Dialer", Intent(Intent.ACTION_DIAL, if (ct != null) Uri.parse("tel:${ct.second}") else Uri.parse("tel:")))
            return if (ct != null) r("Dialer ready for ${ct.first}. Press call to confirm.", "شماره‌گیر برای ${ct.first} آماده است؛ برای تماس دکمه را بزنید.") else if (!granted(c)) "$noPerm ${r("Opened the dialer.", "شماره‌گیر باز شد.")}" else r("Contact not found; opened the dialer.", "مخاطب نبود؛ شماره‌گیر باز شد.") }
        if (has("message ", "text ", "sms", "پیام بده", "پیام به", "whatsapp ")) {
            val m = Regex("(?i)(?:message|text|sms|whatsapp)\\s+(.+?)\\s+(?:saying|that|:)\\s+(.+)").find(raw) ?: Regex("پیام(?: بده)?(?: به)?\\s+(.+?)\\s+(?:که|:)\\s+(.+)").find(raw)
            val who = m?.groupValues?.get(1) ?: raw.replace(Regex("(?i)message|text|sms|whatsapp|پیام بده به|پیام به"), "").trim(); val body = m?.groupValues?.get(2) ?: ""
            val ct = findContact(c, who)
            if (has("whatsapp") && ct != null) { Router.open(c, "WhatsApp", Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${ct.second.filter { it.isDigit() }}?text=${Uri.encode(body)}"))); return r("WhatsApp chat ready; press send.", "واتساپ آماده است؛ ارسال را بزنید.") }
            Router.open(c, "Messages", Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${ct?.second ?: ""}")).putExtra("sms_body", body))
            return if (ct == null && !granted(c)) "$noPerm ${r("Opened messages.", "پیامک باز شد.")}" else r("Message to ${ct?.first ?: who} is ready; press send to confirm.", "پیام برای ${ct?.first ?: who} آماده است؛ برای ارسال تأیید کنید.") }
        return null
    }
}
