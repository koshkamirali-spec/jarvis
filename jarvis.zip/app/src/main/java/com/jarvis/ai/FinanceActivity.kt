package com.jarvis.ai
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import android.widget.LinearLayout

class BarChartView(c: Context, private val data: List<Triple<String, Double, Double?>>) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        if (data.isEmpty()) { p.color = Ui.WHITE; p.textSize = 36f; cv.drawText("No expenses this month", 20f, height / 2f, p); return }
        val max = data.maxOf { maxOf(it.second, it.third ?: 0.0) }.coerceAtLeast(1.0); val rowH = height / data.size.toFloat(); val left = width * 0.28f
        data.forEachIndexed { i, d ->
            val y = i * rowH; p.color = Ui.WHITE; p.textSize = rowH * 0.34f; cv.drawText(d.first.take(10), 8f, y + rowH * 0.62f, p)
            val over = d.third != null && d.second > d.third!!; p.color = if (over) 0xFFFF5252.toInt() else Ui.PURPLE
            cv.drawRect(left, y + rowH * 0.2f, left + (width - left - 16f) * (d.second / max).toFloat(), y + rowH * 0.8f, p)
            d.third?.let { b -> p.color = Ui.GOLD; val x = left + (width - left - 16f) * (b / max).toFloat(); cv.drawRect(x - 3f, y + rowH * 0.1f, x + 3f, y + rowH * 0.9f, p) }
        }
    }
}

/** Manual finance organizer: expenses, income, budgets and a chart. It never moves money. */
class FinanceActivity : GuardedActivity() {
    private lateinit var box: LinearLayout
    override fun build() {
        val r = Ui.screen(this, "💳 Finance"); val fa = Lang.fa(this)
        r.addView(Ui.text(this, Fin.report(this, fa), 14, Ui.CYAN))
        val budgets = Store.list(this, "budget").associate { it.substringBefore("|") to it.substringAfter("|").toDoubleOrNull() }
        val cats = Fin.byCategory(this).entries.sortedByDescending { it.value }.take(8).map { Triple(it.key, it.value, budgets[it.key]) }
        r.addView(BarChartView(this, cats), LinearLayout.LayoutParams(-1, Ui.dp(this, 36 * maxOf(cats.size, 3))))
        val amt = Ui.edit(this, "Amount"); amt.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL; val cat = Ui.edit(this, "Category (food, rent…)")
        r.addView(amt); r.addView(cat)
        fun add(type: String) { val a = amt.text.toString().toDoubleOrNull() ?: return Ui.toast(this, "Enter an amount"); Store.push(this, "fin", "${System.currentTimeMillis()}|$type|${cat.text.toString().trim().ifEmpty { if (type == "inc") "income" else "other" }}|$a|"); recreate() }
        r.addView(Ui.button(this, "Add expense") { add("exp") }); r.addView(Ui.button(this, "Add income") { add("inc") })
        r.addView(Ui.button(this, "Set budget") { Ui.ask(this, "Category", "food") { c -> Ui.ask(this, "Monthly budget", "500") { v -> val n = v.toDoubleOrNull() ?: return@ask; val l = Store.list(this, "budget"); val i = l.indexOfFirst { it.startsWith("$c|") }; if (i >= 0) Store.replaceAt(this, "budget", i, "$c|$n") else Store.push(this, "budget", "$c|$n"); recreate() } } })
        r.addView(Ui.button(this, "Payment reminder (days)") { Ui.ask(this, "What to pay?", "rent") { w -> Ui.ask(this, "In how many days?", "5") { d -> Router.schedule(this, (d.toLongOrNull() ?: 1L) * 86_400_000L, "💳 Pay: $w"); Ui.toast(this, "Reminder set") } } })
        r.addView(Ui.text(this, "Recent (tap to delete)", 15, Ui.GOLD, true))
        val all = Store.list(this, "fin")
        all.withIndex().toList().takeLast(15).reversed().forEach { (i, e) -> val p = e.split("|")
            r.addView(Ui.card(this).also { c -> c.addView(Ui.text(this, "${if (p.getOrNull(1) == "inc") "＋" else "－"} ${p.getOrNull(3)}  ${p.getOrNull(2)}  ${java.text.SimpleDateFormat("MM-dd", java.util.Locale.US).format(java.util.Date(p[0].toLongOrNull() ?: 0))}", 14)); c.setOnClickListener { Store.removeAt(this, "fin", i); recreate() } }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 6 }) }
        r.addView(Ui.button(this, "AI advice for next month") { Thread { val s = Llm.ask(this, "Give 3 short, practical tips to improve my budget next month. Data: ${Fin.report(this, false)} Budgets: ${budgets}", withHistory = false, maxTokens = 300); runOnUiThread { r.addView(Ui.text(this, s, 14)) } }.start() })
    }
}
