package com.jarvis.ai
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.concurrent.CopyOnWriteArrayList
import org.json.JSONArray

/** The single shared brain: every entry point (voice service, mic button, text box, widget, lock screen) calls Brain.process. */
object Brain {
    enum class St { IDLE, LISTENING, THINKING, SPEAKING }
    @Volatile var state = St.IDLE
    @Volatile var cancelled = false
    val listeners = CopyOnWriteArrayList<(St) -> Unit>()
    fun set(s: St) { state = s; listeners.forEach { it(s) } }

    /** Blocking: call from a background thread. */
    fun process(c: Context, raw: String): String {
        val text = raw.trim(); set(St.THINKING)
        val reply = try {
            Confirm.handle(c, text.lowercase()) ?: run(c, text)
        } catch (e: Exception) { ErrorLog.e(c, "brain", e); if (Lang.fa(c, text)) "خطایی رخ داد." else "Something went wrong." }
        Store.add(c, "user", text); Store.add(c, "assistant", reply)
        set(St.IDLE); return reply
    }
    private fun run(c: Context, text: String): String {
        val tl = text.lowercase(); val fa = Lang.fa(c, text)
        if (tl.contains("interpreter mode off") || tl.contains("مترجم زنده خاموش")) { Store.setBool(c, "interp", false); return if (fa) "مترجم زنده خاموش شد." else "Interpreter off." }
        if (tl.contains("interpreter mode on") || tl.contains("مترجم زنده روشن")) { Store.setBool(c, "interp", true); return if (fa) "مترجم زنده روشن شد؛ هر چه بگویید ترجمه می‌کنم. برای خروج بگویید «مترجم زنده خاموش»." else "Interpreter on: I translate everything you say (Persian ⇄ English). Say “interpreter mode off” to stop." }
        if (Store.bool(c, "interp")) return Llm.ask(c, "Translate between Persian and English (Persian to English, English to Persian). Output only the translation:\n$text", withHistory = false, maxTokens = 220)
        if (Logic.wantsPlan(tl)) return aiPlan(c, text)
        Custom.match(c, text.lowercase())?.let { return Planner.run(c, it) }
        val steps = Logic.split(text)
        return if (steps.size > 1) Planner.run(c, steps) else step(c, text)
    }
    /** Complex request -> the model proposes up to 5 short commands -> you see them and confirm -> each runs through the same router. */
    private fun aiPlan(c: Context, text: String): String {
        val fa = Lang.fa(c, text)
        val raw = Llm.ask(c, "Convert this request into at most 5 short voice commands a phone assistant understands (examples: open camera; set timer 10 minutes; add task buy milk; remind me in 30 minutes to call mom; navigate to home; play music; open instagram). Output ONLY a JSON array of strings.\nRequest: $text", withHistory = false, maxTokens = 200)
        val steps = try { val a = JSONArray(raw.substring(raw.indexOf('['), raw.lastIndexOf(']') + 1)); (0 until a.length()).map { a.getString(it) }.take(5) } catch (e: Exception) { emptyList() }
        if (steps.isEmpty()) return if (fa) "نتوانستم مراحل را بسازم." else "I couldn't build a plan."
        return Confirm.ask(fa, "Plan: ${steps.joinToString(" → ")}", "برنامه: ${steps.joinToString(" ← ")}") { Planner.run(c, steps) }
    }
    fun step(c: Context, text: String): String {
        Router.handle(c, text)?.let { return it }
        val search = Logic.needsSearch(text)
        return Llm.ask(c, text, search = search, extra = Ctx.build(c, text), maxTokens = if (search) 420 else 260)
    }
}

/** Multi-step commands: runs steps in order, shows progress, can be cancelled from the notification. */
object Planner {
    fun run(c: Context, steps: List<String>): String {
        Brain.cancelled = false; Notif.channels(c)
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        val out = StringBuilder()
        steps.forEachIndexed { i, s ->
            if (Brain.cancelled) { out.append("\n⛔ cancelled"); return@forEachIndexed }
            nm.notify(41, android.app.Notification.Builder(c, Notif.CH_SVC).setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("JARVIS ${i + 1}/${steps.size}").setContentText(s)
                .addAction(android.app.Notification.Action.Builder(null, "Cancel", PendingIntent.getBroadcast(c, 41, Intent(c, CancelReceiver::class.java), PendingIntent.FLAG_IMMUTABLE)).build()).build())
            val r = try { Brain.step(c, s) } catch (e: Exception) { ErrorLog.e(c, "plan", e); "error" }
            out.append("${i + 1}. $s → $r\n"); if (i < steps.size - 1) Thread.sleep(700)
        }
        nm.cancel(41); return out.toString().trim()
    }
}

/** Sensitive actions wait for an explicit "yes". */
object Confirm {
    private var action: (() -> String)? = null; private var until = 0L
    fun ask(fa: Boolean, en: String, f: String, a: () -> String): String {
        action = a; until = System.currentTimeMillis() + 30_000
        return if (fa) "$f — بگو «بله» یا «نه»." else "$en — say yes or no."
    }
    fun handle(c: Context, t: String): String? {
        val a = action ?: return null
        if (System.currentTimeMillis() > until) { action = null; return null }
        val fa = Lang.fa(c, t)
        if (listOf("yes", "yeah", "confirm", "ok", "بله", "آره", "تایید", "تأیید").any { t == it || t.startsWith("$it ") }) { action = null; return a() }
        if (listOf("no", "cancel", "stop", "نه", "لغو").any { t == it || t.startsWith("$it ") }) { action = null; return if (fa) "لغو شد." else "Cancelled." }
        return null
    }
}

/** User-defined commands/scenarios. Stored as "phrase=>step1;;step2". */
object Custom {
    fun match(c: Context, t: String): List<String>? {
        for (e in Store.list(c, "cmds")) {
            val p = e.substringBefore("=>").trim().lowercase(); if (p.isEmpty() || !e.contains("=>")) continue
            if (t == p || t.contains(p)) return e.substringAfter("=>").split(";;").map { it.trim() }.filter { it.isNotEmpty() }
        }
        return null
    }
}

/** Adds only the relevant personal data to the LLM prompt (token-light). */
object Ctx {
    fun build(c: Context, text: String): String {
        val t = text.lowercase(); val sb = StringBuilder()
        fun has(vararg k: String) = k.any { t.contains(it) }
        if (has("plan", "schedule", "report", "priorit", "overdue", "برنامه", "گزارش", "اولویت", "عقب")) {
            sb.append("User tasks: ${Store.list(c, "tasks").joinToString("; ")}. Goals: ${Store.list(c, "goals").joinToString("; ")}. Habits: ${Store.list(c, "habits").joinToString("; ")}. Done: ${Store.list(c, "done").takeLast(10).joinToString("; ")}.\n") }
        if (has("suggest", "recommend", "پیشنهاد")) sb.append("User favorites: ${Store.list(c, "favs").joinToString("; ")}; favorite games: ${Store.list(c, "games_fav").joinToString("; ")}.\n")
        if (has("notification", "اعلان")) sb.append("Recent notifications (app|title|text): ${NotifStore.digest(15)}. Categorize, flag important ones, keep it short.\n")
        if (has("categor", "genre", "دسته")) sb.append("Installed games: ${Games.installed(c).joinToString(", ")}.\n")
        if (has("translate", "ترجمه")) sb.append("Translate between Persian and English automatically; output only the translation.\n")
        if (has("quiz", "exam", "آزمون", "study plan", "برنامه مطالعه", "practice", "تمرین مکالمه", "summarize book", "خلاصه کتاب")) sb.append("Study log: ${Store.list(c, "study").takeLast(10).joinToString("; ")}. Teach interactively, ask one question at a time.\n")
        if (has("draft", "پیش‌نویس", "پیش نویس")) sb.append("Write only the message text, ready to send.\n")
        return sb.toString()
    }
}
