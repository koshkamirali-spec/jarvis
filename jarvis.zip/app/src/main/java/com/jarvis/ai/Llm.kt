package com.jarvis.ai
import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

/** Gemini brain. Direct (API key on device, stored encrypted) or via your own backend (key stays on the server). */
object Llm {
    fun system(c: Context, extra: String): String {
        val mem = Store.list(c, "memory").takeLast(10); val user = Store.str(c, "user_name")
        return buildString {
            append("You are ${Store.str(c, "ai_name", "JARVIS")}, a personal AI assistant on the user's phone. Reply in the language of the user's last message (Persian incl. colloquial, or English). ")
            append("Be concise: at most 2 short sentences unless asked for detail. You cannot control the phone yourself; never claim you performed an action. If a request is ambiguous ask ONE short question. If information may be outdated or unreliable, say so. ")
            if (user.isNotBlank()) append("User's name: $user. ")
            append(Modes.prompt(c))
            if (mem.isNotEmpty()) append(" Known about user: ${mem.joinToString("; ")}.")
            append(" Now: ${SimpleDateFormat("EEEE yyyy-MM-dd HH:mm", Locale.US).format(Date())}.")
            if (extra.isNotBlank()) append("\n$extra")
        }
    }
    private fun scaled(b: Bitmap): ByteArray {
        val s = 1024f / maxOf(b.width, b.height); val m = if (s < 1f) Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true) else b
        return ByteArrayOutputStream().also { m.compress(Bitmap.CompressFormat.JPEG, 75, it) }.toByteArray()
    }
    private fun inline(mime: String, bytes: ByteArray) = JSONObject().put("inline_data", JSONObject().put("mime_type", mime).put("data", Base64.encodeToString(bytes, Base64.NO_WRAP)))
    private fun txt(t: String) = JSONObject().put("text", t)

    fun ask(c: Context, text: String, image: Bitmap? = null, withHistory: Boolean = true, search: Boolean = false,
            file: Pair<String, ByteArray>? = null, extra: String = "", maxTokens: Int = 260, images: List<Bitmap> = emptyList(), attempt: Int = 0): String {
        val fa = Lang.fa(c, text)
        val key = Store.apiKey(c); val backend = Store.str(c, "backend").trim().trimEnd('/')
        if (key.isEmpty() && backend.isEmpty()) return if (fa) "ابتدا کلید Gemini را در تنظیمات وارد کنید." else "Please add your Gemini API key in Settings."
        if (!Net.online(c)) return if (fa) "اینترنت متصل نیست." else "No internet connection."
        return try {
            val contents = JSONArray(); var last = "model"
            if (withHistory) for ((r, t) in Store.recent(c, 6)) { val role = if (r == "user") "user" else "model"
                if (role != last && !(contents.length() == 0 && role == "model")) { contents.put(JSONObject().put("role", role).put("parts", JSONArray().put(txt(t)))); last = role } }
            if (last == "user") contents.remove(contents.length() - 1)
            val parts = JSONArray()
            image?.let { parts.put(inline("image/jpeg", scaled(it))) }; images.forEach { parts.put(inline("image/jpeg", scaled(it))) }
            file?.let { parts.put(inline(it.first, it.second)) }
            parts.put(txt(text)); contents.put(JSONObject().put("role", "user").put("parts", parts))
            val body = JSONObject().put("systemInstruction", JSONObject().put("parts", JSONArray().put(txt(system(c, extra)))))
                .put("contents", contents).put("generationConfig", JSONObject().put("maxOutputTokens", maxTokens).put("temperature", 0.7))
            if (search) body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            val model = Store.str(c, "model", "gemini-2.5-flash")
            val con = URL(if (backend.isNotEmpty()) "$backend/gemini?model=$model" else "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection
            con.requestMethod = "POST"; con.doOutput = true; con.connectTimeout = 12000; con.readTimeout = 60000
            con.setRequestProperty("content-type", "application/json")
            if (backend.isNotEmpty()) con.setRequestProperty("x-app-token", Store.secret(c, "backend_token")) else con.setRequestProperty("x-goog-api-key", key)
            con.outputStream.use { it.write(body.toString().toByteArray()) }
            val ok = con.responseCode in 200..299
            val resp = (if (ok) con.inputStream else con.errorStream)?.bufferedReader()?.readText() ?: ""
            if (!ok) { ErrorLog.e(c, "llm", RuntimeException("HTTP ${con.responseCode}")); return (if (fa) "خطای سرویس هوش مصنوعی: " else "AI service error: ") + con.responseCode }
            parse(resp, fa, search)
        } catch (e: Exception) { ErrorLog.e(c, "llm", e)
            if (e is java.io.IOException && attempt == 0) { Thread.sleep(1200); return ask(c, text, image, withHistory, search, file, extra, maxTokens, images, 1) }
            if (fa) "خطا در ارتباط با هوش مصنوعی." else "Could not reach the AI service." }
    }
    private fun parse(resp: String, fa: Boolean, search: Boolean): String {
        val j = JSONObject(resp); val cand = j.optJSONArray("candidates")?.optJSONObject(0)
            ?: return if (fa) "پاسخی دریافت نشد (ممکن است مسدود شده باشد)." else "No answer (it may have been blocked)."
        val ps = cand.optJSONObject("content")?.optJSONArray("parts") ?: return if (fa) "پاسخ خالی بود." else "Empty answer."
        val sb = StringBuilder(); for (i in 0 until ps.length()) sb.append(ps.getJSONObject(i).optString("text"))
        if (search) cand.optJSONObject("groundingMetadata")?.optJSONArray("groundingChunks")?.let { ch ->
            val src = (0 until minOf(ch.length(), 3)).mapNotNull { ch.getJSONObject(it).optJSONObject("web")?.let { w -> "${w.optString("title")} ${w.optString("uri")}" } }
            if (src.isNotEmpty()) sb.append("\n\n" + (if (fa) "منابع:" else "Sources:") + "\n" + src.joinToString("\n")) }
        return sb.toString().trim()
    }
}

object Net {
    fun online(c: Context): Boolean {
        val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        if (Store.bool(c, "wifi_only") && caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR) && !caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)) return false
        return caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
    fun get(url: String, ms: Int = 12000): String { val con = URL(url).openConnection() as HttpURLConnection; con.connectTimeout = ms; con.readTimeout = ms; con.setRequestProperty("User-Agent", "Mozilla/5.0"); return con.inputStream.bufferedReader().readText() }
}
