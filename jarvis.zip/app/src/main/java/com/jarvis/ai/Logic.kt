package com.jarvis.ai
sealed class ModeRule {
    data class Time(val a: Int, val b: Int) : ModeRule(); data class Wifi(val ssid: String) : ModeRule(); object Charging : ModeRule(); data class Bt(val name: String) : ModeRule()
}
/** Pure logic (no Android imports) so it is unit-testable on the JVM. */
object Logic {
    fun isPersian(s: String) = s.any { it in '\u0600'..'\u06FF' }
    fun digits(s: String): String = buildString {
        for (ch in s) append(when (ch) { in '\u06F0'..'\u06F9' -> '0' + (ch - '\u06F0'); in '\u0660'..'\u0669' -> '0' + (ch - '\u0660'); '٫' -> '.'; else -> ch })
    }
    private class P(val s: String) {
        var i = 0
        fun peek() = if (i < s.length) s[i] else '\u0000'
        fun ws() { while (peek() == ' ') i++ }
        fun expr(): Double { var v = term(); while (true) { ws(); when (peek()) { '+' -> { i++; v += term() }; '-' -> { i++; v -= term() }; else -> return v } } }
        fun term(): Double { var v = pow(); while (true) { ws(); when (peek()) { '*' -> { i++; v *= pow() }; '/' -> { i++; v /= pow() }; else -> return v } } }
        fun pow(): Double { val b = unary(); ws(); if (peek() == '^') { i++; return Math.pow(b, pow()) }; return b }
        fun unary(): Double { ws(); if (peek() == '-') { i++; return -unary() }; if (peek() == '+') { i++; return unary() }; return atom() }
        fun atom(): Double {
            ws()
            if (peek() == '(') { i++; val v = expr(); ws(); if (peek() == ')') i++ else throw IllegalArgumentException(); return v }
            val st = i; while (peek().isDigit() || peek() == '.') i++
            if (st == i) throw IllegalArgumentException(); return s.substring(st, i).toDouble()
        }
    }
    fun calc(expr: String): Double? {
        val e = digits(expr).lowercase().replace(Regex("(?<=\\d)\\s*x\\s*(?=\\d)"), "*").replace("×", "*").replace("÷", "/").replace(",", "")
        return try { val p = P(e); val v = p.expr(); p.ws(); if (p.i != e.length || v.isNaN() || v.isInfinite()) null else v } catch (ex: Exception) { null }
    }
    /** Finds "2+3*4" style text inside a sentence. */
    fun extractExpr(t: String): String? {
        val m = Regex("[\\d\\s+\\-*/x×÷^().]{3,}").findAll(digits(t)).map { it.value.trim() }.filter { it.any(Char::isDigit) && it.any { c -> c in "+-*/x×÷^" } }.maxByOrNull { it.length }
        return m
    }
    fun fmt(d: Double): String = if (d == Math.floor(d) && Math.abs(d) < 1e12) d.toLong().toString() else String.format(java.util.Locale.US, "%.4f", d).trimEnd('0').trimEnd('.')
    private val alias = mapOf("کیلومتر" to "km", "متر" to "m", "مایل" to "mile", "کیلو" to "kg", "گرم" to "g", "پوند" to "lb", "لیتر" to "l", "سانتیمتر" to "cm", "فوت" to "ft", "اینچ" to "inch",
        "miles" to "mile", "mi" to "mile", "feet" to "ft", "foot" to "ft", "in" to "inch", "inches" to "inch", "lbs" to "lb", "pounds" to "lb", "kilometers" to "km", "meters" to "m", "liter" to "l", "liters" to "l", "kmh" to "km/h", "celsius" to "c", "fahrenheit" to "f", "kelvin" to "k", "°c" to "c", "°f" to "f")
    private val tables: Map<String, Map<String, Double>> = mapOf(
        "len" to mapOf("mm" to .001, "cm" to .01, "m" to 1.0, "km" to 1000.0, "inch" to .0254, "ft" to .3048, "mile" to 1609.344, "yard" to .9144),
        "mass" to mapOf("g" to .001, "kg" to 1.0, "lb" to .45359237, "oz" to .0283495, "ton" to 1000.0),
        "vol" to mapOf("ml" to .001, "l" to 1.0, "gal" to 3.78541, "cup" to .236588),
        "speed" to mapOf("m/s" to 1.0, "km/h" to 1 / 3.6, "mph" to .44704))
    fun convert(text: String): String? {
        val m = Regex("(-?\\d+(?:\\.\\d+)?)\\s*([a-z/°\\u0600-\\u06FF]+)\\s*(?:to|in|into|به)\\s*([a-z/°\\u0600-\\u06FF]+)").find(digits(text).lowercase()) ?: return null
        val v = m.groupValues[1].toDouble()
        val a = alias[m.groupValues[2]] ?: m.groupValues[2]; val b = alias[m.groupValues[3]] ?: m.groupValues[3]
        if (a in listOf("c", "f", "k") && b in listOf("c", "f", "k")) {
            val c = when (a) { "c" -> v; "f" -> (v - 32) * 5 / 9; else -> v - 273.15 }
            val r = when (b) { "c" -> c; "f" -> c * 9 / 5 + 32; else -> c + 273.15 }
            return "${fmt(v)} $a = ${fmt(r)} $b"
        }
        for (t in tables.values) if (a in t && b in t) return "${fmt(v)} $a = ${fmt(v * t[a]!! / t[b]!!)} $b"
        return null
    }
    private val splitRe = Regex("\\s+(?:and then|then)\\s+|\\s*،?\\s*(?:و بعد|بعد از آن|سپس)\\s+|\\s*;\\s*", RegexOption.IGNORE_CASE)
    fun split(text: String): List<String> = text.split(splitRe).map { it.trim() }.filter { it.isNotEmpty() }
    /** "in 10 minutes", "after 2 hours", "۱۰ دقیقه" -> milliseconds */
    fun parseMillis(t: String): Long? {
        val m = Regex("(\\d+)\\s*(second|sec|ثانیه|minute|min|دقیقه|hour|ساعت)").find(digits(t).lowercase()) ?: return null
        val n = m.groupValues[1].toLong()
        return n * when (m.groupValues[2]) { "second", "sec", "ثانیه" -> 1000L; "hour", "ساعت" -> 3_600_000L; else -> 60_000L }
    }
    fun needsSearch(t: String): Boolean = listOf("news", "latest", "price", "compare", "search", "who is", "today", "weather", "score", "اخبار", "قیمت", "جستجو", "آخرین", "امروز", "مقایسه").any { t.lowercase().contains(it) }
    fun wantsPlan(t: String): Boolean = listOf("automate", "do the following", "plan and do", "do these steps", "کارهای زیر", "به ترتیب انجام بده", "مرحله به مرحله انجام").any { t.lowercase().contains(it) }
    fun parseRule(r: String): ModeRule? { val t = r.trim(); val l = t.lowercase()
        return when { t.isEmpty() -> null; l == "charging" -> ModeRule.Charging; l.startsWith("wifi:") -> ModeRule.Wifi(t.substring(5).trim()); l.startsWith("bt:") -> ModeRule.Bt(t.substring(3).trim())
            else -> Regex("^(\\d{1,2})-(\\d{1,2})$").matchEntire(t)?.let { ModeRule.Time(it.groupValues[1].toInt(), it.groupValues[2].toInt()) } } }
    fun inRange(h: Int, a: Int, b: Int) = if (a < b) h in a until b else h >= a || h < b
    fun urlIn(t: String): String? = Regex("https?://\\S+").find(t)?.value
}
