package com.jarvis.ai
import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/** Recorder & media manager. Recording starts only when you press the button and stays visible on screen. */
class MediaActivity : BaseActivity() {
    private var rec: MediaRecorder? = null; private var recFile: File? = null; private var player: MediaPlayer? = null
    private lateinit var status: TextView; private lateinit var box: LinearLayout; private lateinit var recBtn: android.widget.Button
    private val aDir get() = File(filesDir, "recordings").apply { mkdirs() }; private val vDir get() = File(filesDir, "videos").apply { mkdirs() }
    private var vFile: File? = null

    override fun onCreate(s: Bundle?) {
        super.onCreate(s); val r = Ui.screen(this, "🎧 Recorder & Media")
        status = Ui.text(this, "Ready.", 14, Ui.CYAN); r.addView(status)
        recBtn = Ui.button(this, "⏺ Start audio recording") { toggle() }; r.addView(recBtn)
        r.addView(Ui.button(this, "🎥 Record video") { vFile = File(vDir, "vid_${stamp()}.mp4"); startActivityForResult(Intent(MediaStore.ACTION_VIDEO_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, FileUris.of(this, vFile!!)).addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION), 1) })
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; r.addView(box); render()
    }
    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    @Deprecated("Deprecated in Java") override fun onActivityResult(req: Int, res: Int, d: Intent?) { super.onActivityResult(req, res, d); render() }
    private fun toggle() {
        if (rec != null) { stopRec(); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 4); return }
        try {
            val f = File(aDir, "rec_${stamp()}.aac"); val m = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
            m.setAudioSource(MediaRecorder.AudioSource.MIC); m.setOutputFormat(MediaRecorder.OutputFormat.AAC_ADTS); m.setAudioEncoder(MediaRecorder.AudioEncoder.AAC); m.setOutputFile(f.absolutePath); m.prepare(); m.start()
            rec = m; recFile = f; recBtn.text = "⏹ Stop recording"; status.text = "● Recording…"
        } catch (e: Exception) { ErrorLog.e(this, "rec", e); status.text = "Could not start recording."; rec = null }
    }
    private fun stopRec() { try { rec?.stop() } catch (_: Exception) {}; rec?.release(); rec = null; recBtn.text = "⏺ Start audio recording"; status.text = "Saved ${recFile?.name}"; render() }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) { if (c == 4 && r.firstOrNull() == PackageManager.PERMISSION_GRANTED) toggle() }
    override fun onDestroy() { if (rec != null) stopRec(); player?.release(); super.onDestroy() }

    private fun render() {
        box.removeAllViews(); box.addView(Ui.text(this, "Audio", 17, Ui.GOLD, true))
        val audio = aDir.listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList()
        if (audio.isEmpty()) box.addView(Ui.text(this, "(none)", 13))
        for (f in audio) { val c = Ui.card(this); c.addView(Ui.text(this, f.name, 14)); box.addView(c, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
            fun b(l: String, a: () -> Unit) = c.addView(Ui.button(this, l, a))
            b("▶ Play / stop") { play(f) }; b("📝 Transcribe") { ai(f, "Transcribe this audio exactly, in its original language.", 1500, false) }
            b("🧾 Summarize") { ai(f, "Summarize this audio in 3 short bullet points.", 300, false) }; b("🏷 Auto-name") { ai(f, "Give a short file name (max 4 words, no extension, letters/digits/underscore only) describing this audio. Output only the name.", 20, true) }
            b("📤 Share") { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("audio/aac").putExtra(Intent.EXTRA_STREAM, FileUris.of(this, f)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Share")) }
            b("🗑 Delete") { f.delete(); render() } }
        box.addView(Ui.text(this, "Video", 17, Ui.GOLD, true))
        val vids = vDir.listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList()
        if (vids.isEmpty()) box.addView(Ui.text(this, "(none)", 13))
        for (f in vids) { val c = Ui.card(this); c.addView(Ui.text(this, f.name, 14)); box.addView(c, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
            c.addView(Ui.button(this, "▶ Open") { startActivity(Intent(Intent.ACTION_VIEW, FileUris.of(this, f)).setDataAndType(FileUris.of(this, f), "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) })
            c.addView(Ui.button(this, "📤 Share") { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, FileUris.of(this, f)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Share")) })
            c.addView(Ui.button(this, "🗑 Delete") { f.delete(); render() }) }
    }
    private fun play(f: File) { if (player?.isPlaying == true) { player?.stop(); player?.release(); player = null; return }; player = MediaPlayer().apply { setDataSource(f.absolutePath); prepare(); start() } }
    private fun ai(f: File, task: String, tokens: Int, rename: Boolean) {
        status.text = "Working…"; Brain.set(Brain.St.THINKING)
        Thread {
            val r = Llm.ask(this, task, file = "audio/aac" to f.readBytes(), withHistory = false, maxTokens = tokens)
            Brain.set(Brain.St.IDLE)
            runOnUiThread {
                if (rename) { val n = r.trim().replace(Regex("[^A-Za-z0-9_]"), "_").take(40); if (n.isNotEmpty() && !r.startsWith("AI") && !r.contains(" ")) { f.renameTo(File(f.parentFile, "$n.aac")); status.text = "Renamed to $n.aac"; render() } else status.text = r }
                else { status.text = "Done."; Store.add(this, "assistant", r.take(500)); AlertDialog.Builder(this).setMessage(r).setPositiveButton("OK", null).show() }
            }
        }.start()
    }
}
