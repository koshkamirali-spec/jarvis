package com.jarvis.ai
import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Bundle
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Local commands first (zero tokens), each module guarded by its on/off switch. Returns null to fall through to the AI. */
object Router {
    fun handle(c: Context, text: String): String? {
        val t = text.lowercase().trim(); val fa = Lang.fa(c, text)
        fun m(id: String, f: () -> String?) = if (Store.moduleOn(c, id)) f() else null
        return Modes.handle(c, t, fa)
            ?: m("safety") { Safety.handle(c, t, fa) }
            ?: m("screens") { Screens.handle(c, t, fa) }
            ?: m("tools") { Tools.handle(c, t, text, fa) }
            ?: m("tools") { Memory.handle(c, t, text, fa) }
            ?: m("finance") { Fin.handle(c, t, fa) }
            ?: m("comms") { Comms.handle(c, t, text, fa) }
            ?: m("web") { Web.handle(c, t, text, fa) }
            ?: m("home") { Home.handle(c, t, fa) }
            ?: m("location") { Loc.handle(c, t, text, fa) }
            ?: m("games") { Games.handle(c, t, fa) }
            ?: m("phone") { Phone.handle(c, t, fa) }
    }

    fun schedule(c: Context, ms: Long, msg: String, alarm: Boolean = false, id: Int = (System.nanoTime() % 100000).toInt()) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(c, id, Intent(c, ReminderReceiver::class.java).putExtra("m", msg).putExtra("alarm", alarm), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        if (alarm) am.setAlarmClock(AlarmManager.AlarmClockInfo(System.currentTimeMillis() + ms, null), pi) // exact, needs no special permission
        else am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + ms, pi)
    }
    /** Android blocks activity launches from the background: when the app is not visible we also post a tap-to-open notification. */
    fun open(c: Context, label: String, i: Intent): Boolean {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        var ok = true
        try { c.startActivity(i) } catch (e: Exception) { ok = false; ErrorLog.e(c, "open:$label", e) }
        if (!App.visible || !ok) {
            Notif.channels(c)
            val pi = PendingIntent.getActivity(c, label.hashCode(), i, PendingIntent.FLAG_IMMUTABLE)
            (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(label.hashCode(),
                Notification.Builder(c, Notif.CH_ALERT).setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("JARVIS").setContentText("Tap to open: $label").setContentIntent(pi).setAutoCancel(true).build())
        }
        return ok
    }
}

object Notif {
    const val CH_SVC = "svc"; const val CH_ALERT = "alert"; const val CH_ALARM = "alarm"
    fun channels(c: Context) {
        val m = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        m.createNotificationChannel(NotificationChannel(CH_SVC, "JARVIS service", NotificationManager.IMPORTANCE_LOW))
        m.createNotificationChannel(NotificationChannel(CH_ALERT, "JARVIS alerts", NotificationManager.IMPORTANCE_HIGH))
        m.createNotificationChannel(NotificationChannel(CH_ALARM, "JARVIS alarms", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build()) })
    }
}
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Notif.channels(c); val alarm = i.getBooleanExtra("alarm", false)
        val n = Notification.Builder(c, if (alarm) Notif.CH_ALARM else Notif.CH_ALERT).setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle("JARVIS").setContentText(i.getStringExtra("m")).setAutoCancel(true).build()
        if (alarm) n.flags = n.flags or Notification.FLAG_INSISTENT
        (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(System.currentTimeMillis().toInt(), n)
    }
}
class CancelReceiver : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) { Brain.cancelled = true } }

object Speaker {
    private var tts: TextToSpeech? = null; private var ready = false; private var cb: (() -> Unit)? = null; private var pending: Pair<Context, String>? = null
    fun speak(c: Context, text: String, onDone: () -> Unit = {}) {
        cb = onDone; val t = text.take(420)
        if (tts == null) { pending = c to t; tts = TextToSpeech(c.applicationContext) { s ->
            if (s == TextToSpeech.SUCCESS) { ready = true
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) { Brain.set(Brain.St.SPEAKING) }
                    override fun onDone(id: String?) { Brain.set(Brain.St.IDLE); cb?.invoke() }
                    @Deprecated("Deprecated in Java") override fun onError(id: String?) { Brain.set(Brain.St.IDLE); cb?.invoke() } })
                pending?.let { say(it.first, it.second) } } else onDone() } }
        else if (ready) say(c, t) else onDone()
    }
    private fun say(c: Context, t: String) {
        val e = tts ?: return
        val loc = if (Logic.isPersian(t)) Locale("fa", "IR") else Store.str(c, "lang").ifBlank { "en-US" }.let { if (it.startsWith("fa")) Locale.US else Locale.forLanguageTag(it) }
        e.setLanguage(loc)
        e.setSpeechRate(Store.int(c, "tts_rate", 100) / 100f); e.setPitch(Store.int(c, "tts_pitch", 100) / 100f)
        e.speak(t, TextToSpeech.QUEUE_FLUSH, Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, Store.int(c, "tts_vol", 100) / 100f) }, "j")
    }
    fun stop() { tts?.stop(); Brain.set(Brain.St.IDLE) }
}
