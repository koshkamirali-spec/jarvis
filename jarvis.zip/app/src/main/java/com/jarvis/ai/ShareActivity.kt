package com.jarvis.ai
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.*
import android.widget.TextView

/** Screen Intelligence: share a screenshot/text/URL to JARVIS (no overlay, no capture service). */
class ShareActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val tv = TextView(this).apply { setPadding(48, 48, 48, 48); textSize = 16f; text = "..." }; setContentView(tv)
        val txt = intent.getStringExtra(Intent.EXTRA_TEXT)
        val uri: Uri? = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java) else @Suppress("DEPRECATION") intent.getParcelableExtra(Intent.EXTRA_STREAM)
        Thread {
            var bmp: Bitmap? = null
            if (uri != null) try {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                val ss = maxOf(1, maxOf(o.outWidth, o.outHeight) / 1024)
                bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = ss }) }
            } catch (_: Exception) {}
            val q = "Explain or summarize this briefly; translate if foreign; extract key info." + (txt?.let { "\n$it" } ?: "")
            val r = Llm.ask(this, q, bmp, withHistory = false)
            Store.add(this, "user", "[shared] " + (txt ?: "image")); Store.add(this, "assistant", r)
            runOnUiThread { tv.text = r; Speaker.speak(this, r) }
        }.start()
    }
}
