package com.jarvis.ai
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.*
import android.content.ClipData
import java.io.File

/** Smart Camera + Visual Intelligence + Smart Gallery. The photo is analyzed by Gemini only when YOU take/pick it. */
class VisionActivity : BaseActivity() {
    private val prompts = linkedMapOf(
        "identify" to "Identify the main objects, items or devices in the image and explain briefly what each is used for.",
        "ocr" to "Extract ALL text from the image exactly as written (OCR). Keep line breaks.",
        "translate" to "Extract the text in the image and translate it between Persian and English (to the other language).",
        "plant" to "Identify the plant (common and scientific name) and give short care tips.",
        "animal" to "Identify the animal or breed and give 2 short facts.",
        "product" to "Identify the product: type, probable brand and model (say if unsure) and what it is used for.",
        "food" to "Identify the food or ingredients visible and estimate nothing beyond what is visible; mention common allergens.",
        "document" to "Analyze this document: type, key information, important dates and numbers.",
        "invoice" to "Extract invoice/receipt data as a short list: vendor, date, items, subtotal, tax, total.",
        "signs" to "Read and explain any road sign, sign board or symbol in the image.",
        "surroundings" to "Describe the surroundings for a person who may not see well: layout, people, objects, text and possible hazards.",
        "book" to "Transcribe the book page text, then summarize it in two sentences.",
        "compare" to "Compare the images: key similarities and differences.",
        "gallery" to "Briefly describe and tag each image (one line each).")
    private var mode = "identify"; private val pics = mutableListOf<Bitmap>(); private lateinit var out: TextView; private lateinit var preview: ImageView; private lateinit var modeTv: TextView
    private lateinit var camFile: File; private var last = ""

    override fun onCreate(s: Bundle?) {
        super.onCreate(s); mode = intent.getStringExtra("mode") ?: "identify"; if (mode !in prompts) mode = "identify"
        val r = Ui.screen(this, "📷 Smart Camera")
        modeTv = Ui.text(this, "", 15, Ui.CYAN); r.addView(modeTv)
        val hs = HorizontalScrollView(this); val row = LinearLayout(this); hs.addView(row); r.addView(hs)
        for (m in prompts.keys) row.addView(Button(this).apply { text = m; isAllCaps = false; setOnClickListener { mode = m; pics.clear(); upd() } })
        r.addView(Ui.button(this, "📸 Take photo") { shoot() })
        r.addView(Ui.button(this, "🖼 Pick from gallery (multiple allowed)") { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*").putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true), 2) })
        preview = ImageView(this).apply { adjustViewBounds = true; maxHeight = Ui.dp(this@VisionActivity, 220) }; r.addView(preview)
        out = Ui.text(this, "", 15); r.addView(out)
        r.addView(Ui.button(this, "🔎 Search the web about this") { if (last.isBlank()) return@button Ui.toast(this, "Analyze something first"); run("Find reliable information (and typical prices if it is a product) about: ${last.take(300)}", true) })
        upd()
    }
    private fun upd() { modeTv.text = "Mode: $mode" + if (mode == "compare") " (needs 2 photos: ${pics.size}/2)" else ""; preview.setImageBitmap(pics.firstOrNull()) }
    private fun shoot() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.CAMERA), 3); return }
        camFile = File(cacheDir, "images/cap.jpg").also { it.parentFile?.mkdirs() }
        val uri = FileUris.of(this, camFile)
        startActivityForResult(Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, uri).addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION), 1)
    }
    private fun decode(u: Uri): Bitmap? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }; contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
        contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = maxOf(1, maxOf(o.outWidth, o.outHeight) / 1280) }) }
    } catch (e: Exception) { ErrorLog.e(this, "decode", e); null }
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, d: Intent?) {
        super.onActivityResult(req, res, d); if (res != RESULT_OK) return
        if (req == 1) decode(Uri.fromFile(camFile))?.let { pics.add(it) }
        if (req == 2) { val cd: ClipData? = d?.clipData; if (cd != null) for (i in 0 until minOf(cd.itemCount, 4)) decode(cd.getItemAt(i).uri)?.let { pics.add(it) } else d?.data?.let { u -> decode(u)?.let { pics.add(it) } } }
        upd(); if (pics.isEmpty()) return
        if (mode == "compare" && pics.size < 2) { out.text = "Add the second photo to compare."; return }
        run(prompts[mode]!!, false)
    }
    private fun run(task: String, search: Boolean) {
        out.text = "Analyzing…"; Brain.set(Brain.St.THINKING); val fa = Lang.fa(this); val imgs = pics.toList()
        Thread {
            val r = Llm.ask(this, "$task Reply in ${if (fa) "Persian" else "English"}, concise.", image = imgs.firstOrNull(), images = imgs.drop(1), withHistory = false, search = search, maxTokens = 600)
            Store.add(this, "user", "[camera:$mode]"); Store.add(this, "assistant", r); last = r; Brain.set(Brain.St.IDLE)
            runOnUiThread { out.text = r; if (Store.bool(this, "vision_speak", true)) Speaker.speak(this, r) }
        }.start()
    }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) { if (c == 3 && r.firstOrNull() == PackageManager.PERMISSION_GRANTED) shoot() }
}
