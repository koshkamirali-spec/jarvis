package com.jarvis.ai
import android.Manifest
import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.TextView
import java.util.Locale

object EmergencySound {
    private var rt: Ringtone? = null
    fun start(c: Context) {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager; am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
        rt?.stop(); rt = RingtoneManager.getRingtone(c, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)).apply { audioAttributes = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build(); isLooping = true; play() }
    }
    fun stop() { rt?.stop(); rt = null }
    val on get() = rt?.isPlaying == true
}

object Loc {
    fun last(c: Context): Location? {
        if (c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && c.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return null
        val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return lm.getProviders(true).mapNotNull { try { lm.getLastKnownLocation(it) } catch (e: SecurityException) { null } }.maxByOrNull { it.time }
    }
    fun link(l: Location) = "https://maps.google.com/?q=${l.latitude},${l.longitude}"
    fun handle(c: Context, t: String, raw: String, fa: Boolean): String? {
        fun has(vararg k: String) = k.any { t.contains(it) }
        fun r(en: String, f: String) = if (fa) f else en
        val noLoc = r("Allow Location permission in JARVIS Settings > Permissions.", "مجوز مکان را در تنظیمات جارویس بدهید.")
        if (has("where am i", "my location", "من کجا", "موقعیت من")) { val l = last(c) ?: return noLoc
            val addr = try { if (Geocoder.isPresent()) @Suppress("DEPRECATION") Geocoder(c, Locale.getDefault()).getFromLocation(l.latitude, l.longitude, 1)?.firstOrNull()?.getAddressLine(0) else null } catch (e: Exception) { null }
            return addr ?: "%.5f, %.5f".format(l.latitude, l.longitude) }
        if (has("save this place", "save place", "ذخیره مکان", "این مکان را ذخیره")) { val l = last(c) ?: return noLoc; val n = raw.replace(Regex("(?i)save this place as|save place|ذخیره مکان|این مکان را ذخیره کن|as"), "").trim(' ', ':', '،').ifEmpty { "place ${Store.list(c, "places").size + 1}" }
            Store.push(c, "places", "$n|${l.latitude}|${l.longitude}"); return r("Saved “$n”.", "«$n» ذخیره شد.") }
        if (has("my places", "saved places", "مکان‌های من", "مکان های من")) return Store.list(c, "places").map { it.substringBefore("|") }.ifEmpty { listOf(r("No saved places.", "مکانی ذخیره نشده.")) }.joinToString("، ")
        if (has("navigate to", "directions to", "take me to", "مسیریابی به", "مسیر به", "برو به")) { val n = t.replace(Regex("navigate to|directions to|take me to|مسیریابی به|مسیر به|برو به"), "").trim()
            val p = Store.list(c, "places").firstOrNull { it.substringBefore("|").lowercase() == n }?.split("|")
            val uri = if (p != null && p.size >= 3) Uri.parse("google.navigation:q=${p[1]},${p[2]}") else Uri.parse("google.navigation:q=${Uri.encode(n)}")
            Router.open(c, "Navigation", Intent(Intent.ACTION_VIEW, uri)); return r("Starting navigation to $n. Maps shows the arrival time.", "مسیریابی به $n شروع شد؛ زمان رسیدن در نقشه است.") }
        if (has("share my location", "send my location", "موقعیتم را بفرست", "اشتراک موقعیت")) { val l = last(c) ?: return noLoc
            return Confirm.ask(fa, "Share your location", "موقعیت شما به اشتراک گذاشته شود") { Router.open(c, "Share location", Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, "My location: ${link(l)}"), "Share location").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); if (fa) "انتخاب برنامه باز شد." else "Pick an app to send it." } }
        if (has("when i arrive", "when i get to", "وقتی رسیدم", "وقتی به")) { if (c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return noLoc
            val p = Store.list(c, "places").map { it.split("|") }.firstOrNull { it.size >= 3 && t.contains(it[0].lowercase()) } ?: return r("Save that place first: “save place <name>” while you're there.", "ابتدا مکان را ذخیره کنید: «ذخیره مکان …».")
            val what = raw.substringAfter("to ", "").ifBlank { raw }
            val pi = PendingIntent.getBroadcast(c, p[0].hashCode(), Intent(c, ReminderReceiver::class.java).putExtra("m", "📍 ${p[0]}: $what"), PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            return try { (c.getSystemService(Context.LOCATION_SERVICE) as LocationManager).addProximityAlert(p[1].toDouble(), p[2].toDouble(), 150f, -1, pi); r("I'll remind you when you reach ${p[0]}.", "وقتی به ${p[0]} برسید یادآوری می‌کنم.") } catch (e: SecurityException) { noLoc } }
        return null
    }
}

object Journey {
    fun active(c: Context) = Store.str(c, "journey").isNotEmpty()
    fun start(c: Context, dest: String, ms: Long) {
        Store.setStr(c, "journey", "$dest|${System.currentTimeMillis() + ms}")
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + ms + 5 * 60_000L, PendingIntent.getBroadcast(c, 5001, Intent(c, SafetyReceiver::class.java).setAction("ARRIVAL_CHECK"), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        watch(c)
    }
    fun arrive(c: Context) { Store.setStr(c, "journey", ""); (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(PendingIntent.getBroadcast(c, 5001, Intent(c, SafetyReceiver::class.java).setAction("ARRIVAL_CHECK"), PendingIntent.FLAG_IMMUTABLE)) }
    private var cb: ConnectivityManager.NetworkCallback? = null
    /** Warns when the connection drops during a journey (while JARVIS is running). */
    fun watch(c: Context) {
        if (cb != null) return; val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        cb = object : ConnectivityManager.NetworkCallback() { override fun onLost(n: Network) { if (active(c)) SafetyReceiver.notify(c, 5003, "⚠ Connection lost during your journey", "Tap if you need help.", help = true) } }
        cm.registerDefaultNetworkCallback(cb!!)
    }
    fun unwatch(c: Context) { cb?.let { try { (c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(it) } catch (e: Exception) {} }; cb = null }
}

object Check {
    fun start(c: Context, hours: Int) { Store.setInt(c, "check_h", hours); Store.setBool(c, "check_pending", false); next(c) }
    fun stop(c: Context) { Store.setInt(c, "check_h", 0); (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi(c)) }
    fun next(c: Context) { val h = Store.int(c, "check_h"); if (h <= 0) return; (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + h * 3_600_000L, pi(c)) }
    private fun pi(c: Context) = PendingIntent.getBroadcast(c, 5002, Intent(c, SafetyReceiver::class.java).setAction("CHECK"), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
}

class SafetyReceiver : BroadcastReceiver() {
    companion object {
        fun notify(c: Context, id: Int, title: String, text: String, ok: String? = null, help: Boolean = false) {
            Notif.channels(c)
            val b = Notification.Builder(c, Notif.CH_ALERT).setSmallIcon(android.R.drawable.ic_dialog_alert).setContentTitle(title).setContentText(text).setAutoCancel(true)
            if (ok != null) b.addAction(Notification.Action.Builder(null, "I'm OK", PendingIntent.getBroadcast(c, id, Intent(c, SafetyReceiver::class.java).setAction(ok), PendingIntent.FLAG_IMMUTABLE)).build())
            if (help) { val pi = PendingIntent.getActivity(c, id + 1, Intent(c, EmergencyActivity::class.java).putExtra("level", 1), PendingIntent.FLAG_IMMUTABLE); b.addAction(Notification.Action.Builder(null, "Need help", pi).build()); b.setContentIntent(pi) }
            (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id, b.build())
        }
    }
    override fun onReceive(c: Context, i: Intent) {
        when (i.action) {
            "ARRIVAL_CHECK" -> if (Journey.active(c)) notify(c, 5010, "Did you arrive at ${Store.str(c, "journey").substringBefore("|")}?", "Confirm so nobody worries.", "ARRIVED", true)
            "ARRIVED" -> { Journey.arrive(c); (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(5010) }
            "CHECK" -> { if (Store.bool(c, "check_pending")) notify(c, 5011, "No answer to the last safety check", "Tap to prepare an emergency message (you confirm before anything is sent).", help = true)
                else notify(c, 5012, "Safety check", "Are you OK?", "CHECK_OK", true); Store.setBool(c, "check_pending", true); Check.next(c) }
            "CHECK_OK" -> { Store.setBool(c, "check_pending", false); (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(5012) }
        }
    }
}

object Safety {
    fun contacts(c: Context) = Store.list(c, "emergency").map { it.split("|") }.filter { it.size >= 2 }
    fun onBatteryLow(c: Context) = SafetyReceiver.notify(c, 5020, "🔋 Battery low (${Phone.level(c)}%)", if (Journey.active(c)) "Journey active – consider sharing your location." else "Charge soon.", help = Journey.active(c))
    fun handle(c: Context, t: String, fa: Boolean): String? {
        fun has(vararg k: String) = k.any { t.contains(it) }
        fun r(en: String, f: String) = if (fa) f else en
        fun emergency(level: Int, test: Boolean): String { Router.open(c, "Emergency", Intent(c, EmergencyActivity::class.java).putExtra("level", level).putExtra("test", test)); return r("Emergency screen opened. You have 10 seconds to cancel.", "صفحه اضطراری باز شد؛ ۱۰ ثانیه برای لغو دارید.") }
        if (has("danger 1", "danger one", "خطر ۱", "خطر 1", "خطر یک")) return emergency(1, false)
        if (has("danger 2", "danger two", "خطر ۲", "خطر 2", "خطر دو")) return emergency(2, false)
        if (has("test emergency", "emergency test", "تست اضطراری", "حالت آزمایشی")) return emergency(1, true)
        if (has("sos", "help me", "i'm in danger", "کمکم کن", "به کمک نیاز")) return emergency(1, false)
        if (has("siren", "emergency sound", "آژیر", "صدای اضطراری")) { if (has("off", "stop", "خاموش", "قطع")) { EmergencySound.stop(); return r("Siren off.", "آژیر خاموش شد.") }; EmergencySound.start(c); return r("Siren on. Say “siren off” to stop.", "آژیر روشن شد.") }
        if (has("fake call", "تماس ساختگی", "تماس جعلی")) { val ms = Logic.parseMillis(t) ?: 0L; val name = Store.str(c, "fake_name", "Mom")
            if (ms == 0L) { Router.open(c, "Call", Intent(c, FakeCallActivity::class.java).putExtra("name", name)); return r("Ringing now (simulated call).", "تماس شبیه‌سازی‌شده شروع شد.") }
            val pi = PendingIntent.getActivity(c, 5030, Intent(c, FakeCallActivity::class.java).putExtra("name", name), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).setAlarmClock(AlarmManager.AlarmClockInfo(System.currentTimeMillis() + ms, null), pi); return r("Simulated call in ${ms / 60000} min.", "تماس شبیه‌سازی‌شده ${ms / 60000} دقیقه دیگر.") }
        if (has("safe journey", "start journey", "سفر امن", "شروع سفر")) { val ms = Logic.parseMillis(t) ?: return r("How long will the trip take? e.g. “safe journey to home in 30 minutes”.", "سفر چقدر طول می‌کشد؟ مثلاً «سفر امن به خانه ۳۰ دقیقه»")
            val dest = Regex("(?:to|به)\\s+(.+?)(?:\\s+in\\s|\\s+\\d|$)").find(t)?.groupValues?.get(1)?.trim() ?: "destination"; Journey.start(c, dest, ms)
            return r("Journey to $dest started. I'll ask if you arrived. Say “I arrived” when you do.", "سفر به $dest شروع شد. بعد از رسیدن بگویید «رسیدم».") }
        if (has("i arrived", "i'm home", "رسیدم")) { if (!Journey.active(c)) return r("No journey is active.", "سفری فعال نیست."); Journey.arrive(c)
            val cs = contacts(c); if (cs.isNotEmpty()) Router.open(c, "Arrival message", Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${cs.joinToString(";") { it[1] }}")).putExtra("sms_body", "I arrived safely."))
            return r("Arrival confirmed.${if (cs.isNotEmpty()) " Message prepared — press send." else ""}", "رسیدن ثبت شد.${if (cs.isNotEmpty()) " پیام آماده است؛ ارسال را بزنید." else ""}") }
        if (has("share journey", "share eta", "اشتراک مسیر")) { val cs = contacts(c); if (cs.isEmpty()) return r("Add emergency contacts first (Safety screen).", "ابتدا مخاطبین اضطراری را اضافه کنید.")
            val l = Loc.last(c); val j = Store.str(c, "journey").split("|"); val eta = j.getOrNull(1)?.toLongOrNull()?.let { java.text.SimpleDateFormat("HH:mm", Locale.US).format(java.util.Date(it)) } ?: "?"
            Router.open(c, "Share journey", Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${cs.joinToString(";") { it[1] }}")).putExtra("sms_body", "I'm heading to ${j.getOrNull(0) ?: "my destination"}, arriving about $eta.${l?.let { " Now: ${Loc.link(it)}" } ?: ""}"))
            return r("Message prepared — press send.", "پیام آماده است؛ ارسال را بزنید.") }
        if (has("safety check", "بررسی ایمنی")) { if (has("stop", "off", "cancel", "توقف", "خاموش")) { Check.stop(c); return r("Safety checks stopped.", "بررسی ایمنی متوقف شد.") }
            val h = Regex("(\\d+)").find(Logic.digits(t))?.value?.toInt() ?: 4; Check.start(c, h); return r("I'll check on you every $h hours.", "هر $h ساعت از شما می‌پرسم.") }
        if (has("emergency id", "my emergency info", "اطلاعات اضطراری")) { Router.open(c, "Emergency ID", Intent(c, EmergencyInfoActivity::class.java)); return r("Opening emergency info.", "اطلاعات اضطراری باز شد.") }
        if (has("security status", "وضعیت امنیتی")) { Router.open(c, "Safety", Intent(c, SafetyActivity::class.java)); return r("Opening security dashboard.", "داشبورد امنیت باز شد.") }
        return null
    }
}

/** 10-second countdown with Cancel. Nothing is sent secretly: the SMS app opens with a ready message and YOU press send. */
class EmergencyActivity : Activity() {
    private var timer: CountDownTimer? = null
    override fun onCreate(s: Bundle?) {
        super.onCreate(s); setShowWhenLocked(true); setTurnScreenOn(true)
        val level = intent.getIntExtra("level", 1); val test = intent.getBooleanExtra("test", false)
        val root = Ui.screen(this, if (test) "🧪 EMERGENCY TEST" else "🚨 EMERGENCY (level $level)")
        val count = Ui.text(this, "10", 48); val status = Ui.text(this, "Message and location will be prepared. Cancel to stop.", 15)
        root.addView(count); root.addView(status)
        root.addView(Ui.button(this, "CANCEL") { timer?.cancel(); EmergencySound.stop(); finish() })
        root.addView(Ui.button(this, "Prepare now") { timer?.cancel(); run(level, test, status) })
        timer = object : CountDownTimer(10_000, 1000) { override fun onTick(ms: Long) { count.text = "${ms / 1000 + 1}" }; override fun onFinish() { count.text = "0"; run(level, test, status) } }.start()
    }
    private fun run(level: Int, test: Boolean, status: TextView) {
        val sb = StringBuilder(); val l = Loc.last(this); val cs = Safety.contacts(this)
        if (!test) Modes.set(this, "emergency")
        sb.append(if (l != null) "📍 Location found\n" else "📍 Location unavailable (grant permission)\n")
        if (level >= 2) { EmergencySound.start(this); sb.append("🔊 Siren on (press Cancel to stop)\n") }
        val msg = (if (test) "[TEST] " else "") + "EMERGENCY: I need help." + (l?.let { " Location: ${Loc.link(it)}." } ?: "") + " " + Store.secret(this, "emergency_id")
        if (cs.isEmpty()) sb.append("⚠ No emergency contacts yet (Safety screen)\n") else {
            try { startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${cs.joinToString(";") { it[1] }}")).putExtra("sms_body", msg)); sb.append("✉ Message prepared for ${cs.size} contact(s) — press SEND in the messaging app.\n") } catch (e: Exception) { sb.append("✉ Could not open messaging app\n") }
            if (level >= 2) status.post { /* call button */ } }
        Store.push(this, "sec_log", java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.US).format(java.util.Date()) + " level $level${if (test) " TEST" else ""}: contacts=${cs.size}, location=${l != null}, SMS app opened=${cs.isNotEmpty()}", 50)
        status.text = sb.toString() + "\nDelivery cannot be confirmed by the app: the SMS app sends only when you press send."
        if (level >= 2 && cs.isNotEmpty()) (status.parent as android.widget.LinearLayout).addView(Ui.button(this, "Call ${cs[0][0]}") { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${cs[0][1]}"))) })
    }
    override fun onDestroy() { timer?.cancel(); super.onDestroy() }
}

/** Works offline and over the lock screen: shows only what you chose to store. */
class EmergencyInfoActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s); setShowWhenLocked(true)
        val root = Ui.screen(this, "🆘 Emergency ID")
        root.addView(Ui.text(this, Store.secret(this, "emergency_id").ifBlank { "Nothing saved. Add info in Safety screen." }, 17))
        Safety.contacts(this).forEach { ct -> root.addView(Ui.button(this, "Call ${ct[0]}") { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${ct[1]}"))) }) }
    }
}

/** Simulated incoming call (clearly labelled) to help you leave an uncomfortable situation. */
class FakeCallActivity : Activity() {
    private var rt: Ringtone? = null
    override fun onCreate(s: Bundle?) {
        super.onCreate(s); setShowWhenLocked(true); setTurnScreenOn(true)
        val name = intent.getStringExtra("name") ?: "Mom"
        val root = Ui.screen(this, "📞 Incoming call"); root.addView(Ui.text(this, name, 34)); val st = Ui.text(this, "ringing… (simulated)", 14); root.addView(st)
        rt = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)).apply { isLooping = true; play() }
        root.addView(Ui.button(this, "Accept") { rt?.stop(); st.text = "call in progress (simulated)" })
        root.addView(Ui.button(this, "Decline / End") { rt?.stop(); finish() })
    }
    override fun onDestroy() { rt?.stop(); super.onDestroy() }
}
