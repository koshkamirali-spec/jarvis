package com.jarvis.ai
import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.*
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Foreground microphone service (visible notification at all times).
 * WAKE: waits for the wake phrase. AWAKE: conversation open (60 s idle -> WAKE). PAUSED: only "Continue Jarvis".
 * "Stop Jarvis" pauses, "Stop listening" ends the service. Auto-stops after the idle timeout to save battery.
 */
class ListenService : Service() {
    enum class S { WAKE, AWAKE, PAUSED }
    companion object {
        const val START = "start"; const val STOP = "stop"; const val CONTINUE = "continue"; const val MUTE = "mute"
        @Volatile var running = false; @Volatile var stateText = "off"
        fun start(c: Context) = c.startForegroundService(Intent(c, ListenService::class.java).setAction(START))
        fun stop(c: Context) { c.stopService(Intent(c, ListenService::class.java)) }
    }
    private val h = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var state = S.WAKE; private var muted = false; private var busy = false
    private var lastActive = 0L; private var started = 0L
    private var wl: PowerManager.WakeLock? = null
    private fun ack(t: String) = if (Lang.fa(this, t)) Store.str(this, "ack_fa", "بله قربان") else Store.str(this, "ack_en", "Yes sir")
    private fun beepGuard(on: Boolean) { if (!Store.bool(this, "mute_beep", true)) return; try { val am = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
        for (s in intArrayOf(android.media.AudioManager.STREAM_SYSTEM, android.media.AudioManager.STREAM_NOTIFICATION)) am.adjustStreamVolume(s, if (on) android.media.AudioManager.ADJUST_MUTE else android.media.AudioManager.ADJUST_UNMUTE, 0) } catch (_: Exception) {} }
    private val batt = object : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) { Safety.onBatteryLow(c) } }
    private val tick = object : Runnable { override fun run() { Modes.tick(this@ListenService); h.postDelayed(this, 60_000) } }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) {
            STOP -> { state = S.PAUSED; note("Paused – say “Continue Jarvis”") }
            CONTINUE -> { state = S.AWAKE; lastActive = now(); note("Conversation active") }
            MUTE -> { muted = !muted; if (muted) rec?.cancel() else listen(); note(if (muted) "Muted" else "Listening") }
            else -> if (!running) begin()
        }
        return START_STICKY
    }
    private fun now() = SystemClock.elapsedRealtime()
    private fun begin() {
        running = true; started = now(); Notif.channels(this)
        val n = build("Say “${Store.str(this, "wake", "Hey Jarvis")}”")
        if (Build.VERSION.SDK_INT >= 30) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { Speaker.speak(this, "Speech recognition is unavailable on this phone."); stopSelf(); return }
        if (Store.bool(this, "keep_awake", true)) { wl = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jarvis:listen"); wl?.acquire() }
        registerReceiver(batt, IntentFilter(Intent.ACTION_BATTERY_LOW)); registerReceiver(triggers, IntentFilter().apply { addAction(android.bluetooth.BluetoothDevice.ACTION_ACL_CONNECTED); addAction(android.bluetooth.BluetoothDevice.ACTION_ACL_DISCONNECTED); addAction(Intent.ACTION_POWER_CONNECTED); addAction(Intent.ACTION_POWER_DISCONNECTED) }); h.post(tick); if (Journey.active(this)) Journey.watch(this)
        listen()
    }
    private fun act(a: String, code: Int) = PendingIntent.getService(this, code, Intent(this, ListenService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE)
    private fun build(text: String): Notification { stateText = text
        return Notification.Builder(this, Notif.CH_SVC).setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("J.A.R.V.I.S").setContentText(text).setOngoing(true)
            .setContentIntent(PendingIntent.getActivity(this, 9, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            .addAction(Notification.Action.Builder(null, "Stop", act(STOP, 1)).build()).addAction(Notification.Action.Builder(null, "Continue", act(CONTINUE, 2)).build())
            .addAction(Notification.Action.Builder(null, if (muted) "Unmute" else "Mute", act(MUTE, 3)).build()).build() }
    private fun note(t: String) = (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(1, build(t))

    private fun listen() {
        if (!running || muted || busy) return
        val idle = Store.int(this, "idle_min", 30) * 60_000L
        if (state == S.WAKE && idle > 0 && now() - maxOf(started, lastActive) > idle) { Speaker.speak(this, "Listening stopped to save battery."); stopSelf(); return }
        if (state == S.AWAKE && now() - lastActive > 60_000) { state = S.WAKE; note("Say “${Store.str(this, "wake", "Hey Jarvis")}”") }
        if (state != S.WAKE) Wake.pause()
        else { rec?.destroy(); rec = null; if (Wake.start(this) { h.post { onPorcupine() } }) return }
        rec?.destroy(); beepGuard(true); h.postDelayed({ beepGuard(false) }, 600)
        rec = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) { val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull(); if (t != null) handle(t); if (!busy) h.postDelayed({ listen() }, 300) }
                override fun onError(e: Int) { if (!busy) h.postDelayed({ listen() }, if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 500) }
                override fun onReadyForSpeech(p: Bundle?) { if (state == S.AWAKE) Brain.set(Brain.St.LISTENING) }; override fun onBeginningOfSpeech() {}; override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}; override fun onEndOfSpeech() {}; override fun onPartialResults(b: Bundle?) {}; override fun onEvent(t: Int, b: Bundle?) {}
            })
            r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                .apply { Lang.tag(this@ListenService).takeIf { it.isNotBlank() }?.let { putExtra(RecognizerIntent.EXTRA_LANGUAGE, it) } })
        }
    }
    private fun has(t: String, vararg k: String) = k.any { t.contains(it) }
    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }
    private fun wakeIn(t: String): String? {
        val w = Store.str(this, "wake", "Hey Jarvis").lowercase().trim()
        val exact = listOf(w, "hey jarvis", "هی جارویس", "هی جارویز", "هی جاروس").firstOrNull { t.contains(it) }
        if (exact != null) return exact
        if (Store.int(this, "sens", 1) >= 2) { val n = norm(t); listOf(norm(w), "heyjarvis", "jarvis", "جارویس").firstOrNull { it.isNotEmpty() && n.contains(it) }?.let { k -> return if (t.contains(k)) k else "" } }
        return null
    }
    private fun onPorcupine() { if (!running || state != S.WAKE) return; Wake.pause(); state = S.AWAKE; lastActive = now(); note("Conversation active"); say(ack("")) }
    private val triggers = object : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) {
        if (i.action == android.bluetooth.BluetoothDevice.ACTION_ACL_CONNECTED || i.action == android.bluetooth.BluetoothDevice.ACTION_ACL_DISCONNECTED) {
            @Suppress("DEPRECATION") val n = try { i.getParcelableExtra<android.bluetooth.BluetoothDevice>(android.bluetooth.BluetoothDevice.EXTRA_DEVICE)?.name } catch (e: Exception) { null }
            if (n != null) { if (i.action == android.bluetooth.BluetoothDevice.ACTION_ACL_CONNECTED) Modes.btConnected.add(n) else Modes.btConnected.remove(n) } }
        Modes.tick(c) } }
    private var wasWake = false
    private fun handle(text: String) {
        wasWake = false
        val t = text.lowercase()
        if (state == S.PAUSED) { if (has(t, "continue jarvis", "ادامه جارویس")) { state = S.AWAKE; lastActive = now(); say("Back.") }; return }
        if (has(t, "stop listening", "شنود را خاموش کن", "شنود رو خاموش کن")) { Speaker.speak(this, "Listening off."); stopSelf(); return }
        if (has(t, "stop jarvis", "توقف جارویس")) { state = S.PAUSED; Speaker.stop(); say("Paused."); return }
        var cmd = text
        if (state == S.WAKE) {
            val w = wakeIn(t) ?: return
            cmd = if (w.isEmpty()) "" else t.substringAfter(w).trim(); state = S.AWAKE; lastActive = now(); note("Conversation active")
            if (cmd.isEmpty()) { say(ack(text)); return }
            wasWake = true
        }
        lastActive = now(); busy = true; rec?.cancel()
        val prefix = if (wasWake) ack(text) + ". " else ""
        Thread { val r = Brain.process(this, cmd); h.post { Speaker.speak(this, prefix + r) { h.post { busy = false; lastActive = now(); listen() } } } }.start()
    }
    private fun say(r: String) { busy = true; rec?.cancel(); Speaker.speak(this, r) { h.post { busy = false; lastActive = now(); listen() } } }
    override fun onDestroy() { running = false; stateText = "off"; try { wl?.release() } catch (_: Exception) {}; beepGuard(false); try { unregisterReceiver(batt) } catch (_: Exception) {}; try { unregisterReceiver(triggers) } catch (_: Exception) {}; Wake.release(); Journey.unwatch(this); rec?.destroy(); Speaker.stop(); h.removeCallbacksAndMessages(null); super.onDestroy() }
}
