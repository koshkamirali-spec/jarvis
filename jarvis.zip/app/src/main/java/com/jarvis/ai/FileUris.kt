package com.jarvis.ai
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File

/** content:// URIs for files created by JARVIS (camera, recordings) so other apps can read them. */
object FileUris {
    fun of(c: Context, f: File): Uri = androidx.core.content.FileProvider.getUriForFile(c, "${c.packageName}.fp", f)
    fun name(c: Context, u: Uri): String = c.contentResolver.query(u, null, null, null, null)?.use { if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null } ?: "file"
}
