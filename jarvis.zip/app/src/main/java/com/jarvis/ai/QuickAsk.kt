package com.jarvis.ai
import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionListener
import android.speech.RecognitionService
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.TextView

object Voice {
    /** One-shot speech recognition (mic button, lock screen, assistant gesture). */
    fun once(a: Activity, onText: (String) -> Unit, onEnd: () -> Unit = {}): SpeechRecognizer? {
        if (a.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { Ui.toast(a, "Microphone permission needed"); onEnd(); return null }
        val r = SpeechRecognizer.createSpeechRecognizer(a)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) { Brain.set(Brain.St.IDLE); val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull(); if (t != null) onText(t) else onEnd() }
            override fun onError(e: Int) { Brain.set(Brain.St.IDLE); onEnd() }
            override fun onReadyForSpeech(p: Bundle?) { Brain.set(Brain.St.LISTENING) }; override fun onBeginningOfSpeech() {}; override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}; override fun onEndOfSpeech() {}; override fun onPartialResults(b: Bundle?) {}; override fun onEvent(t: Int, b: Bundle?) {}
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .apply { Lang.tag(a).takeIf { it.isNotBlank() }?.let { putExtra(RecognizerIntent.EXTRA_LANGUAGE, it) } })
        return r
    }
}

/** One voice question that also works over the lock screen. Private actions (notes, opening apps, contacts) need unlock. */
class QuickAskActivity : Activity() {
    private var rec: SpeechRecognizer? = null
    override fun onCreate(s: Bundle?) {
        super.onCreate(s); setShowWhenLocked(true); setTurnScreenOn(true)
        val tv = TextView(this).apply { setPadding(48, 48, 48, 48); textSize = 18f; text = "Listening…" }; setContentView(tv)
        val locked = (getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager).isKeyguardLocked
        rec = Voice.once(this, { t ->
            tv.text = t
            Thread {
                val priv = locked && listOf("note", "open", "call", "message", "task", "memory", "finance", "expense", "یادداشت", "باز کن", "تماس", "پیام", "هزینه", "حافظه").any { t.lowercase().contains(it) }
                val rep = if (priv) "Please unlock your phone first." else Brain.process(this, t)
                runOnUiThread { tv.text = rep; Speaker.speak(this, rep) { runOnUiThread { finish() } } }
            }.start()
        }, { finish() })
        if (rec == null) finish()
    }
    override fun onDestroy() { rec?.destroy(); super.onDestroy() }
}

/** Lets JARVIS be chosen as the phone's default digital assistant (power-button / corner swipe). */
class JarvisVoiceService : VoiceInteractionService()
class JarvisSessionService : VoiceInteractionSessionService() { override fun onNewSession(args: Bundle?): VoiceInteractionSession = JarvisSession(this) }
class JarvisSession(c: Context) : VoiceInteractionSession(c) {
    override fun onShow(args: Bundle?, flags: Int) { super.onShow(args, flags); try { startAssistantActivity(Intent(context, QuickAskActivity::class.java)) } catch (_: Exception) {}; hide() }
}
class StubRecognition : RecognitionService() {
    override fun onStartListening(i: Intent?, l: Callback?) { l?.error(SpeechRecognizer.ERROR_CLIENT) }
    override fun onCancel(l: Callback?) {}
    override fun onStopListening(l: Callback?) {}
}
