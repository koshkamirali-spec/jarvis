package com.jarvis.ai
import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationManager
import android.app.usage.UsageStatsManager
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import android.provider.Settings

/** Phone control. Everything here uses permitted system APIs; where Android forbids a direct action we open the right settings screen and say so. */
object Phone {
    private var torchOn = false
    private val settingsMap: List<Pair<List<String>, String>> = listOf(
        listOf("wifi", "wi-fi", "وای فای", "وای‌فای") to Settings.ACTION_WIFI_SETTINGS,
        listOf("bluetooth", "بلوتوث") to Settings.ACTION_BLUETOOTH_SETTINGS,
        listOf("display settings", "تنظیمات نمایش") to Settings.ACTION_DISPLAY_SETTINGS,
        listOf("sound settings", "تنظیمات صدا") to Settings.ACTION_SOUND_SETTINGS,
        listOf("location settings", "تنظیمات مکان") to Settings.ACTION_LOCATION_SOURCE_SETTINGS,
        listOf("storage settings", "تنظیمات حافظه") to Settings.ACTION_INTERNAL_STORAGE_SETTINGS,
        listOf("battery settings", "battery saver", "تنظیمات باتری") to Settings.ACTION_BATTERY_SAVER_SETTINGS,
        listOf("apps settings", "تنظیمات برنامه") to Settings.ACTION_APPLICATION_SETTINGS,
        listOf("airplane", "حالت پرواز") to Settings.ACTION_AIRPLANE_MODE_SETTINGS,
        listOf("nfc") to Settings.ACTION_NFC_SETTINGS,
        listOf("security settings", "تنظیمات امنیت") to Settings.ACTION_SECURITY_SETTINGS,
        listOf("data usage", "مصرف اینترنت") to "android.settings.DATA_USAGE_SETTINGS",
        listOf("accessibility settings") to Settings.ACTION_ACCESSIBILITY_SETTINGS)
    private val alias = mapOf("اینستاگرام" to "instagram", "تلگرام" to "telegram", "واتساپ" to "whatsapp", "واتس اپ" to "whatsapp", "یوتیوب" to "youtube", "مرورگر" to "chrome", "نقشه" to "maps", "اسپاتیفای" to "spotify")

    fun handle(c: Context, t: String, fa: Boolean): String? {
        fun has(vararg k: String) = k.any { t.contains(it) }
        fun r(en: String, f: String) = if (fa) f else en
        fun go(label: String, i: Intent, en: String, f: String): String { Router.open(c, label, i); return r(en, f) }
        fun selector(cat: String) = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, cat)
        if (has("jarvis settings", "تنظیمات جارویس")) return go("Settings", Intent(c, SettingsActivity::class.java), "Opening my settings.", "تنظیمات باز شد.")
        for ((keys, action) in settingsMap) if (has(*keys.toTypedArray())) return go("Settings", Intent(action), "Opening settings. Android does not let apps toggle this directly.", "تنظیمات باز شد؛ اندروید اجازه تغییر مستقیم نمی‌دهد.")
        if (has("flashlight", "torch", "چراغ قوه", "چراغ‌قوه")) return torch(c, !has("off", "خاموش"), fa)
        if (has("brightness", "روشنایی")) return brightness(c, t, fa)
        if (has("volume", "صدا را", "صدا رو", "بلندی صدا")) return volume(c, t, fa)
        if (has("battery", "باتری")) return battery(c, fa)
        if (has("internet status", "network info", "am i online", "وضعیت اینترنت", "اطلاعات شبکه", "آنلاین")) return network(c, fa)
        if (has("device info", "phone info", "اطلاعات دستگاه", "اطلاعات گوشی")) return r("${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})", "${Build.MANUFACTURER} ${Build.MODEL}، اندروید ${Build.VERSION.RELEASE}")
        if (has("storage", "فضای ذخیره", "حافظه داخلی")) { val s = StatFs(Environment.getDataDirectory().path); val free = s.availableBytes / 1e9; val tot = s.totalBytes / 1e9
            return r("Storage: %.1f GB free of %.1f GB.".format(free, tot), "فضای خالی: %.1f از %.1f گیگابایت.".format(free, tot)) }
        if (has("memory usage", "free memory", "ram usage", "how much ram", "وضعیت حافظه", "منابع دستگاه", "رم گوشی")) { val mi = ActivityManager.MemoryInfo(); (c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
            return r("RAM: %d MB free of %d MB.".format(mi.availMem / 1048576, mi.totalMem / 1048576), "رم آزاد: %d از %d مگابایت.".format(mi.availMem / 1048576, mi.totalMem / 1048576)) }
        if (has("bluetooth status", "وضعیت بلوتوث")) return try { val on = (c.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter?.isEnabled == true; r("Bluetooth is ${if (on) "on" else "off"}.", "بلوتوث ${if (on) "روشن" else "خاموش"} است.") } catch (e: SecurityException) { r("Bluetooth permission is missing.", "مجوز بلوتوث داده نشده.") }
        if (has("do not disturb", "مزاحم نشوید")) { val on = !has("off", "خاموش"); return if (Modes.dnd(c, on)) r("Do Not Disturb ${if (on) "on" else "off"}.", "مزاحم نشوید ${if (on) "روشن" else "خاموش"} شد.") else go("DND access", Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS), "Please allow Do Not Disturb access.", "لطفاً دسترسی مزاحم نشوید را بدهید.") }
        if (has("play music", "resume music", "پخش موسیقی", "ادامه موسیقی")) return media(c, android.view.KeyEvent.KEYCODE_MEDIA_PLAY, r("Playing.", "پخش شد."))
        if (has("pause music", "stop music", "مکث موسیقی", "موسیقی را نگه دار", "توقف موسیقی")) return media(c, android.view.KeyEvent.KEYCODE_MEDIA_PAUSE, r("Paused.", "مکث شد."))
        if (has("next song", "next track", "آهنگ بعدی")) return media(c, android.view.KeyEvent.KEYCODE_MEDIA_NEXT, r("Next.", "بعدی."))
        if (has("previous song", "previous track", "آهنگ قبلی")) return media(c, android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS, r("Previous.", "قبلی."))
        if (has("open music", "music app", "برنامه موسیقی")) return go("Music", selector(Intent.CATEGORY_APP_MUSIC), "Opening music.", "موسیقی باز شد.")
        if (has("open camera", "دوربین را باز", "باز کردن دوربین", "دوربین باز")) return go("Camera", Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA), "Opening camera.", "دوربین باز شد.")
        if (has("open gallery", "گالری")) return go("Gallery", selector(Intent.CATEGORY_APP_GALLERY), "Opening gallery.", "گالری باز شد.")
        if (has("open browser", "مرورگر")) return go("Browser", Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")), "Opening browser.", "مرورگر باز شد.")
        if (has("open calendar", "تقویم را باز", "باز کردن تقویم")) return go("Calendar", selector(Intent.CATEGORY_APP_CALENDAR), "Opening calendar.", "تقویم باز شد.")
        if (has("open calculator", "ماشین حساب", "ماشین‌حساب")) return go("Calculator", selector(Intent.CATEGORY_APP_CALCULATOR), "Opening calculator.", "ماشین‌حساب باز شد.")
        if (has("open maps", "open map", "نقشه را باز", "باز کردن نقشه")) return go("Maps", Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=")), "Opening maps.", "نقشه باز شد.")
        if (has("find app", "search app", "جستجوی برنامه")) { val q = t.substringAfter("app").trim(); val l = apps(c).filter { it.first.lowercase().contains(q) }.map { it.first }.take(8)
            return if (l.isEmpty()) r("No installed app matches.", "برنامه‌ای پیدا نشد.") else l.joinToString("، ") }
        if (has("open ", "launch ", "start ", "باز کن", "اجرا کن", "اجرای ")) return openApp(c, t, fa)
        return null
    }

    fun apps(c: Context): List<Pair<String, ApplicationInfo>> {
        val pm = c.packageManager
        return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0).map { it.loadLabel(pm).toString() to it.activityInfo.applicationInfo }.distinctBy { it.second.packageName }
    }
    fun openApp(c: Context, t: String, fa: Boolean): String {
        var name = t.replace(Regex("^(please\\s+)?(open|launch|start)\\s+(the\\s+)?(app\\s+)?"), "").replace("باز کن", "").replace("اجرا کن", "").replace("اجرای", "").replace("برنامه", "").replace("بازی", "").trim()
        alias.forEach { (k, v) -> if (name.contains(k)) name = v }
        if (name.isEmpty()) return if (fa) "کدام برنامه؟" else "Which app?"
        val m = apps(c).firstOrNull { it.first.lowercase() == name } ?: apps(c).firstOrNull { it.first.lowercase().contains(name) || name.contains(it.first.lowercase()) }
        if (m == null) return if (fa) "برنامه «$name» نصب نیست." else "I couldn't find an app named “$name”."
        val i = c.packageManager.getLaunchIntentForPackage(m.second.packageName) ?: return if (fa) "باز نشد." else "Can't open it."
        Router.open(c, m.first, i); return if (fa) "${m.first} باز شد." else "Opening ${m.first}."
    }
    private fun media(c: Context, key: Int, reply: String): String {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, key)); am.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, key)); return reply
    }
    private fun torch(c: Context, on: Boolean, fa: Boolean): String = try {
        val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
        cm.setTorchMode(id, on); torchOn = on; if (fa) "چراغ‌قوه ${if (on) "روشن" else "خاموش"} شد." else "Flashlight ${if (on) "on" else "off"}."
    } catch (e: Exception) { ErrorLog.e(c, "torch", e); if (fa) "چراغ‌قوه در دسترس نیست." else "Flashlight unavailable." }
    private fun brightness(c: Context, t: String, fa: Boolean): String {
        if (!Settings.System.canWrite(c)) { Router.open(c, "Allow settings change", Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${c.packageName}"))); return if (fa) "برای تغییر روشنایی مجوز را بدهید." else "Please allow “modify system settings” first." }
        val n = Regex("(\\d+)").find(Logic.digits(t))?.value?.toInt()
        val cur = Settings.System.getInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
        val v = n?.let { it.coerceIn(1, 100) * 255 / 100 } ?: if (listOf("up", "increase", "زیاد", "بالا").any { t.contains(it) }) minOf(255, cur + 50) else if (listOf("down", "decrease", "کم", "پایین").any { t.contains(it) }) maxOf(5, cur - 50) else return (if (fa) "روشنایی ${cur * 100 / 255}٪" else "Brightness ${cur * 100 / 255}%")
        Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, v); return if (fa) "روشنایی ${v * 100 / 255}٪ شد." else "Brightness ${v * 100 / 255}%."
    }
    private fun volume(c: Context, t: String, fa: Boolean): String {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager; val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val n = Regex("(\\d+)").find(Logic.digits(t))?.value?.toInt()
        when {
            n != null -> am.setStreamVolume(AudioManager.STREAM_MUSIC, max * n.coerceIn(0, 100) / 100, AudioManager.FLAG_SHOW_UI)
            listOf("mute", "بی صدا", "بی‌صدا").any { t.contains(it) } -> am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI)
            listOf("up", "raise", "increase", "زیاد", "بالا").any { t.contains(it) } -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            listOf("down", "lower", "decrease", "کم", "پایین").any { t.contains(it) } -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
        }
        val p = am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / max; return if (fa) "صدا $p٪" else "Volume $p%."
    }
    fun battery(c: Context, fa: Boolean): String {
        val b = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return "?"
        val lvl = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) * 100 / b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1); val ch = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        val temp = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0
        return if (fa) "باتری $lvl٪${if (ch) "، در حال شارژ" else ""}، دما $temp درجه." else "Battery $lvl%${if (ch) ", charging" else ""}, $temp°C."
    }
    fun level(c: Context): Int { val b = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return -1; return b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) * 100 / b.getIntExtra(BatteryManager.EXTRA_SCALE, 100) }
    private fun network(c: Context, fa: Boolean): String {
        val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager; val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val kind = when { caps == null -> "offline"; caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"; caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobile data"; caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"; else -> "other" }
        val down = caps?.linkDownstreamBandwidthKbps?.div(1000) ?: 0
        return if (fa) "اتصال: $kind، حدود $down مگابیت." else "Connection: $kind, about $down Mbps down."
    }
}

object Gaming {
    fun start(c: Context) {
        Store.setLong(c, "gs", System.currentTimeMillis()); Notif.channels(c)
        (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(77, Notification.Builder(c, Notif.CH_SVC).setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("JARVIS Gaming Mode").setContentText("Play time").setUsesChronometer(true).setWhen(System.currentTimeMillis()).setOngoing(true).build())
        Router.schedule(c, 45 * 60_000L, "Time for a short break 🎮", id = 7701)
    }
    fun stop(c: Context) { Store.setLong(c, "gs", 0); (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(77) }
    fun elapsed(c: Context, fa: Boolean): String { val s = Store.long(c, "gs"); if (s == 0L) return if (fa) "حالت بازی خاموش است." else "Gaming mode is off."; val m = (System.currentTimeMillis() - s) / 60000; return if (fa) "$m دقیقه بازی کرده‌اید." else "You have played $m minutes." }
}

object Games {
    fun installed(c: Context): List<String> = Phone.apps(c).filter { it.second.category == ApplicationInfo.CATEGORY_GAME }.map { it.first }
    private fun recent(c: Context): List<String>? {
        val ao = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION") val mode = ao.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), c.packageName)
        if (mode != AppOpsManager.MODE_ALLOWED) return null
        val now = System.currentTimeMillis(); val us = (c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager).queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 7 * 86400000L, now)
        val games = Phone.apps(c).filter { it.second.category == ApplicationInfo.CATEGORY_GAME }.associate { it.second.packageName to it.first }
        return us.filter { it.packageName in games }.sortedByDescending { it.lastTimeUsed }.map { games[it.packageName]!! }.distinct().take(6)
    }
    fun handle(c: Context, t: String, fa: Boolean): String? {
        fun has(vararg k: String) = k.any { t.contains(it) }
        fun r(en: String, f: String) = if (fa) f else en
        if (has("how long", "game time", "زمان بازی", "چقدر بازی")) return Gaming.elapsed(c, fa)
        if (has("my games", "list games", "installed games", "بازی‌های من", "بازی های من", "بازی‌های نصب")) { val l = installed(c); return if (l.isEmpty()) r("No games found.", "بازی‌ای پیدا نشد.") else l.take(12).joinToString("، ") }
        if (has("recent games", "last game", "آخرین بازی", "بازی‌های اخیر")) { val l = recent(c)
            if (l == null) { Router.open(c, "Usage access", Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)); return r("Allow Usage access for JARVIS, then ask again.", "دسترسی Usage را به جارویس بدهید و دوباره بپرسید.") }
            return if (l.isEmpty()) r("No recent games.", "بازی اخیری نیست.") else l.joinToString("، ") }
        if (has("favorite game", "favourite game", "بازی مورد علاقه", "بازی موردعلاقه")) {
            val n = t.substringAfter("game").substringAfter("بازی").replace("مورد علاقه", "").replace("موردعلاقه", "").replace("add", "").trim()
            if (has("add", "اضافه") && n.isNotBlank()) { Store.push(c, "games_fav", n); return r("Added $n.", "$n اضافه شد.") }
            return Store.list(c, "games_fav").ifEmpty { listOf(r("No favorites yet.", "هنوز چیزی نیست.")) }.joinToString("، ") }
        if (has("daily game", "game list for today", "فهرست بازی روزانه", "بازی‌های امروز")) {
            val n = t.substringAfter("add").trim()
            if (has("add", "اضافه") && n.isNotBlank()) { Store.push(c, "games_daily", n); return r("Added.", "اضافه شد.") }
            return Store.list(c, "games_daily").ifEmpty { listOf(r("Empty.", "خالی است.")) }.joinToString("، ") }
        if (has("play ", "start game", "open game", "اجرای بازی", "بازی ") && !has("music", "موسیقی", "video")) {
            val name = t.replace(Regex("^(play|start game|open game)\\s+"), "").replace("اجرای بازی", "").replace("بازی", "").replace("game", "").trim()
            if (name.isEmpty()) return null
            val m = Phone.apps(c).firstOrNull { it.second.category == ApplicationInfo.CATEGORY_GAME && it.first.lowercase().contains(name) } ?: return if (has("game", "بازی")) store(c, name, fa) else null
            val i = c.packageManager.getLaunchIntentForPackage(m.second.packageName) ?: return null
            Modes.set(c, "gaming"); Router.open(c, m.first, i); return r("Starting ${m.first}. Gaming mode on.", "${m.first} اجرا شد. حالت بازی روشن شد.")
        }
        return null
    }
    private fun store(c: Context, name: String, fa: Boolean): String {
        Router.open(c, "Play Store", Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=${Uri.encode(name)}&c=apps")))
        return if (fa) "«$name» نصب نیست؛ صفحه جست‌وجو در Google Play باز شد." else "“$name” isn't installed; opening Google Play search."
    }
}

/** Opens JARVIS's own screens by voice. */
object Screens {
    fun handle(c: Context, t: String, fa: Boolean): String? {
        fun has(vararg k: String) = k.any { t.contains(it) }
        fun go(cls: Class<*>, en: String, f: String, vararg extra: Pair<String, String>): String { Router.open(c, en, Intent(c, cls).apply { extra.forEach { putExtra(it.first, it.second) } }); return if (fa) f else en }
        val ctx = has("photo", "image", "picture", "camera", "scan", "identify", "what is this", "what's this", "عکس", "تصویر", "دوربین", "اسکن", "تشخیص", "این چیه", "این چیست")
        val vision = listOf("identify" to listOf("what is this", "what's this", "identify this", "smart camera", "این چیه", "این چیست", "دوربین هوشمند"),
            "ocr" to listOf("ocr", "scan text", "read this text", "خواندن متن", "متن داخل تصویر"),
            "plant" to listOf("plant", "گیاه"), "animal" to listOf("animal", "حیوان"), "product" to listOf("product", "محصول"), "food" to listOf("food", "ingredient", "غذا", "مواد غذایی"),
            "translate" to listOf("translate image", "translate this image", "translate photo", "ترجمه تصویر", "ترجمه عکس"),
            "document" to listOf("invoice", "receipt", "document", "فاکتور", "سند"), "signs" to listOf("road sign", "traffic sign", "sign", "تابلو", "علائم"),
            "surroundings" to listOf("surroundings", "around me", "محیط اطراف"), "compare" to listOf("compare photos", "compare images", "مقایسه تصاویر", "مقایسه عکس"))
        if (!has("open camera", "باز کردن دوربین", "دوربین را باز", "دوربین باز")) {
            for ((mode, keys) in vision) if (has(*keys.toTypedArray()) && (ctx || mode in listOf("identify", "ocr"))) return go(VisionActivity::class.java, "Opening smart camera.", "دوربین هوشمند باز شد.", "mode" to mode)
        }
        if (has("analyze screen", "analyse screen", "what's on my screen", "تحلیل صفحه", "توضیح صفحه", "game help", "game tip", "راهنمای بازی")) {
            Router.open(c, "Analyze screen", Intent(c, ScreenAskActivity::class.java).putExtra("q", if (has("game", "بازی")) "This is a game screen. Give one short helpful tip." else "Briefly explain what is on this screen; translate foreign text."))
            return if (fa) "اعلان را لمس کنید و اجازه ضبط صفحه را بدهید." else "Tap the notification and allow screen capture." }
        if (has("open finance", "show chart", "expenses screen", "نمودار", "صفحه هزینه")) return go(FinanceActivity::class.java, "Opening finance.", "مالی باز شد.")
        if (has("open safety", "security dashboard", "داشبورد امنیت", "صفحه امنیت")) return go(SafetyActivity::class.java, "Opening safety.", "امنیت باز شد.")
        if (has("open recorder", "record audio", "record video", "ضبط صدا", "ضبط ویدئو", "ضبط ویدیو", "open media")) return go(MediaActivity::class.java, "Opening recorder.", "ضبط باز شد.")
        if (has("open files", "file intelligence", "analyze file", "summarize pdf", "خلاصه pdf", "تحلیل فایل", "جستجوی فایل", "search files", "find file")) {
            val q = if (has("find file", "search files", "جستجوی فایل")) t.replace(Regex("find file|search files|for |جستجوی فایل"), "").trim() else ""
            return go(FilesActivity::class.java, "Opening files.", "فایل‌ها باز شد.", "q" to q) }
        if (has("open modes", "list modes", "حالت‌ها")) return go(ModesActivity::class.java, "Opening modes.", "حالت‌ها باز شد.")
        if (has("open memory", "show memory", "حافظه")) return go(ListActivity::class.java, "Opening memory.", "حافظه باز شد.", "key" to "memory", "title" to "Memory", "hint" to "Add a fact about you")
        if (has("open tasks", "open todo", "لیست کارها را باز")) return go(ListActivity::class.java, "Opening tasks.", "کارها باز شد.", "key" to "tasks", "title" to "Tasks", "hint" to "New task")
        if (has("open commands", "my commands", "custom commands", "فرمان‌های من", "فرمان های من")) return go(ListActivity::class.java, "Opening commands.", "فرمان‌ها باز شد.", "key" to "cmds", "title" to "Custom commands", "hint" to "phrase=>step 1;;step 2")
        return null
    }
}
