package com.jarvis.ai
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics

/** Screen Intelligence with explicit consent each time (Android system dialog). No overlay. */
class ScreenAskActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val m = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION") startActivityForResult(m.createScreenCaptureIntent(), 1)
    }
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (res == RESULT_OK && data != null)
            startForegroundService(Intent(this, ScreenCaptureService::class.java).putExtra("code", res).putExtra("data", data).putExtra("q", intent.getStringExtra("q") ?: "Briefly explain what is on this screen."))
        finish()
    }
}

class ScreenCaptureService : Service() {
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i == null) { stopSelf(); return START_NOT_STICKY }
        Notif.channels(this)
        val n = Notification.Builder(this, Notif.CH_SVC).setSmallIcon(android.R.drawable.ic_menu_camera).setContentTitle("JARVIS").setContentText("Analyzing screen...").build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(2, n)
        @Suppress("DEPRECATION") val data: Intent = i.getParcelableExtra("data")!!
        val mp = (getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).getMediaProjection(i.getIntExtra("code", 0), data)
        val q = i.getStringExtra("q") ?: ""
        val h = Handler(Looper.getMainLooper())
        mp.registerCallback(object : MediaProjection.Callback() {}, h)
        val dm = DisplayMetrics(); @Suppress("DEPRECATION") (getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager).defaultDisplay.getRealMetrics(dm)
        val w = dm.widthPixels / 2; val hh = dm.heightPixels / 2
        val ir = ImageReader.newInstance(w, hh, PixelFormat.RGBA_8888, 2)
        val vd = mp.createVirtualDisplay("jarvis", w, hh, dm.densityDpi / 2, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, ir.surface, null, h)
        h.postDelayed({
            var bmp: Bitmap? = null
            try { ir.acquireLatestImage()?.use { img ->
                val p = img.planes[0]; val rw = p.rowStride / p.pixelStride
                val b = Bitmap.createBitmap(rw, hh, Bitmap.Config.ARGB_8888); b.copyPixelsFromBuffer(p.buffer); bmp = Bitmap.createBitmap(b, 0, 0, w, hh) } } catch (_: Exception) {}
            vd.release(); ir.close(); mp.stop()
            Thread {
                val r = if (bmp == null) "Could not capture the screen." else Llm.ask(this, q, bmp, withHistory = false)
                Store.add(this, "user", "[screen] $q"); Store.add(this, "assistant", r)
                h.post { Speaker.speak(this, r) { stopSelf() }
                    (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(3, Notification.Builder(this, Notif.CH_ALERT).setSmallIcon(android.R.drawable.ic_menu_camera).setContentTitle("JARVIS").setContentText(r).setStyle(Notification.BigTextStyle().bigText(r)).build()) }
            }.start()
        }, 800)
        return START_NOT_STICKY
    }
}
