package com.jarvis.ai
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.Build
import android.service.quicksettings.TileService
import android.widget.RemoteViews

private fun launch(c: Context) = Intent(c, MainActivity::class.java).putExtra("auto", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)

/** Normal home-screen widget (not an overlay). */
class JarvisWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        val v = RemoteViews(c.packageName, R.layout.widget)
        v.setOnClickPendingIntent(R.id.wbtn, PendingIntent.getActivity(c, 5, launch(c), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        v.setOnClickPendingIntent(R.id.wask, PendingIntent.getActivity(c, 7, Intent(c, QuickAskActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE))
        ids.forEach { m.updateAppWidget(it, v) }
    }
}
class JarvisTile : TileService() {
    override fun onClick() {
        val i = launch(this)
        if (Build.VERSION.SDK_INT >= 34) startActivityAndCollapse(PendingIntent.getActivity(this, 6, i, PendingIntent.FLAG_IMMUTABLE))
        else @Suppress("DEPRECATION") startActivityAndCollapse(i)
    }
}
