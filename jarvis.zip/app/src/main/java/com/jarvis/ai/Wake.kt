package com.jarvis.ai
import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import android.content.Context

/** Optional low-power wake-word engine (Picovoice Porcupine, built-in keyword "Jarvis"). Active only when a free AccessKey is saved in Settings;
 *  otherwise JARVIS falls back to Android speech recognition. If this file ever blocks the build, delete it and the dependency line. */
object Wake {
    private var pm: PorcupineManager? = null; private var on = false
    fun start(c: Context, onWake: () -> Unit): Boolean {
        val key = Store.secret(c, "picovoice"); if (key.isBlank()) return false
        return try {
            if (pm == null) pm = PorcupineManager.Builder().setAccessKey(key).setKeyword(Porcupine.BuiltInKeyword.JARVIS)
                .setSensitivity(if (Store.int(c, "sens", 1) >= 2) 0.8f else 0.6f).build(c.applicationContext, PorcupineManagerCallback { onWake() })
            if (!on) { pm!!.start(); on = true }; true
        } catch (e: Exception) { ErrorLog.e(c, "porcupine", e); pm = null; on = false; false }
    }
    fun pause() { if (on) try { pm?.stop() } catch (_: Exception) {}; on = false }
    fun release() { pause(); try { pm?.delete() } catch (_: Exception) {}; pm = null }
}
