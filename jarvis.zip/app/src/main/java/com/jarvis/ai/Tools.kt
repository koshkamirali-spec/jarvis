package com.jarvis.ai
import android.content.Context
import android.content.Intent
import android.provider.CalendarContract
import java.text.SimpleDateFormat
import java.util.*

/** Daily tools: calculator, units, time, alarm, timer, stopwatch, reminders, tasks, lists, habits, goals, notes, calendar. */
object Tools {
    private val faMonths = listOf("فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")
    fun handle(c: Context, t: String, raw: String, fa: Boolean): String? {
        fun has(vararg k: String) = k.any { t.contains(it) }
        fun r(en: String, f: String) = if (fa) f else en
        // calculator & units
        val expr = Logic.extractExpr(raw)
        if (expr != null && (has("calc", "what is", "what's", "حساب", "چند", "چقدر", "=") || raw.trim() == expr)) Logic.calc(expr)?.let { return "$expr = ${Logic.fmt(it)}" }
        if (has("convert", "تبدیل", " to ", " به ")) Logic.convert(raw)?.let { return it }
        // time & date
        if (has("what time", "time is it", "ساعت چنده", "ساعت چند")) return SimpleDateFormat("HH:mm", Locale.US).format(Date())
        if (has("what date", "today's date", "what day", "تاریخ امروز", "امروز چندم")) {
            val g = SimpleDateFormat("EEEE d MMMM yyyy", Locale.US).format(Date())
            if (!fa) return g
            val p = android.icu.util.PersianCalendar(); return "${p.get(Calendar.DAY_OF_MONTH)} ${faMonths[p.get(Calendar.MONTH)]} ${p.get(Calendar.YEAR)} ($g)" }
        if (has("daily report", "weekly report", "report of my day", "گزارش روزانه", "گزارش هفتگی")) {
            val study = Store.list(c, "study").sumOf { it.split("|").getOrNull(1)?.toIntOrNull() ?: 0 }
            val habits = Store.list(c, "habits").joinToString("، ") { it.split("|").let { p -> "${p[0]} ${p.getOrNull(1) ?: 0}🔥" } }
            return if (fa) "گزارش: ${Store.list(c, "done").size} کار انجام‌شده، ${Store.list(c, "tasks").size} کار باقی‌مانده. عادت‌ها: ${habits.ifEmpty { "—" }}. مطالعه: $study دقیقه. ${Fin.report(c, true)}"
            else "Report: ${Store.list(c, "done").size} tasks done, ${Store.list(c, "tasks").size} pending. Habits: ${habits.ifEmpty { "—" }}. Study: $study min. ${Fin.report(c, false)}" }
        // stopwatch
        if (has("stopwatch", "کرنومتر")) {
            val s = Store.long(c, "sw")
            if (has("start", "شروع") ) { Store.setLong(c, "sw", System.currentTimeMillis()); return r("Stopwatch started.", "کرنومتر شروع شد.") }
            if (s == 0L) return r("Stopwatch is not running.", "کرنومتر روشن نیست.")
            val sec = (System.currentTimeMillis() - s) / 1000; val txt = "%d:%02d".format(sec / 60, sec % 60)
            if (has("stop", "توقف", "پایان")) Store.setLong(c, "sw", 0)
            return r("Elapsed $txt.", "زمان سپری‌شده $txt.")
        }
        // timer / alarm / reminder
        if (has("timer", "تایمر")) { val ms = Logic.parseMillis(t) ?: return r("For how long?", "چه مدت؟"); Router.schedule(c, ms, "⏱ Timer finished", alarm = true); return r("Timer set for ${ms / 60000} min ${ms / 1000 % 60} s.", "تایمر ${ms / 60000} دقیقه تنظیم شد.") }
        if (has("alarm", "wake me", "آلارم", "زنگ هشدار", "بیدارم کن")) {
            val ms = untilClock(t) ?: Logic.parseMillis(t) ?: return r("What time? e.g. “alarm at 7:30”.", "چه ساعتی؟ مثلاً «آلارم ساعت ۷:۳۰»")
            Router.schedule(c, ms, "⏰ Alarm", alarm = true); val at = SimpleDateFormat("HH:mm", Locale.US).format(Date(System.currentTimeMillis() + ms)); return r("Alarm set for $at.", "آلارم برای $at تنظیم شد.") }
        if (has("remind me", "یادآوری", "یادم بنداز", "یادآور")) {
            val ms = Logic.parseMillis(t) ?: untilClock(t) ?: return r("When? e.g. “remind me in 10 minutes to call mom”.", "چه زمانی؟ مثلاً «۱۰ دقیقه دیگه یادم بنداز …»")
            val what = t.substringAfter(" to ", "").ifBlank { raw }; Router.schedule(c, ms, "🔔 $what"); return r("I'll remind you in ${ms / 60000} min.", "${ms / 60000} دقیقه دیگر یادآوری می‌کنم.") }
        // calendar event (opens the calendar form; you press Save)
        if (has("add event", "new event", "appointment", "قرار ", "رویداد جدید")) {
            val ms = Logic.parseMillis(t) ?: untilClock(t) ?: 3_600_000L; val st = System.currentTimeMillis() + ms
            Router.open(c, "Calendar event", Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI).putExtra(CalendarContract.Events.TITLE, raw).putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, st).putExtra(CalendarContract.EXTRA_EVENT_END_TIME, st + 3_600_000L))
            return r("Calendar form opened; press Save to confirm.", "فرم تقویم باز شد؛ ذخیره را بزنید.") }
        // tasks
        if (has("add task", "new task", "todo ", "کار جدید", "کاری اضافه", "تسک")) { val x = raw.replace(Regex("(?i)add task|new task|todo|کار جدید|اضافه کن|کاری|تسک"), "").trim(' ', ':', '،'); if (x.isEmpty()) return r("What task?", "چه کاری؟"); Store.push(c, "tasks", x); return r("Task added: $x", "کار اضافه شد: $x") }
        if (has("my tasks", "list tasks", "what's on my list", "کارهای من", "لیست کارها", "کارهایم")) return Store.list(c, "tasks").let { if (it.isEmpty()) r("No tasks.", "کاری نیست.") else it.mapIndexed { i, s -> "${i + 1}. $s" }.joinToString("\n") }
        if (has("done task", "complete task", "task done", "finished task", "انجام شد", "انجام دادم")) {
            val q = raw.replace(Regex("(?i)done|complete|task|finished|انجام شد|انجام دادم"), "").trim(); val l = Store.list(c, "tasks")
            val i = q.toIntOrNull()?.minus(1) ?: l.indexOfFirst { it.lowercase().contains(q.lowercase()) && q.isNotBlank() }
            if (i !in l.indices) return r("Which task?", "کدام کار؟"); val x = l[i]; Store.removeAt(c, "tasks", i); Store.push(c, "done", x); return r("Done: $x", "انجام شد: $x") }
        if (has("completed tasks", "done list", "کارهای انجام شده", "کارهای انجام‌شده")) return Store.list(c, "done").takeLast(10).ifEmpty { listOf(r("Nothing yet.", "هنوز چیزی نیست.")) }.joinToString("\n")
        // shopping
        if (has("shopping list", "لیست خرید")) {
            val m = Regex("(?i)add (.+?) to (?:my |the )?shopping").find(raw) ?: Regex("(.+?) را به لیست خرید").find(raw)
            if (m != null) { val x = m.groupValues[1].replace("اضافه کن", "").trim(); Store.push(c, "shopping", x); return r("Added $x.", "$x اضافه شد.") }
            if (has("clear", "پاک")) { Store.setList(c, "shopping", emptyList()); return r("Cleared.", "پاک شد.") }
            return Store.list(c, "shopping").ifEmpty { listOf(r("Shopping list is empty.", "لیست خرید خالی است.")) }.joinToString("، ") }
        // habits: entries "name|streak|yyyy-MM-dd"
        if (has("habit", "عادت")) {
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()); val l = Store.list(c, "habits")
            if (has("my habits", "list habits", "عادت‌های من", "عادت های من")) return l.map { it.split("|") }.ifEmpty { return r("No habits yet.", "عادتی ثبت نشده.") }.joinToString("\n") { "${it[0]}: ${it.getOrNull(1) ?: 0} 🔥" }
            val name = raw.replace(Regex("(?i)habit|done|add|عادت|انجام شد|اضافه کن|انجام دادم"), "").trim(); if (name.isEmpty()) return r("Which habit?", "کدام عادت؟")
            val i = l.indexOfFirst { it.substringBefore("|").equals(name, true) }
            if (i < 0) { Store.push(c, "habits", "$name|${if (has("done", "انجام")) 1 else 0}|${if (has("done", "انجام")) today else ""}"); return r("Habit “$name” added.", "عادت «$name» اضافه شد.") }
            val p = l[i].split("|"); val streak = p.getOrNull(1)?.toIntOrNull() ?: 0
            if (p.getOrNull(2) == today) return r("Already logged today: $streak 🔥", "امروز ثبت شده: $streak 🔥")
            val y = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(System.currentTimeMillis() - 86400000L)); val ns = if (p.getOrNull(2) == y) streak + 1 else 1
            Store.replaceAt(c, "habits", i, "${p[0]}|$ns|$today"); return r("${p[0]}: $ns day streak 🔥", "${p[0]}: $ns روز پیاپی 🔥") }
        // goals: "name|percent"
        if (has("goal", "هدف")) {
            val l = Store.list(c, "goals")
            if (has("my goals", "list goals", "اهداف من", "هدف‌های من")) return l.ifEmpty { return r("No goals yet.", "هدفی نیست.") }.joinToString("\n") { it.replace("|", ": ") + "%" }
            val pct = Regex("(\\d+)\\s*%?").find(Logic.digits(raw))?.groupValues?.get(1)?.toIntOrNull()
            val name = raw.replace(Regex("(?i)add goal|goal progress|goal|progress|\\d+\\s*%?|هدف|پیشرفت|اضافه کن|درصد"), "").trim(' ', ':', '،')
            val i = l.indexOfFirst { it.substringBefore("|").equals(name, true) }
            if (has("progress", "update", "پیشرفت") && pct != null && i >= 0) { Store.replaceAt(c, "goals", i, "$name|${pct.coerceIn(0, 100)}"); return r("$name: $pct%", "$name: $pct٪") }
            if (name.isNotEmpty() && i < 0) { Store.push(c, "goals", "$name|0"); return r("Goal added: $name", "هدف اضافه شد: $name") }
            return null }
        // notes
        if (has("read my notes", "read notes", "my notes", "یادداشت‌هایم را بخوان", "یادداشت‌های من")) return Store.list(c, "notes").takeLast(3).ifEmpty { listOf(r("No notes.", "یادداشتی نیست.")) }.joinToString(". ")
        if (has("note", "یادداشت")) { val x = raw.replace(Regex("(?i)take a note|add note|note|یادداشت کن|یادداشت"), "").trim(' ', ':', '،'); if (x.isEmpty()) return r("What should I note?", "چه چیزی یادداشت کنم؟"); Store.push(c, "notes", x); return r("Saved.", "ذخیره شد.") }
        // study log "date|minutes|topic"
        if (has("log study", "study progress", "ثبت مطالعه", "پیشرفت مطالعه")) {
            if (has("progress", "پیشرفت")) { val l = Store.list(c, "study"); return r("Studied ${l.sumOf { it.split("|").getOrNull(1)?.toIntOrNull() ?: 0 }} min over ${l.size} sessions.", "مجموع مطالعه ${l.sumOf { it.split("|").getOrNull(1)?.toIntOrNull() ?: 0 }} دقیقه در ${l.size} جلسه.") }
            val mins = Regex("(\\d+)").find(Logic.digits(t))?.value?.toIntOrNull() ?: return r("How many minutes?", "چند دقیقه؟")
            Store.push(c, "study", "${SimpleDateFormat("MM-dd", Locale.US).format(Date())}|$mins|${raw.substringAfter("on ", "")}"); return r("Logged $mins min.", "$mins دقیقه ثبت شد.") }
        return null
    }
    /** Milliseconds until the next "7:30"/"7 pm"/"ساعت ۷ صبح". */
    fun untilClock(t: String): Long? {
        val m = Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm|صبح|ظهر|عصر|شب)?").findAll(Logic.digits(t).lowercase()).firstOrNull { it.groupValues[2].isNotEmpty() || it.groupValues[3].isNotEmpty() || t.contains("at ") || t.contains("ساعت") } ?: return null
        var h = m.groupValues[1].toInt(); val min = m.groupValues[2].ifEmpty { "0" }.toInt(); val ap = m.groupValues[3]
        if ((ap == "pm" || ap == "عصر" || ap == "شب") && h < 12) h += 12; if ((ap == "am" || ap == "صبح") && h == 12) h = 0
        if (h > 23 || min > 59) return null
        val now = Calendar.getInstance(); val at = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, min); set(Calendar.SECOND, 0) }
        if (at.before(now)) at.add(Calendar.DAY_OF_MONTH, 1); return at.timeInMillis - now.timeInMillis
    }
}

/** Shared long-term memory: only what you explicitly ask JARVIS to remember. View/edit/delete in the Memory screen. */
object Memory {
    fun handle(c: Context, t: String, raw: String, fa: Boolean): String? {
        fun has(vararg k: String) = k.any { t.contains(it) }
        fun r(en: String, f: String) = if (fa) f else en
        if (has("remember that", "remember my", "یادت باشه", "به خاطر بسپار", "یادت باشد")) {
            val x = raw.replace(Regex("(?i)remember that|remember|یادت باشه|یادت باشد|به خاطر بسپار"), "").trim(' ', ':', '،'); if (x.isEmpty()) return null
            Store.push(c, "memory", x, 200); return r("I'll remember that.", "یادم می‌ماند.") }
        if (has("forget ", "فراموش کن")) { val q = raw.replace(Regex("(?i)forget|فراموش کن"), "").trim().lowercase(); val l = Store.list(c, "memory"); val i = l.indexOfFirst { q.isNotBlank() && it.lowercase().contains(q) }
            if (i < 0) return r("I don't have that in memory.", "چنین چیزی در حافظه نیست."); Store.removeAt(c, "memory", i); return r("Forgotten.", "فراموش شد.") }
        if (has("what do you know about me", "what do you remember", "چی درباره من میدونی", "چه چیزی یادته")) return Store.list(c, "memory").ifEmpty { listOf(r("Nothing saved yet.", "هنوز چیزی ذخیره نشده.")) }.joinToString("؛ ")
        if (Store.bool(c, "learn_prefs", true) && (Regex("^i (really )?(like|love|prefer|hate|enjoy) ").containsMatchIn(t) || has("دوست دارم", "ترجیح میدم", "ترجیح می‌دم", "متنفرم")) && !t.contains("?"))
            return Confirm.ask(fa, "Should I remember this about you: “$raw”", "این را درباره شما یادم بماند: «$raw»") { Store.push(c, "memory", raw, 200); if (fa) "ذخیره شد." else "Saved." }
        if (has("clear memory", "delete all memory", "پاک کردن حافظه", "حافظه را پاک")) return Confirm.ask(fa, "Delete ALL saved memory", "همه حافظه پاک شود") { Store.setList(c, "memory", emptyList()); if (fa) "حافظه پاک شد." else "Memory cleared." }
        if (has("clear history", "delete history", "پاک کردن تاریخچه")) return Confirm.ask(fa, "Delete conversation history", "تاریخچه گفتگو پاک شود") { Store.clearHistory(c); if (fa) "تاریخچه پاک شد." else "History cleared." }
        return null
    }
}

/** Manual finance organizer. Entries "ts|type|cat|amount|note"; never makes transactions. */
object Fin {
    fun entries(c: Context) = Store.list(c, "fin").mapNotNull { e -> e.split("|").takeIf { it.size >= 4 }?.let { Triple(it[0].toLongOrNull() ?: 0L, it[1] to it[2], it[3].toDoubleOrNull() ?: 0.0) } }
    fun monthStart(): Long = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }.timeInMillis
    fun byCategory(c: Context): Map<String, Double> = entries(c).filter { it.first >= monthStart() && it.second.first == "exp" }.groupBy { it.second.second }.mapValues { e -> e.value.sumOf { it.third } }
    fun report(c: Context, fa: Boolean): String {
        val m = entries(c).filter { it.first >= monthStart() }; val inc = m.filter { it.second.first == "inc" }.sumOf { it.third }; val exp = m.filter { it.second.first == "exp" }.sumOf { it.third }
        val cats = byCategory(c).entries.sortedByDescending { it.value }.take(4).joinToString("، ") { "${it.key} ${Logic.fmt(it.value)}" }
        val over = Store.list(c, "budget").mapNotNull { b -> val p = b.split("|"); val spent = byCategory(c)[p[0]] ?: 0.0; if (p.size > 1 && spent > (p[1].toDoubleOrNull() ?: Double.MAX_VALUE)) "${p[0]} (${Logic.fmt(spent)}/${p[1]})" else null }
        return (if (fa) "این ماه: درآمد ${Logic.fmt(inc)}، هزینه ${Logic.fmt(exp)}، مانده ${Logic.fmt(inc - exp)}. " else "This month: income ${Logic.fmt(inc)}, expenses ${Logic.fmt(exp)}, balance ${Logic.fmt(inc - exp)}. ") +
            (if (cats.isNotEmpty()) (if (fa) "بیشترین: $cats. " else "Top: $cats. ") else "") + (if (over.isNotEmpty()) (if (fa) "⚠ فراتر از بودجه: ${over.joinToString()}" else "⚠ Over budget: ${over.joinToString()}") else "")
    }
    fun handle(c: Context, t: String, fa: Boolean): String? {
        fun has(vararg k: String) = k.any { t.contains(it) }
        fun r(en: String, f: String) = if (fa) f else en
        val d = Logic.digits(t); val num = Regex("(\\d+(?:\\.\\d+)?)").find(d)?.groupValues?.get(1)?.toDoubleOrNull()
        if (has("monthly report", "expense report", "گزارش هزینه", "گزارش مالی")) return report(c, fa)
        if (has("budget", "بودجه") && num != null) { val cat = d.replace(Regex("(?i)budget|بودجه|set|for|\\d+(?:\\.\\d+)?"), "").trim().ifEmpty { "total" }
            val l = Store.list(c, "budget"); val i = l.indexOfFirst { it.startsWith("$cat|") }; if (i >= 0) Store.replaceAt(c, "budget", i, "$cat|${Logic.fmt(num)}") else Store.push(c, "budget", "$cat|${Logic.fmt(num)}"); return r("Budget for $cat: ${Logic.fmt(num)}.", "بودجه $cat: ${Logic.fmt(num)}.") }
        if (has("expense", "spent", "هزینه", "خرج") && num != null) { val cat = d.replace(Regex("(?i)expense|spent|on|هزینه|خرج|کردم|برای|\\d+(?:\\.\\d+)?"), "").trim().ifEmpty { "other" }
            Store.push(c, "fin", "${System.currentTimeMillis()}|exp|$cat|$num|"); return r("Logged expense ${Logic.fmt(num)} ($cat).", "هزینه ${Logic.fmt(num)} ($cat) ثبت شد.") }
        if (has("income", "salary", "earned", "درآمد", "حقوق") && num != null) { Store.push(c, "fin", "${System.currentTimeMillis()}|inc|income|$num|"); return r("Logged income ${Logic.fmt(num)}.", "درآمد ${Logic.fmt(num)} ثبت شد.") }
        if (has("payment", "پرداخت", "bill", "قبض") && has("remind", "یادآوری")) { val days = Regex("(\\d+)\\s*(day|days|روز)").find(d)?.groupValues?.get(1)?.toLongOrNull() ?: return r("In how many days?", "چند روز دیگر؟")
            Router.schedule(c, days * 86_400_000L, "💳 Payment due: ${t.take(60)}"); return r("Payment reminder in $days days.", "یادآوری پرداخت $days روز دیگر.") }
        return null
    }
}
