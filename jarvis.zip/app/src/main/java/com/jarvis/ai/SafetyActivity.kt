package com.jarvis.ai
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager

/** Security dashboard: real status of every safety feature. */
class SafetyActivity : GuardedActivity() {
    override fun build() {
        val r = Ui.screen(this, "🛡 Security Dashboard")
        fun ok(b: Boolean) = if (b) "✓" else "✗"
        val cs = Safety.contacts(this)
        r.addView(Ui.text(this, "${ok(cs.isNotEmpty())} Emergency contacts: ${cs.size}\n${ok(Store.secret(this, "emergency_id").isNotEmpty())} Emergency ID saved\n" +
            "${ok(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)} Location permission\n${ok(Store.bool(this, "privacy_lock"))} Privacy lock\n" +
            "${ok(Store.apiKey(this).isNotEmpty())} API key stored encrypted\n${ok(Journey.active(this))} Journey: ${Store.str(this, "journey").substringBefore("|").ifEmpty { "none" }}\n" +
            "${ok(Store.int(this, "check_h") > 0)} Safety check every ${Store.int(this, "check_h")} h\nLast emergency test: ${Store.str(this, "last_test", "never")}", 15))
        r.addView(Ui.button(this, "Emergency contacts (name|number)") { startActivity(Intent(this, ListActivity::class.java).putExtra("key", "emergency").putExtra("title", "Emergency contacts").putExtra("hint", "Mom|+989121234567")) })
        r.addView(Ui.button(this, "Edit Emergency ID (name, blood type, allergies…)") { Ui.ask(this, "Emergency ID", "Name, blood type, allergies, conditions", Store.secret(this, "emergency_id")) { Store.setSecret(this, "emergency_id", it); recreate() } })
        r.addView(Ui.button(this, "Show Emergency ID (works offline / lock screen)") { startActivity(Intent(this, EmergencyInfoActivity::class.java)) })
        r.addView(Ui.button(this, "Test emergency (safe, labelled TEST)") { Store.setStr(this, "last_test", java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.US).format(java.util.Date())); startActivity(Intent(this, EmergencyActivity::class.java).putExtra("level", 1).putExtra("test", true)) })
        r.addView(Ui.button(this, "Danger 1 – silent alert (message + location)") { startActivity(Intent(this, EmergencyActivity::class.java).putExtra("level", 1)) })
        r.addView(Ui.button(this, "Danger 2 – siren + message + call") { startActivity(Intent(this, EmergencyActivity::class.java).putExtra("level", 2)) })
        r.addView(Ui.button(this, "Siren on/off") { if (EmergencySound.on) EmergencySound.stop() else EmergencySound.start(this) })
        r.addView(Ui.button(this, "Fake call (name…)") { Ui.ask(this, "Caller name", "Mom", Store.str(this, "fake_name", "Mom")) { Store.setStr(this, "fake_name", it); startActivity(Intent(this, FakeCallActivity::class.java).putExtra("name", it)) } })
        r.addView(Ui.button(this, "Start safety check (hours)") { Ui.ask(this, "Ask me every N hours", "4", "4") { Check.start(this, it.toIntOrNull() ?: 4); recreate() } })
        r.addView(Ui.button(this, "Stop safety check") { Check.stop(this); recreate() })
        r.addView(Ui.button(this, "Start safe journey") { Ui.ask(this, "Destination", "Home") { d -> Ui.ask(this, "Minutes", "30", "30") { m -> Journey.start(this, d, (m.toLongOrNull() ?: 30L) * 60_000L); recreate() } } })
        r.addView(Ui.button(this, "I arrived (end journey)") { Journey.arrive(this); recreate() })
        r.addView(Ui.text(this, "Alert log (what was prepared):\n" + Store.list(this, "sec_log").takeLast(5).joinToString("\n").ifEmpty { "(none yet)" }, 12, Ui.CYAN))
        r.addView(Ui.text(this, "JARVIS never sends messages or places calls secretly: the SMS/dialer app opens ready and you press send/call. Delivery cannot be confirmed by the app.", 12, 0xFF8888AA.toInt()))
    }
}
