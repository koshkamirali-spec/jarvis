package com.jarvis.ai
import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import java.security.KeyStore
import java.text.SimpleDateFormat
import java.util.*
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** AES-GCM with an Android Keystore key: secrets (API keys, emergency ID) are never stored in plain text. */
object Crypto {
    private const val ALIAS = "jarvis_key"
    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        return g.generateKey()
    }
    fun enc(s: String): String {
        if (s.isEmpty()) return ""
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE, key())
        return Base64.encodeToString(c.iv + c.doFinal(s.toByteArray()), Base64.NO_WRAP)
    }
    fun dec(s: String): String {
        if (s.isEmpty()) return ""
        return try {
            val b = Base64.decode(s, Base64.NO_WRAP); val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, b, 0, 12)); String(c.doFinal(b, 12, b.size - 12))
        } catch (e: Exception) { "" }
    }
}

private class Db(c: Context) : SQLiteOpenHelper(c.applicationContext, "jarvis.db", null, 1) {
    override fun onCreate(d: SQLiteDatabase) { d.execSQL("CREATE TABLE lists(k TEXT NOT NULL, i INTEGER NOT NULL, v TEXT NOT NULL, PRIMARY KEY(k, i))") }
    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}
}

/** One shared settings + memory + data store for every module. Settings: SharedPreferences. Lists, history, finance, memory: local SQLite. */
object Store {
    private fun p(c: Context) = c.applicationContext.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    fun str(c: Context, k: String, d: String = "") = p(c).getString(k, d) ?: d
    fun setStr(c: Context, k: String, v: String) = p(c).edit().putString(k, v).apply()
    fun int(c: Context, k: String, d: Int = 0) = p(c).getInt(k, d)
    fun setInt(c: Context, k: String, v: Int) = p(c).edit().putInt(k, v).apply()
    fun bool(c: Context, k: String, d: Boolean = false) = p(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) = p(c).edit().putBoolean(k, v).apply()
    fun long(c: Context, k: String, d: Long = 0L) = p(c).getLong(k, d)
    fun setLong(c: Context, k: String, v: Long) = p(c).edit().putLong(k, v).apply()
    fun secret(c: Context, k: String) = Crypto.dec(str(c, "s_$k"))
    fun setSecret(c: Context, k: String, v: String) = setStr(c, "s_$k", Crypto.enc(v.trim()))
    private var db: Db? = null; @Volatile private var migrated = false
    private fun d(c: Context): SQLiteDatabase { if (db == null) synchronized(this) { if (db == null) db = Db(c) }; return db!!.writableDatabase }
    private fun putRaw(c: Context, k: String, l: List<String>) {
        val x = d(c); x.beginTransaction()
        try { x.delete("lists", "k=?", arrayOf(k)); l.forEachIndexed { i, v -> x.execSQL("INSERT INTO lists(k,i,v) VALUES(?,?,?)", arrayOf<Any>(k, i, v)) }; x.setTransactionSuccessful() } finally { x.endTransaction() }
    }
    /** One-time move of lists from the old SharedPreferences format into SQLite. */
    private fun migrate(c: Context) {
        if (migrated) return
        synchronized(this) {
            if (migrated) return
            val ed = p(c).edit(); var any = false
            for ((k, v) in p(c).all) if (k.startsWith("l_") && v is String) { try { val a = JSONArray(v); putRaw(c, k.substring(2), List(a.length()) { a.getString(it) }) } catch (e: Exception) {}; ed.remove(k); any = true }
            if (any) ed.apply(); migrated = true
        }
    }
    fun list(c: Context, k: String): MutableList<String> {
        migrate(c); val out = mutableListOf<String>()
        d(c).rawQuery("SELECT v FROM lists WHERE k=? ORDER BY i", arrayOf(k)).use { while (it.moveToNext()) out.add(it.getString(0)) }; return out
    }
    fun setList(c: Context, k: String, l: List<String>) { migrate(c); putRaw(c, k, l) }
    fun allLists(c: Context): Map<String, List<String>> {
        migrate(c); val keys = mutableListOf<String>(); d(c).rawQuery("SELECT DISTINCT k FROM lists", null).use { while (it.moveToNext()) keys.add(it.getString(0)) }
        return keys.filter { it != "hist" && it != "errors" }.associateWith { list(c, it) }
    }
    fun push(c: Context, k: String, v: String, max: Int = 500) { val l = list(c, k); l.add(v); setList(c, k, l.takeLast(max)) }
    fun removeAt(c: Context, k: String, i: Int) { val l = list(c, k); if (i in l.indices) { l.removeAt(i); setList(c, k, l) } }
    fun replaceAt(c: Context, k: String, i: Int, v: String) { val l = list(c, k); if (i in l.indices) { l[i] = v; setList(c, k, l) } }
    fun all(c: Context): Map<String, *> = p(c).all
    fun wipe(c: Context) { p(c).edit().clear().apply(); migrate(c); d(c).delete("lists", null, null) }
    fun apiKey(c: Context) = secret(c, "gemini")
    // conversation (shared by voice, text, camera, files)
    fun add(c: Context, role: String, text: String) = push(c, "hist", "$role\u0001$text", 60)
    fun recent(c: Context, n: Int = 6): List<Pair<String, String>> = list(c, "hist").takeLast(n).map { it.substringBefore('\u0001') to it.substringAfter('\u0001') }
    fun transcript(c: Context) = recent(c, 60).joinToString("\n\n") { (r, t) -> (if (r == "user") "▸ " else "◆ ") + t }
    fun clearHistory(c: Context) = setList(c, "hist", emptyList())
    fun moduleOn(c: Context, id: String) = bool(c, "mod_$id", true)
}

object Lang {
    fun fa(c: Context, text: String = "") = if (text.isNotEmpty() && Logic.isPersian(text)) true else Store.str(c, "lang").ifBlank { Locale.getDefault().toLanguageTag() }.startsWith("fa")
    fun tag(c: Context) = Store.str(c, "lang")
}

object ErrorLog {
    fun e(c: Context, tag: String, t: Throwable) = Store.push(c, "errors", SimpleDateFormat("MM-dd HH:mm", Locale.US).format(Date()) + " $tag: ${t.message ?: t.javaClass.simpleName}", 30)
}
object App { @Volatile var visible = false }
