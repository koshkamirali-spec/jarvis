package com.jarvis.ai
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.WifiManager
import android.os.BatteryManager
import java.util.Calendar

data class Mode(val id: String, val title: String, val fa: String, val dnd: Boolean, val prompt: String, val readNotifs: Boolean = false)

/** Smart modes: change assistant behaviour (system prompt), Do-Not-Disturb and notification reading. */
object Modes {
    val all = listOf(
        Mode("normal", "Normal", "عادی", false, ""),
        Mode("driving", "Driving", "رانندگی", true, "Driving mode: answer in ONE very short sentence; the user is driving.", true),
        Mode("study", "Study", "مطالعه", true, "Study mode: act as a patient tutor, explain step by step but briefly."),
        Mode("gaming", "Gaming", "بازی", true, "Gaming mode: keep replies under 12 words."),
        Mode("focus", "Focus", "تمرکز", true, "Focus mode: be minimal, no small talk."),
        Mode("sleep", "Sleep", "خواب", true, "Sleep mode: calm and very brief."),
        Mode("training", "Training", "تمرین", false, "Training mode: act as an energetic, brief coach."),
        Mode("emergency", "Emergency", "اضطراری", false, "Emergency mode: calm, direct, safety-first instructions."),
        Mode("work", "Work", "کار", false, "Work mode: professional and efficient."),
        Mode("cinema", "Cinema", "سینما", true, "Cinema mode: whisper-brief replies."),
        Mode("meeting", "Meeting", "جلسه", true, "Meeting mode: only essential, very short replies."),
        Mode("travel", "Travel", "سفر", false, "Travel mode: help with directions, translation and local tips."),
        Mode("custom", "Custom", "سفارشی", false, ""))

    fun current(c: Context) = all.firstOrNull { it.id == Store.str(c, "mode", "normal") } ?: all[0]
    fun prompt(c: Context): String = current(c).let { if (it.id == "custom") Store.str(c, "custom_prompt") else it.prompt }
    fun title(c: Context, m: Mode, fa: Boolean) = if (m.id == "custom" && Store.str(c, "custom_name").isNotBlank()) Store.str(c, "custom_name") else if (fa) m.fa else m.title

    fun set(c: Context, id: String) {
        val m = all.first { it.id == id }; val prev = current(c).id
        Store.setStr(c, "mode", id)
        dnd(c, Store.str(c, "mode_${id}_dnd").let { if (it.isEmpty()) m.dnd else it == "1" })
        if (id == "gaming") Gaming.start(c) else if (prev == "gaming") Gaming.stop(c)
    }
    fun readsNotifs(c: Context): Boolean = current(c).let { m -> Store.str(c, "mode_${m.id}_read").let { if (it.isEmpty()) m.readNotifs else it == "1" } }
    fun dnd(c: Context, on: Boolean): Boolean {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) return false
        nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL); return true
    }
    fun handle(c: Context, t: String, fa: Boolean): String? {
        if (t.contains("exit gaming")) { set(c, "normal"); return if (fa) "حالت عادی." else "Normal mode." }
        if (!(t.contains("mode") || t.contains("حالت"))) return null
        if (listOf("exit", "off", "normal", "خروج", "خاموش", "عادی").any { t.contains(it) }) { set(c, "normal"); return if (fa) "حالت عادی فعال شد." else "Normal mode on." }
        val m = all.firstOrNull { it.id != "normal" && (t.contains(it.title.lowercase()) || t.contains(it.fa) || (it.id == "custom" && Store.str(c, "custom_name").let { n -> n.isNotBlank() && t.contains(n.lowercase()) })) } ?: return null
        set(c, m.id)
        val dndNote = if (m.dnd && !(c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).isNotificationPolicyAccessGranted) (if (fa) " (برای مزاحم نشوید، مجوز را در تنظیمات بدهید.)" else " (Grant Do Not Disturb access in Settings to silence notifications.)") else ""
        return (if (fa) "حالت ${title(c, m, true)} فعال شد." else "${title(c, m, false)} mode on.") + dndNote
    }
    val btConnected: MutableSet<String> = java.util.Collections.synchronizedSet(mutableSetOf<String>())
    private fun charging(c: Context): Boolean { val b = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)); val st = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1); return st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL }
    private fun ssid(c: Context): String = try { @Suppress("DEPRECATION") (c.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).connectionInfo?.ssid?.trim('"') ?: "" } catch (e: Exception) { "" }
    private fun matches(c: Context, rule: String): Boolean = when (val r = Logic.parseRule(rule)) {
        null -> false; is ModeRule.Time -> Logic.inRange(Calendar.getInstance().get(Calendar.HOUR_OF_DAY), r.a, r.b)
        is ModeRule.Wifi -> ssid(c).equals(r.ssid, true); ModeRule.Charging -> charging(c); is ModeRule.Bt -> synchronized(btConnected) { btConnected.any { it.contains(r.name, true) } } }
    /** Automatic activation: rules like "22-6", "wifi:HomeName", "charging", "bt:CarName" saved as auto_<id>. Evaluated while the voice service or the app is active. */
    fun tick(c: Context) {
        for (m in all) {
            val r = Store.str(c, "auto_${m.id}"); if (r.isBlank()) continue
            val inR = matches(c, r)
            if (inR && current(c).id != m.id && Store.str(c, "auto_on") != m.id) { Store.setStr(c, "auto_on", m.id); set(c, m.id) }
            if (!inR && Store.str(c, "auto_on") == m.id) { Store.setStr(c, "auto_on", ""); if (current(c).id == m.id) set(c, "normal") }
        }
    }
}
