package com.jarvis.ai
import android.Manifest
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.MediaStore
import android.widget.LinearLayout
import android.net.Uri
import android.os.Bundle
import android.widget.TextView

/** File Intelligence: pick any file (the system picker has its own search), then summarize / OCR / translate / search inside / auto-name. */
class FilesActivity : BaseActivity() {
    private var uri: Uri? = null; private var mime = ""; private lateinit var info: TextView; private lateinit var out: TextView
    override fun onCreate(s: Bundle?) {
        super.onCreate(s); val r = Ui.screen(this, "📂 File Intelligence")
        info = Ui.text(this, "No file selected. Supported: PDF, images, audio, text.", 14, Ui.CYAN); r.addView(info)
        r.addView(Ui.button(this, "Choose / search a file") { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/pdf", "image/*", "audio/*", "text/*", "application/json")), 1) })
        r.addView(Ui.button(this, "Summarize") { go("Summarize this file in 3-5 short sentences.") })
        r.addView(Ui.button(this, "Extract key information") { go("Extract the most important information: names, dates, numbers, amounts, action items. Short list.") })
        r.addView(Ui.button(this, "Image → text (OCR)") { go("Extract all text exactly as written.", 1500) })
        r.addView(Ui.button(this, "Translate (Persian ⇄ English)") { go("Translate the content between Persian and English (to the other language).", 1200) })
        r.addView(Ui.button(this, "Search text inside") { Ui.ask(this, "Search inside file", "word or phrase") { q -> go("Find every passage about “$q”; quote each very briefly with its context. If none, say so.", 700) } })
        r.addView(Ui.button(this, "Suggest name & category") { go("Suggest a short file name (max 5 words, no extension) and one category (document, receipt, photo, study, work, personal, other). Format: name | category", 80) })
        r.addView(Ui.button(this, "Open file") { uri?.let { startActivity(Intent(Intent.ACTION_VIEW, it).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) } })
        r.addView(Ui.button(this, "Share file") { uri?.let { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, it).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Share")) } })
        val q = Ui.edit(this, "Search phone media by file name (photos, videos, audio)"); r.addView(q)
        r.addView(Ui.button(this, "🔎 Search & categorize") { search(q.text.toString().trim()) })
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; r.addView(results)
        out = Ui.text(this, "", 15); r.addView(out)
        intent.getStringExtra("q")?.takeIf { it.isNotBlank() }?.let { q.setText(it); search(it) }
    }
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, d: Intent?) {
        super.onActivityResult(req, res, d); val u = d?.data ?: return; if (res != RESULT_OK) return
        uri = u; mime = contentResolver.getType(u) ?: "application/octet-stream"; info.text = "${FileUris.name(this, u)}  ($mime)"
    }
    private lateinit var results: LinearLayout; private var pendingQ = ""
    /** Android 11 lets apps search media (images/video/audio) with the storage permission; other documents: use the picker above. */
    private fun search(q: String) {
        if (q.isEmpty()) return
        val perms = if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        if (perms.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }) { pendingQ = q; requestPermissions(perms, 7); return }
        Thread {
            val res = mutableListOf<Triple<String, String, Uri>>(); val base = MediaStore.Files.getContentUri("external")
            try { contentResolver.query(base, arrayOf(MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.DISPLAY_NAME, MediaStore.Files.FileColumns.MIME_TYPE), "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE ?", arrayOf("%$q%"), "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC")
                ?.use { c -> while (c.moveToNext() && res.size < 40) res.add(Triple(c.getString(1) ?: "?", c.getString(2) ?: "", ContentUris.withAppendedId(base, c.getLong(0)))) } } catch (e: Exception) { ErrorLog.e(this, "filesearch", e) }
            runOnUiThread {
                results.removeAllViews(); if (res.isEmpty()) results.addView(Ui.text(this, "Nothing found.", 14))
                for ((cat, items) in res.groupBy { when { it.second.startsWith("image") -> "🖼 Images"; it.second.startsWith("video") -> "🎞 Videos"; it.second.startsWith("audio") -> "🎵 Audio"; it.second.contains("pdf") -> "📄 PDF"; else -> "📁 Other" } }) {
                    results.addView(Ui.text(this, "$cat (${items.size})", 16, Ui.GOLD, true))
                    items.forEach { (n, m, u) -> results.addView(Ui.button(this, n) { uri = u; mime = m.ifEmpty { "application/octet-stream" }; info.text = "$n  ($mime)" }) } }
            }
        }.start()
    }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) { if (c == 7 && r.isNotEmpty() && r.all { it == PackageManager.PERMISSION_GRANTED }) search(pendingQ) }
    private fun go(task: String, tokens: Int = 450) {
        val u = uri ?: return Ui.toast(this, "Choose a file first"); out.text = "Working…"; Brain.set(Brain.St.THINKING)
        Thread {
            val bytes = try { contentResolver.openInputStream(u)?.use { it.readBytes() } } catch (e: Exception) { ErrorLog.e(this, "file", e); null }
            val r = when {
                bytes == null -> "Could not read the file."
                bytes.size > 12_000_000 -> "File is larger than 12 MB."
                mime.startsWith("text") || mime.contains("json") -> Llm.ask(this, "$task\n\n${String(bytes).take(30000)}", withHistory = false, maxTokens = tokens)
                mime == "application/pdf" || mime.startsWith("image/") || mime.startsWith("audio/") -> Llm.ask(this, task, file = mime to bytes, withHistory = false, maxTokens = tokens)
                else -> "Unsupported file type ($mime)."
            }
            Store.add(this, "user", "[file] ${FileUris.name(this, u)}: $task".take(120)); Store.add(this, "assistant", r); Brain.set(Brain.St.IDLE)
            runOnUiThread { out.text = r }
        }.start()
    }
}
