package com.jarvis.ai
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.widget.*

class MainActivity : BaseActivity() {
    private lateinit var chat: TextView; private lateinit var status: TextView; private lateinit var listenBtn: Button
    private lateinit var scroll: ScrollView; private var rec: SpeechRecognizer? = null
    private val ui = Handler(Looper.getMainLooper())
    private val brainCb: (Brain.St) -> Unit = { s -> runOnUiThread { if (::status.isInitialized) status.text = when (s) { Brain.St.LISTENING -> "● Listening"; Brain.St.THINKING -> "◌ Thinking"; Brain.St.SPEAKING -> "◉ Speaking"; else -> "○ Ready" } } }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (!Store.bool(this, "onboarded")) { splash() } else dashboard()
    }
    private fun splash() {
        val f = FrameLayout(this).apply { setBackgroundColor(Ui.BG) }
        f.addView(LogoView(this), FrameLayout.LayoutParams(Ui.dp(this, 140), Ui.dp(this, 140), Gravity.CENTER)); setContentView(f)
        ui.postDelayed({ onboarding() }, 1400)
    }
    private fun onboarding() {
        val root = Ui.screen(this, "Welcome · خوش آمدید")
        root.addView(Ui.text(this, "I'm J.A.R.V.I.S — your personal assistant. I can listen (even while you use other apps, with a visible notification), open apps and games, analyze photos, search the web, manage your day, and help keep you safe.\n\nمن جارویس هستم؛ دستیار شخصی شما. همه چیز با اجازه و تأیید شما انجام می‌شود.", 15))
        val name = Ui.edit(this, "Your name / نام شما"); val ai = Ui.edit(this, "Assistant name / نام دستیار", "JARVIS")
        root.addView(name); root.addView(ai)
        root.addView(Ui.button(this, "Start · شروع") {
            Store.setStr(this, "user_name", name.text.toString().trim()); Store.setStr(this, "ai_name", ai.text.toString().trim().ifEmpty { "JARVIS" }); Store.setBool(this, "onboarded", true)
            requestAll(); dashboard()
        })
    }
    private fun requestAll() {
        val l = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        val need = l.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }; if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }
    private fun dashboard() {
        val root = Ui.screen(this, "")
        (root.getChildAt(0) as TextView).visibility = android.view.View.GONE
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(LogoView(this), LinearLayout.LayoutParams(Ui.dp(this, 52), Ui.dp(this, 52)))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(Ui.dp(this@MainActivity, 12), 0, 0, 0) }
        col.addView(Ui.text(this, Store.str(this, "ai_name", "JARVIS").uppercase().let { if (it == "JARVIS") "J.A.R.V.I.S" else it }, 22, Ui.accent(this), true))
        status = Ui.text(this, "○ Ready", 13, Ui.CYAN); col.addView(status); head.addView(col); root.addView(head)
        root.addView(HoloView(this), LinearLayout.LayoutParams(-1, Ui.dp(this, 70)))
        // info cards (personalizable in Settings)
        val row = LinearLayout(this); val fa = Lang.fa(this)
        fun info(id: String, t: String, v: String): TextView? { if (!Store.bool(this, "card_$id", true)) return null
            val c = Ui.card(this); c.addView(Ui.text(this, t, 11, 0xFF8888AA.toInt())); val tv = Ui.text(this, v, 15, Ui.WHITE, true); c.addView(tv)
            row.addView(c, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(4, 4, 4, 4) }); return tv }
        val clock = info("clock", "TIME", ""); val weather = info("weather", "WEATHER", "…"); val batt = info("battery", "BATTERY", "")
        root.addView(row)
        val modeTv = Ui.text(this, "", 13, Ui.PURPLE); root.addView(modeTv)
        fun tickInfo() { clock?.text = java.text.SimpleDateFormat("HH:mm", java.util.Locale.US).format(java.util.Date()) + "\n" + Ui.dateLine(fa); batt?.text = "${Phone.level(this)}%"
            modeTv.text = "Mode: ${Modes.title(this, Modes.current(this), fa)}  ·  Voice service: ${if (ListenService.running) "ON" else "off"}"; listenBtn.text = if (ListenService.running) "⏹ Stop background listening" else "👂 Start background listening" }
        // mic + listen
        val mic = Ui.button(this, "🎙  Speak") { if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) requestAll() else { rec?.destroy(); rec = Voice.once(this, { submit(it) }) } }
        listenBtn = Ui.button(this, "") { toggleListen(false) }
        root.addView(mic); root.addView(listenBtn)
        root.addView(Ui.text(this, "Hands-free: tap “Start background listening” once (while this app is open), then leave the app and say “Hey Jarvis” — it answers “${Store.str(this, if (fa) "ack_fa" else "ack_en", if (fa) "بله قربان" else "Yes sir")}”.", 12, 0xFF8888AA.toInt()))
        // chat
        chat = Ui.text(this, "", 14); scroll = ScrollView(this).apply { addView(chat); background = android.graphics.drawable.GradientDrawable().apply { setColor(Ui.CARD); cornerRadius = 24f } }
        root.addView(scroll, LinearLayout.LayoutParams(-1, Ui.dp(this, 230)).apply { topMargin = Ui.dp(this@MainActivity, 8) })
        val input = Ui.edit(this, "Type to JARVIS… / بنویسید"); val send = Ui.button(this, "Send") { val t = input.text.toString(); input.setText(""); submit(t) }
        root.addView(input); root.addView(send)
        // quick panel
        val items = listOf(Triple("vision", "📷 Smart camera", VisionActivity::class.java), Triple("files", "📂 Files & docs", FilesActivity::class.java), Triple("media", "🎧 Recorder", MediaActivity::class.java),
            Triple("finance", "💳 Finance", FinanceActivity::class.java), Triple("safety", "🛡 Safety", SafetyActivity::class.java), Triple("modes", "🎛 Modes", ModesActivity::class.java))
        for (it in items) if (Store.moduleOn(this, it.first)) root.addView(Ui.button(this, it.second) { startActivity(Intent(this, it.third)) })
        val lists = listOf("✅ Tasks" to ("tasks" to "New task"), "🛒 Shopping" to ("shopping" to "Item"), "🎯 Goals" to ("goals" to "goal|percent"), "📝 Notes" to ("notes" to "Note"), "🔁 Habits" to ("habits" to "habit|streak|date"),
            "🧠 Memory" to ("memory" to "A fact about you"), "⚡ Commands" to ("cmds" to "phrase=>step 1;;step 2"), "⭐ Favorites" to ("favs" to "Movie / music / show"), "🎮 Favorite games" to ("games_fav" to "Game name"))
        for ((label, kh) in lists) if (Store.moduleOn(this, "tools")) root.addView(Ui.button(this, label) { startActivity(Intent(this, ListActivity::class.java).putExtra("key", kh.first).putExtra("title", label).putExtra("hint", kh.second)) })
        root.addView(Ui.button(this, "⚙ Settings") { startActivity(Intent(this, SettingsActivity::class.java)) })
        if (!Store.bool(this, "first_hint")) { Store.setBool(this, "first_hint", true); chat.text = "Hi ${Store.str(this, "user_name")}! Add your Gemini key in Settings, then tap Speak or type.\nSay: “Hey Jarvis, open camera”, “what is 12*7”, “remember that I like tea”." }
        AutoSync.schedule(this); Modes.tick(this)
        tickInfo(); weather?.let { w -> Weather.fetch(this) { s -> runOnUiThread { w.text = s } } }
        ui.post(object : Runnable { override fun run() { tickInfo(); ui.postDelayed(this, 30_000) } })
        refreshChat(); Brain.listeners.add(brainCb)
        if (intent.getBooleanExtra("auto", false)) toggleListen(true)
    }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); setIntent(i); if (i.getBooleanExtra("auto", false) && ::listenBtn.isInitialized) toggleListen(true) }
    override fun onResume() { super.onResume(); if (::chat.isInitialized) { refreshChat(); Modes.tick(this) } }
    private fun refreshChat() { val t = Store.transcript(this); if (t.isNotEmpty()) chat.text = t; scroll.post { scroll.fullScroll(android.view.View.FOCUS_DOWN) } }
    private fun submit(text: String) {
        if (text.isBlank()) return; chat.append("\n\n▸ $text\n…"); scroll.post { scroll.fullScroll(android.view.View.FOCUS_DOWN) }
        Thread { val r = Brain.process(this, text); runOnUiThread { refreshChat(); Speaker.speak(this, r) } }.start()
    }
    private fun toggleListen(forceOn: Boolean) {
        if (ListenService.running && !forceOn) { ListenService.stop(this); ui.postDelayed({ listenBtn.text = "👂 Start background listening" }, 400); return }
        if (ListenService.running) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestAll(); return }
        val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName) && !Store.bool(this, "bat_asked")) { Store.setBool(this, "bat_asked", true)
            android.app.AlertDialog.Builder(this).setTitle("Keep JARVIS alive").setMessage("To hear you while other apps are open or the screen is off, allow JARVIS to ignore battery optimization.")
                .setPositiveButton("Allow") { _, _ -> try { startActivity(Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, android.net.Uri.parse("package:$packageName"))) } catch (e: Exception) { startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } }.setNegativeButton("Later", null).show() }
        ListenService.start(this); ui.postDelayed({ listenBtn.text = "⏹ Stop background listening" }, 500)
    }
    override fun onDestroy() { Brain.listeners.remove(brainCb); rec?.destroy(); ui.removeCallbacksAndMessages(null); super.onDestroy() }
}
