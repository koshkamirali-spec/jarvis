import Foundation
import UIKit
import AVFoundation
import CoreLocation
import MediaPlayer
import UserNotifications
import SwiftUI

/// Navigation requests coming from voice commands.
final class Nav: ObservableObject {
    static let shared = Nav()
    @Published var tab = 0; @Published var fake = false; @Published var sos = false
    func go(_ t: Int) { DispatchQueue.main.async { self.tab = t } }
}

final class LocationService: NSObject, CLLocationManagerDelegate, ObservableObject {
    static let shared = LocationService(); private let m = CLLocationManager(); @Published var last: CLLocation?
    override init() { super.init(); m.delegate = self; m.desiredAccuracy = kCLLocationAccuracyHundredMeters }
    func request() { m.requestWhenInUseAuthorization(); m.requestLocation() }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations l: [CLLocation]) { last = l.last }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) { Store.logError("location", error) }
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) { m.requestLocation() }
    var link: String { last.map { "https://maps.apple.com/?ll=\($0.coordinate.latitude),\($0.coordinate.longitude)" } ?? "" }
}

enum Weather {
    static func fetch() async -> String {
        guard let l = LocationService.shared.last, let u = URL(string: "https://api.open-meteo.com/v1/forecast?latitude=\(l.coordinate.latitude)&longitude=\(l.coordinate.longitude)&current=temperature_2m,weather_code") else { return "📍 enable location" }
        guard let (d, _) = try? await URLSession.shared.data(from: u), let j = try? JSONSerialization.jsonObject(with: d) as? [String: Any], let c = j["current"] as? [String: Any], let t = c["temperature_2m"] as? Double, let code = c["weather_code"] as? Int else { return "☁ offline" }
        let icon = code == 0 ? "☀️" : code < 4 ? "⛅" : code < 50 ? "🌫" : code < 70 ? "🌧" : code < 80 ? "❄️" : code < 90 ? "🌦" : "⛈"; return "\(icon) \(Int(t))°C" }
}

/// Generated siren (works without audio files); loops until stopped.
final class Siren {
    static let shared = Siren(); private var p: AVAudioPlayer?
    var on: Bool { p?.isPlaying ?? false }
    func start() {
        let rate = 22050, secs = 2; var pcm = [Int16](); for i in 0..<(rate * secs) { let t = Double(i) / Double(rate); let f = 700 + 500 * sin(2 * .pi * 0.5 * t); pcm.append(Int16(sin(2 * .pi * f * t) * 30000)) }
        var h = Data("RIFF".utf8); func u32(_ v: Int) -> Data { withUnsafeBytes(of: UInt32(v).littleEndian) { Data($0) } }; func u16(_ v: Int) -> Data { withUnsafeBytes(of: UInt16(v).littleEndian) { Data($0) } }
        h += u32(36 + pcm.count * 2) + Data("WAVEfmt ".utf8) + u32(16) + u16(1) + u16(1) + u32(rate) + u32(rate * 2) + u16(2) + u16(16) + Data("data".utf8) + u32(pcm.count * 2)
        let data = h + pcm.withUnsafeBytes { Data($0) }
        try? AVAudioSession.sharedInstance().setCategory(.playback); try? AVAudioSession.sharedInstance().setActive(true)
        p = try? AVAudioPlayer(data: data); p?.numberOfLoops = -1; p?.volume = 1; p?.play() }
    func stop() { p?.stop(); p = nil }
}

enum Torch { static func set(_ on: Bool) -> Bool { guard let d = AVCaptureDevice.default(for: .video), d.hasTorch else { return false }; do { try d.lockForConfiguration(); d.torchMode = on ? .on : .off; d.unlockForConfiguration(); return true } catch { return false } } }

/// Audio recorder (explicit start/stop, visible UI). WAV so Gemini can transcribe it.
final class Recorder: NSObject, ObservableObject {
    @Published var recording = false; private var r: AVAudioRecorder?
    static var dir: URL { let u = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("recordings"); try? FileManager.default.createDirectory(at: u, withIntermediateDirectories: true); return u }
    func toggle() {
        if recording { r?.stop(); recording = false; return }
        AVAudioSession.sharedInstance().requestRecordPermission { ok in DispatchQueue.main.async { guard ok else { return }
            try? AVAudioSession.sharedInstance().setCategory(.playAndRecord, mode: .default); try? AVAudioSession.sharedInstance().setActive(true)
            let f = Self.dir.appendingPathComponent("rec_\(Int(Date().timeIntervalSince1970)).wav")
            self.r = try? AVAudioRecorder(url: f, settings: [AVFormatIDKey: kAudioFormatLinearPCM, AVSampleRateKey: 16000, AVNumberOfChannelsKey: 1, AVLinearPCMBitDepthKey: 16])
            self.recording = self.r?.record() ?? false } } }
}

enum Notify {
    static func schedule(_ seconds: Double, _ body: String, repeats: Bool = false, id: String = UUID().uuidString) {
        let c = UNMutableNotificationContent(); c.title = "JARVIS"; c.body = body; c.sound = .default
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { _, _ in
            UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: id, content: c, trigger: UNTimeIntervalNotificationTrigger(timeInterval: repeats ? max(60, seconds) : max(1, seconds), repeats: repeats))) } }
    static func cancel(_ id: String) { UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [id]) }
}
