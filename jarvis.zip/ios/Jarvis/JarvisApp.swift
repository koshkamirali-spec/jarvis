import SwiftUI
@main struct JarvisApp: App {
    @StateObject var voice = VoiceEngine(); @StateObject var nav = Nav.shared
    var body: some Scene { WindowGroup { RootView().environmentObject(voice).environmentObject(nav).onOpenURL { if $0.host == "listen" { voice.start() } } } }
}
