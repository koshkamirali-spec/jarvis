import Foundation
import UIKit
import MediaPlayer
import AVFoundation
import UserNotifications

/// Local commands (0 tokens). nil -> AI. iOS cannot: toggle Wi-Fi/Bluetooth, open other apps' internals, set system alarms, or read other apps' notifications.
enum Router {
    static func notify(_ seconds: Double, _ body: String) { Notify.schedule(seconds, body) }
    private static func open(_ s: String) { if let u = URL(string: s) { DispatchQueue.main.async { UIApplication.shared.open(u) } } }
    static func handle(_ raw: String) -> String? {
        let t = raw.lowercased().trimmingCharacters(in: .whitespaces); let fa = Logic.isPersian(raw)
        func has(_ k: String...) -> Bool { k.contains { t.contains($0) } }
        func r(_ en: String, _ f: String) -> String { fa ? f : en }
        // modes
        if has("mode", "حالت"), let m = Modes.all.first(where: { $0.id != "normal" && (t.contains($0.title.lowercased()) || t.contains($0.fa)) }) {
            if has("exit", "off", "خروج", "خاموش") { Store.set("mode", "normal"); Store.gameStart = 0; return r("Normal mode.", "حالت عادی.") }
            Store.set("mode", m.id); if m.id == "gaming" { Store.gameStart = Date().timeIntervalSince1970; Notify.schedule(45 * 60, "Time for a short break 🎮") }
            return r("\(m.title) mode on. (iOS lets me change behavior, but you control Focus/Do Not Disturb in Control Center.)", "حالت \(m.fa) فعال شد.") }
        if has("exit gaming", "normal mode", "حالت عادی") { Store.set("mode", "normal"); Store.gameStart = 0; return r("Normal mode.", "حالت عادی.") }
        if has("how long", "game time", "زمان بازی") { return Store.gameStart == 0 ? r("Gaming mode is off.", "حالت بازی خاموش است.") : r("You played \(Int((Date().timeIntervalSince1970 - Store.gameStart) / 60)) minutes.", "\(Int((Date().timeIntervalSince1970 - Store.gameStart) / 60)) دقیقه بازی کردید.") }
        // safety
        if has("danger 1", "danger 2", "sos", "help me", "خطر", "کمکم کن") { DispatchQueue.main.async { Nav.shared.tab = 3; Nav.shared.sos = true }; return r("Emergency screen opened. Nothing is sent until you confirm.", "صفحه اضطراری باز شد؛ بدون تأیید شما چیزی ارسال نمی‌شود.") }
        if has("fake call", "تماس ساختگی") { DispatchQueue.main.async { Nav.shared.fake = true }; return r("Ringing (simulated).", "تماس شبیه‌سازی شد.") }
        if has("siren", "آژیر") { if has("off", "stop", "خاموش") { Siren.shared.stop(); return r("Siren off.", "آژیر خاموش.") }; Siren.shared.start(); return r("Siren on.", "آژیر روشن شد.") }
        // screens
        if has("camera", "what is this", "identify", "scan", "دوربین", "این چیه") && !has("flash") { Nav.shared.go(1); return r("Opening smart camera.", "دوربین هوشمند باز شد.") }
        if has("finance", "chart", "نمودار") { Nav.shared.go(4); return r("Opening finance.", "مالی باز شد.") }
        // calc / time
        if let e = Logic.extractExpr(raw), has("calc", "what is", "what's", "حساب", "چند", "چقدر", "=") || raw.trimmingCharacters(in: .whitespaces) == e, let v = Logic.calc(e) { return "\(e) = \(Logic.fmt(v))" }
        if has("what time", "time is it", "ساعت چنده") { return Date().formatted(date: .omitted, time: .shortened) }
        if has("what date", "today's date", "تاریخ امروز") { return Date().formatted(date: .complete, time: .omitted) }
        if has("timer", "تایمر", "alarm", "آلارم", "remind me", "یادآوری", "یادم بنداز") { guard let ms = Logic.millis(t) else { return r("When? e.g. “remind me in 10 minutes”.", "چه زمانی؟ مثلاً «۱۰ دقیقه دیگه یادم بنداز»") }
            Notify.schedule(ms / 1000, "🔔 " + raw); return r("Reminder in \(Int(ms / 60000)) min (iOS apps cannot set system alarms; this is a notification).", "یادآوری \(Int(ms / 60000)) دقیقه دیگر.") }
        // lists
        if has("add task", "todo ", "کار جدید") { let x = raw.replacingOccurrences(of: "(?i)add task|todo|کار جدید|اضافه کن", with: "", options: .regularExpression).trimmingCharacters(in: .whitespaces); Store.push("tasks", x); return r("Task added.", "کار اضافه شد.") }
        if has("my tasks", "کارهای من") { let l = Store.list("tasks"); return l.isEmpty ? r("No tasks.", "کاری نیست.") : l.enumerated().map { "\($0 + 1). \($1)" }.joined(separator: "\n") }
        if has("shopping list", "لیست خرید") { if let m = raw.range(of: "(?i)add (.+?) to (my |the )?shopping", options: .regularExpression) { let x = raw[m].replacingOccurrences(of: "(?i)add | to (my |the )?shopping", with: "", options: .regularExpression); Store.push("shopping", x); return r("Added.", "اضافه شد.") }
            return Store.list("shopping").isEmpty ? r("Empty.", "خالی است.") : Store.list("shopping").joined(separator: "، ") }
        if has("read my notes", "my notes") { return Store.notes.suffix(3).joined(separator: ". ") }
        if has("note", "یادداشت") { Store.notes.append(raw.replacingOccurrences(of: "(?i)note|یادداشت", with: "", options: .regularExpression).trimmingCharacters(in: .whitespaces)); return r("Saved.", "ذخیره شد.") }
        if has("remember that", "یادت باشه", "به خاطر بسپار") { Store.push("memory", raw.replacingOccurrences(of: "(?i)remember that|یادت باشه|به خاطر بسپار", with: "", options: .regularExpression).trimmingCharacters(in: .whitespaces), max: 200); return r("I'll remember that.", "یادم می‌ماند.") }
        if has("what do you know about me", "چی درباره من میدونی") { return Store.list("memory").joined(separator: "؛ ") }
        // finance
        let num = Logic.digits(t).range(of: "\\d+(\\.\\d+)?", options: .regularExpression).flatMap { Double(Logic.digits(t)[$0]) }
        if has("monthly report", "گزارش هزینه") { return Fin.report() }
        if has("expense", "spent", "هزینه"), let n = num { Store.push("fin", "\(Date().timeIntervalSince1970)|exp|other|\(n)|"); return r("Logged expense \(Logic.fmt(n)).", "هزینه ثبت شد.") }
        if has("income", "salary", "درآمد", "حقوق"), let n = num { Store.push("fin", "\(Date().timeIntervalSince1970)|inc|income|\(n)|"); return r("Logged income.", "درآمد ثبت شد.") }
        // phone
        if has("battery", "باتری") { UIDevice.current.isBatteryMonitoringEnabled = true; return r("Battery \(Int(UIDevice.current.batteryLevel * 100))%.", "باتری \(Int(UIDevice.current.batteryLevel * 100))٪.") }
        if has("device info", "اطلاعات دستگاه") { return "\(UIDevice.current.model), iOS \(UIDevice.current.systemVersion)" }
        if has("storage", "فضای ذخیره") { if let a = try? FileManager.default.attributesOfFileSystem(forPath: NSHomeDirectory()), let f = a[.systemFreeSize] as? Double, let tt = a[.systemSize] as? Double { return String(format: "%.1f GB free of %.1f GB", f / 1e9, tt / 1e9) } }
        if has("flashlight", "torch", "چراغ قوه", "چراغ‌قوه") { return Torch.set(!has("off", "خاموش")) ? r("Done.", "انجام شد.") : r("Flashlight unavailable.", "چراغ‌قوه در دسترس نیست.") }
        if has("brightness", "روشنایی") { if let n = num { DispatchQueue.main.async { UIScreen.main.brightness = CGFloat(min(100, n) / 100) }; return r("Brightness \(Int(n))%.", "روشنایی تنظیم شد.") } }
        if has("settings", "wifi", "bluetooth", "تنظیمات", "وای فای", "بلوتوث") { open(UIApplication.openSettingsURLString); return r("Opened Settings. iOS does not let apps toggle Wi-Fi/Bluetooth.", "تنظیمات باز شد؛ iOS اجازه تغییر مستقیم نمی‌دهد.") }
        let p = MPMusicPlayerController.systemMusicPlayer
        if has("pause music", "مکث موسیقی") { p.pause(); return r("Paused.", "مکث شد.") }
        if has("play music", "پخش موسیقی") { p.play(); return r("Playing.", "پخش شد.") }
        if has("next song", "آهنگ بعدی") { p.skipToNextItem(); return r("Next.", "بعدی.") }
        if has("search for", "جستجو") { let q = t.components(separatedBy: "search for ").last ?? t; open("https://www.google.com/search?q=" + (q.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")); return r("Searching.", "در حال جستجو.") }
        if has("open ", "باز کن") {
            let schemes = ["instagram": "instagram://app", "اینستاگرام": "instagram://app", "telegram": "tg://", "تلگرام": "tg://", "whatsapp": "whatsapp://", "واتساپ": "whatsapp://", "maps": "maps://", "نقشه": "maps://", "youtube": "youtube://", "spotify": "spotify://", "browser": "https://www.google.com", "مرورگر": "https://www.google.com", "photos": "photos-redirect://", "گالری": "photos-redirect://", "calendar": "calshow://", "تقویم": "calshow://"]
            if let k = schemes.keys.first(where: { t.contains($0) }) { open(schemes[k]!); return r("Opening \(k).", "\(k) باز شد.") }
            return r("iOS only lets me open apps that I know: Instagram, Telegram, WhatsApp, Maps, YouTube, Spotify, Photos, Calendar, browser.", "فقط برنامه‌های شناخته‌شده قابل باز شدن هستند.") }
        return nil
    }
}

enum Fin {
    static func report() -> String {
        let start = Calendar.current.date(from: Calendar.current.dateComponents([.year, .month], from: Date()))!.timeIntervalSince1970
        let e = Store.list("fin").compactMap { s -> (Double, String, String, Double)? in let p = s.components(separatedBy: "|"); guard p.count >= 4, let t = Double(p[0]), let a = Double(p[3]) else { return nil }; return (t, p[1], p[2], a) }.filter { $0.0 >= start }
        let inc = e.filter { $0.1 == "inc" }.reduce(0) { $0 + $1.3 }; let exp = e.filter { $0.1 == "exp" }.reduce(0) { $0 + $1.3 }
        return "This month: income \(Logic.fmt(inc)), expenses \(Logic.fmt(exp)), balance \(Logic.fmt(inc - exp))." }
}
