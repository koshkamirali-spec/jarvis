import Foundation
import Contacts
import UIKit

/// iOS brain pipeline: confirmation -> interpreter -> AI planner -> local router -> contacts / home / report -> Gemini.
enum Brain {
    static var pending: (() async -> String)?
    static func process(_ text: String) async -> String {
        let t = text.lowercased().trimmingCharacters(in: .whitespaces)
        if let p = pending {
            if ["yes", "yeah", "ok", "confirm", "بله", "آره", "تایید"].contains(t) { pending = nil; return await p() }
            if ["no", "cancel", "نه", "لغو"].contains(t) { pending = nil; return "Cancelled." } }
        if t.contains("interpreter mode off") || t.contains("مترجم زنده خاموش") { Store.set("interp", false); return "Interpreter off." }
        if t.contains("interpreter mode on") || t.contains("مترجم زنده روشن") { Store.set("interp", true); return "Interpreter on: I translate everything you say (Persian ⇄ English). Say “interpreter mode off” to stop." }
        if Store.bool("interp") { return await LLM.ask("Translate between Persian and English (Persian to English, English to Persian). Output only the translation:\n\(text)", history: false, maxTokens: 220) }
        if Logic.wantsPlan(t) { return await plan(text) }
        if let r = Router.handle(text) { return r }
        if let r = await Extras.handle(text) { return r }
        let s = Logic.needsSearch(text); return await LLM.ask(text, search: s, maxTokens: s ? 420 : 260)
    }
    /// The model proposes up to 5 commands; you confirm; each runs through the same router.
    static func plan(_ text: String) async -> String {
        let raw = await LLM.ask("Convert this request into at most 5 short voice commands a phone assistant understands (examples: open camera; remind me in 30 minutes to call mom; add task buy milk; search for pizza). Output ONLY a JSON array of strings.\nRequest: \(text)", history: false, maxTokens: 200)
        guard let a = raw.firstIndex(of: "["), let b = raw.lastIndex(of: "]"), a < b, let d = String(raw[a...b]).data(using: .utf8),
              let steps = (try? JSONSerialization.jsonObject(with: d)) as? [String], !steps.isEmpty else { return "I couldn't build a plan." }
        let s = Array(steps.prefix(5))
        pending = { var out = ""; for (i, x) in s.enumerated() { let r = Router.handle(x) ?? (await Extras.handle(x)) ?? (await LLM.ask(x)); out += "\(i + 1). \(x) → \(r)\n"; try? await Task.sleep(nanoseconds: 600_000_000) }; return out }
        return "Plan: " + s.joined(separator: " → ") + " — say yes or no."
    }
}

enum Extras {
    static func open(_ s: String) async { if let u = URL(string: s) { await MainActor.run { UIApplication.shared.open(u) } } }
    static func find(_ name: String) async -> (String, String)? {
        let store = CNContactStore(); guard (try? await store.requestAccess(for: .contacts)) == true else { return nil }
        let keys = [CNContactGivenNameKey, CNContactFamilyNameKey, CNContactPhoneNumbersKey] as [CNKeyDescriptor]
        guard let cs = try? store.unifiedContacts(matching: CNContact.predicateForContacts(matchingName: name), keysToFetch: keys), let c = cs.first, let n = c.phoneNumbers.first?.value.stringValue else { return nil }
        return ("\(c.givenName) \(c.familyName)", n)
    }
    static func handle(_ raw: String) async -> String? {
        let t = raw.lowercased(); let fa = Logic.isPersian(raw)
        func has(_ k: String...) -> Bool { k.contains { t.contains($0) } }
        func r(_ en: String, _ f: String) -> String { fa ? f : en }
        if has("daily report", "weekly report", "گزارش روزانه", "گزارش هفتگی") {
            return r("Report: \(Store.list("done").count) tasks done, \(Store.list("tasks").count) pending. \(Fin.report())", "گزارش: \(Store.list("done").count) کار انجام‌شده، \(Store.list("tasks").count) کار باقی‌مانده. \(Fin.report())") }
        if let re = try? NSRegularExpression(pattern: "(?:message|text|sms)\\s+(.+?)\\s+(?:saying|that|:)\\s+(.+)", options: .caseInsensitive), let m = re.firstMatch(in: raw, range: NSRange(raw.startIndex..., in: raw)), let w = Range(m.range(at: 1), in: raw), let b = Range(m.range(at: 2), in: raw) {
            guard let c = await find(String(raw[w])) else { return r("Contact not found (allow Contacts in iOS Settings).", "مخاطب پیدا نشد.") }
            await open("sms:\(c.1.filter { $0.isNumber || $0 == "+" })&body=\(String(raw[b]).addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")")
            return r("Message to \(c.0) is ready in Messages; press send to confirm.", "پیام برای \(c.0) آماده است؛ ارسال را بزنید.") }
        if has("call ", "تماس با") { let n = t.replacingOccurrences(of: "call ", with: "").replacingOccurrences(of: "تماس با", with: "").trimmingCharacters(in: .whitespaces)
            guard let c = await find(n) else { return r("Contact not found (allow Contacts in iOS Settings).", "مخاطب پیدا نشد.") }
            await open("tel:\(c.1.filter { $0.isNumber || $0 == "+" })"); return r("Calling \(c.0): iOS asks you to confirm.", "تماس با \(c.0): iOS تأیید می‌خواهد.") }
        return await Home.handle(t, fa)
    }
}

/// Smart home through your Home Assistant server. Every action asks for confirmation.
enum Home {
    static func call(_ path: String, body: Data? = nil) async throws -> Data {
        guard let u = URL(string: Store.str("ha_url").trimmingCharacters(in: CharacterSet(charactersIn: "/ ")) + path) else { throw URLError(.badURL) }
        var req = URLRequest(url: u); req.setValue("Bearer " + Keychain.get("ha_token"), forHTTPHeaderField: "Authorization"); req.setValue("application/json", forHTTPHeaderField: "content-type"); req.timeoutInterval = 8
        if let b = body { req.httpMethod = "POST"; req.httpBody = b }
        return try await URLSession.shared.data(for: req).0
    }
    static func handle(_ t: String, _ fa: Bool) async -> String? {
        let scene = t.contains("scene ") || t.contains("سناریو")
        let dev = ["light", "lamp", "plug", "fan", "heater", "چراغ", "پریز", "پنکه", "بخاری", "لامپ"].contains { t.contains($0) }
        let sw = (t.contains("turn on") || t.contains("turn off") || t.contains("روشن کن") || t.contains("خاموش کن")) && dev
        guard scene || sw else { return nil }
        guard !Store.str("ha_url").isEmpty, !Keychain.get("ha_token").isEmpty else { return fa ? "آدرس و توکن Home Assistant را در تنظیمات وارد کنید." : "Add your Home Assistant URL and token in Settings." }
        let on = !(t.contains("turn off") || t.contains("خاموش کن"))
        var name = t; for w in ["turn on", "turn off", "scene", "the", "روشن کن", "خاموش کن", "سناریوی", "سناریو"] { name = name.replacingOccurrences(of: w, with: "") }; name = name.trimmingCharacters(in: .whitespaces)
        guard let d = try? await call("/api/states"), let arr = try? JSONSerialization.jsonObject(with: d) as? [[String: Any]] else { return fa ? "اتصال به Home Assistant ممکن نشد." : "Could not reach Home Assistant." }
        let hit = arr.first { e in let id = e["entity_id"] as? String ?? ""; let fn = ((e["attributes"] as? [String: Any])?["friendly_name"] as? String ?? "").lowercased()
            return !fn.isEmpty && (fn.contains(name) || name.contains(fn)) && (scene ? id.hasPrefix("scene.") : ["light", "switch", "fan", "climate", "input_boolean"].contains(String(id.split(separator: ".").first ?? ""))) }
        guard let h = hit, let id = h["entity_id"] as? String else { return fa ? "دستگاهی به نام «\(name)» پیدا نشد." : "No matching device “\(name)”." }
        Brain.pending = { do { _ = try await call("/api/services/\(id.split(separator: ".")[0])/\(scene || on ? "turn_on" : "turn_off")", body: try JSONSerialization.data(withJSONObject: ["entity_id": id])); return fa ? "انجام شد." : "Done." } catch { Store.logError("home", error); return fa ? "اجرا نشد." : "The command failed." } }
        return (fa ? "اجرا شود؟ " : "Run: ") + id + (fa ? " — بگو «بله» یا «نه»." : " — say yes or no.")
    }
}

/// Manual encrypted sync with your own backend (same endpoint as Android).
enum Sync {
    private static func req(_ method: String) -> URLRequest? {
        let b = Store.str("backend").trimmingCharacters(in: .whitespaces).trimmingCharacters(in: CharacterSet(charactersIn: "/")); guard !b.isEmpty, let u = URL(string: b + "/sync") else { return nil }
        var r = URLRequest(url: u); r.httpMethod = method; r.timeoutInterval = 20; r.setValue(Store.backendToken, forHTTPHeaderField: "x-app-token"); return r
    }
    static func put(_ d: Data) async -> Bool { guard var r = req("PUT") else { return false }; r.httpBody = d; guard let (_, resp) = try? await URLSession.shared.data(for: r) else { return false }; return (resp as? HTTPURLResponse)?.statusCode == 200 }
    static func get() async -> Data? { guard let r = req("GET"), let (d, resp) = try? await URLSession.shared.data(for: r), (resp as? HTTPURLResponse)?.statusCode == 200 else { return nil }; return d }
}
