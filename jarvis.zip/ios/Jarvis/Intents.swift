import AppIntents
/// Siri / Shortcuts / Action Button / Lock Screen controls. "Hey Siri, Ask Jarvis".
struct AskJarvisIntent: AppIntent {
    static var title: LocalizedStringResource = "Ask Jarvis"
    @Parameter(title: "Question") var question: String
    func perform() async throws -> some IntentResult & ProvidesDialog {
        let r = await Brain.process(question)
        Store.add("user", question); Store.add("assistant", r)
        return .result(dialog: IntentDialog(stringLiteral: r))
    }
}
struct AddNoteIntent: AppIntent {
    static var title: LocalizedStringResource = "Jarvis Note"
    @Parameter(title: "Note") var note: String
    func perform() async throws -> some IntentResult & ProvidesDialog { Store.notes.append(note); return .result(dialog: "Saved.") }
}
struct RemindIntent: AppIntent {
    static var title: LocalizedStringResource = "Jarvis Reminder"
    @Parameter(title: "Minutes") var minutes: Int
    @Parameter(title: "Text") var text: String
    func perform() async throws -> some IntentResult & ProvidesDialog { Router.notify(Double(minutes) * 60, text); return .result(dialog: "Reminder set.") }
}
struct GamingModeIntent: AppIntent {
    static var title: LocalizedStringResource = "Jarvis Gaming Mode"
    func perform() async throws -> some IntentResult & ProvidesDialog { _ = Router.handle("gaming mode"); return .result(dialog: "Gaming mode on. Break reminder in 45 minutes.") }
}
struct StartListeningIntent: AppIntent {
    static var title: LocalizedStringResource = "Start Jarvis Listening"
    static var openAppWhenRun = true   // opens the app so the audio session can legally start
    func perform() async throws -> some IntentResult { .result() }
}
struct JarvisShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(intent: AskJarvisIntent(), phrases: ["Ask \(.applicationName)", "Hey \(.applicationName)"], shortTitle: "Ask", systemImageName: "mic")
        AppShortcut(intent: GamingModeIntent(), phrases: ["\(.applicationName) gaming mode"], shortTitle: "Gaming", systemImageName: "gamecontroller")
        AppShortcut(intent: AddNoteIntent(), phrases: ["\(.applicationName) note"], shortTitle: "Note", systemImageName: "note.text")
        AppShortcut(intent: StartListeningIntent(), phrases: ["Start \(.applicationName) listening"], shortTitle: "Listen", systemImageName: "waveform")
    }
}
