import SwiftUI
import PhotosUI
import Charts
import LocalAuthentication
import UniformTypeIdentifiers
import MessageUI
import CommonCrypto
import CryptoKit

let gold = Color(red: 1, green: 0.78, blue: 0.34), purple = Color(red: 0.48, green: 0.18, blue: 0.97), neon = Color(red: 0, green: 0.9, blue: 1)

struct RootView: View {
    @EnvironmentObject var nav: Nav; @State var splash = true
    var body: some View {
        ZStack {
            if !Store.bool("onboarded") { Onboarding() }
            else { TabView(selection: $nav.tab) {
                HomeView().tabItem { Label("Home", systemImage: "waveform") }.tag(0)
                VisionView().tabItem { Label("Camera", systemImage: "camera.viewfinder") }.tag(1)
                ToolsView().tabItem { Label("Tools", systemImage: "checklist") }.tag(2)
                Guarded { SafetyView() }.tabItem { Label("Safety", systemImage: "shield.lefthalf.filled") }.tag(3)
                MoreView().tabItem { Label("More", systemImage: "ellipsis.circle") }.tag(4) }
                .tint(gold).fullScreenCover(isPresented: $nav.fake) { FakeCallView() } }
            if splash { Color.black.ignoresSafeArea().overlay(Text("J").font(.system(size: 90, weight: .bold)).foregroundColor(.white).padding(40).background(Circle().fill(purple)).overlay(Circle().stroke(gold, lineWidth: 6))).transition(.opacity) }
        }.preferredColorScheme(.dark).onAppear { LocationService.shared.request(); DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) { withAnimation { splash = false } } }
    }
}
struct Onboarding: View {
    @State var name = ""; @State var ai = "JARVIS"
    var body: some View { VStack(spacing: 14) { Text("J.A.R.V.I.S").font(.largeTitle.bold()).foregroundColor(gold)
        Text("Your personal assistant. Everything happens with your permission.\nدستیار شخصی شما؛ همه‌چیز با اجازه و تأیید شما.").multilineTextAlignment(.center)
        TextField("Your name / نام شما", text: $name).textFieldStyle(.roundedBorder); TextField("Assistant name / نام دستیار", text: $ai).textFieldStyle(.roundedBorder)
        Button("Start · شروع") { Store.set("user_name", name); Store.set("ai_name", ai.isEmpty ? "JARVIS" : ai); Store.set("onboarded", true); UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { _, _ in } }.buttonStyle(.borderedProminent).tint(purple) }.padding() }
}
/// Privacy Lock: Face ID / passcode when enabled.
struct Guarded<C: View>: View {
    @ViewBuilder var content: () -> C; @State var ok = !Store.bool("privacy_lock")
    var body: some View { Group { if ok { content() } else { Button("🔒 Unlock") { auth() }.buttonStyle(.borderedProminent) } }.onAppear { if !ok { auth() } } }
    func auth() { LAContext().evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "Unlock JARVIS") { s, _ in DispatchQueue.main.async { ok = s } } }
}
struct Wave: View {
    @EnvironmentObject var v: VoiceEngine
    var body: some View { TimelineView(.animation) { tl in let t = tl.date.timeIntervalSinceReferenceDate
        HStack(spacing: 3) { ForEach(0..<28, id: \.self) { i in let a = v.state == .awake ? 0.3 + 0.6 * abs(sin(t * 4 + Double(i) * 0.45)) : v.state == .wake ? 0.1 + 0.1 * abs(sin(t * 1.5 + Double(i) * 0.3)) : 0.05
            Capsule().fill(i % 2 == 0 ? gold : neon).frame(width: 5, height: 60 * a * (0.4 + 0.6 * sin(Double(i) / 28 * .pi))) } }.frame(height: 64) } }
}
struct HomeView: View {
    @EnvironmentObject var v: VoiceEngine; @State var text = ""; @State var weather = "…"; @State var busy = false; @State var chat = Store.transcript
    var body: some View { ScrollView { VStack(alignment: .leading, spacing: 10) {
        HStack { Text("J.A.R.V.I.S").font(.title.bold()).foregroundColor(gold); Spacer(); Text(busy ? "◌ Thinking" : v.state == .off ? "○ Ready" : v.state == .awake ? "● Listening" : "◉ Waiting for wake word").font(.caption).foregroundColor(neon) }
        Wave()
        HStack { card("TIME", Date().formatted(date: .abbreviated, time: .shortened)); card("WEATHER", weather); card("BATTERY", battery()) }
        Text("Mode: \(Modes.current)").font(.caption).foregroundColor(purple)
        Button(v.state == .off ? "👂 Start voice conversation" : "⏹ Stop voice") { v.state == .off ? v.start() : v.stop() }.buttonStyle(.borderedProminent).tint(purple)
        Text("iOS keeps listening only while this session is active (Background Audio). For hands-free use when closed: “Hey Siri, Ask Jarvis”.").font(.caption2).foregroundColor(.gray)
        Text(chat.isEmpty ? "Add your Gemini key in More ▸ Settings, then type or speak." : chat).font(.callout).padding().frame(maxWidth: .infinity, alignment: .leading).background(Color(white: 0.1)).cornerRadius(12)
        HStack { TextField("Type to JARVIS… / بنویسید", text: $text).textFieldStyle(.roundedBorder).onSubmit(send); Button("Send", action: send).disabled(busy) }
    }.padding() }.task { weather = await Weather.fetch() } }
    func card(_ t: String, _ x: String) -> some View { VStack(alignment: .leading) { Text(t).font(.caption2).foregroundColor(.gray); Text(x).font(.footnote.bold()) }.padding(8).frame(maxWidth: .infinity, alignment: .leading).background(Color(white: 0.1)).cornerRadius(10) }
    func battery() -> String { UIDevice.current.isBatteryMonitoringEnabled = true; return "\(Int(UIDevice.current.batteryLevel * 100))%" }
    func send() { let t = text.trimmingCharacters(in: .whitespaces); guard !t.isEmpty else { return }; text = ""; busy = true; Store.add("user", t)
        Task { let r = await Brain.process(t); Store.add("assistant", r); await MainActor.run { chat = Store.transcript; busy = false } } }
}

struct ListScreen: View {
    let key: String, title: String; @State var items: [String] = []; @State var new = ""; @State var editing: Int?; @State var edit = ""
    var body: some View { List { Section { HStack { TextField("Add…", text: $new); Button("Add") { guard !new.isEmpty else { return }; Store.push(key, new); new = ""; items = Store.list(key) } } }
        ForEach(Array(items.enumerated()), id: \.offset) { i, s in Text(s).onTapGesture { editing = i; edit = s } }.onDelete { o in var l = Store.list(key); l.remove(atOffsets: o); Store.setList(key, l); items = l } }
        .navigationTitle(title).onAppear { items = Store.list(key) }
        .sheet(isPresented: Binding(get: { editing != nil }, set: { if !$0 { editing = nil } })) { VStack { TextField("Edit", text: $edit).textFieldStyle(.roundedBorder); Button("Save") { if let i = editing { var l = Store.list(key); if i < l.count { l[i] = edit; Store.setList(key, l) }; items = l }; editing = nil }.buttonStyle(.borderedProminent) }.padding().presentationDetents([.height(160)]) } }
}
struct ToolsView: View {
    var body: some View { NavigationStack { List {
        ForEach([("✅ Tasks", "tasks"), ("🛒 Shopping", "shopping"), ("🎯 Goals", "goals"), ("📝 Notes", "notes"), ("🔁 Habits", "habits"), ("⚡ Custom commands (phrase=>step;;step)", "cmds"), ("⭐ Favorites", "favs"), ("🎮 Favorite games", "games_fav"), ("📄 Saved pages", "pages"), ("📍 Places", "places")], id: \.1) { l in NavigationLink(l.0) { ListScreen(key: l.1, title: l.0) } }
        NavigationLink("🧠 Memory") { Guarded { ListScreen(key: "memory", title: "Memory") } }
        NavigationLink("🎛 Modes") { ModesView() } }.navigationTitle("Tools") } }
}
struct ModesView: View {
    @State var cur = Modes.current
    var body: some View { List(Modes.all, id: \.id) { m in Button { Store.set("mode", m.id); cur = m.id; if m.id == "gaming" { Store.gameStart = Date().timeIntervalSince1970 } } label: { HStack { Text("\(m.title) · \(m.fa)"); Spacer(); if cur == m.id { Image(systemName: "checkmark").foregroundColor(gold) } } } }.navigationTitle("Modes") }
}

struct CameraPicker: UIViewControllerRepresentable {
    var onImage: (UIImage) -> Void
    func makeUIViewController(context: Context) -> UIImagePickerController { let p = UIImagePickerController(); p.sourceType = UIImagePickerController.isSourceTypeAvailable(.camera) ? .camera : .photoLibrary; p.delegate = context.coordinator; return p }
    func updateUIViewController(_ u: UIImagePickerController, context: Context) {}
    func makeCoordinator() -> Co { Co(onImage) }
    final class Co: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate { let f: (UIImage) -> Void; init(_ f: @escaping (UIImage) -> Void) { self.f = f }
        func imagePickerController(_ p: UIImagePickerController, didFinishPickingMediaWithInfo i: [UIImagePickerController.InfoKey: Any]) { if let im = i[.originalImage] as? UIImage { f(im) }; p.dismiss(animated: true) } }
}
struct VisionView: View {
    static let prompts: [(String, String)] = [("identify", "Identify the main objects and explain briefly what each is used for."), ("ocr", "Extract ALL text exactly (OCR)."), ("translate", "Extract the text and translate it between Persian and English."),
        ("plant", "Identify the plant and give short care tips."), ("animal", "Identify the animal or breed, 2 facts."), ("product", "Identify the product: type, probable brand/model, use."), ("food", "Identify food/ingredients; mention common allergens."),
        ("document", "Analyze this document: type, key info, dates, numbers."), ("invoice", "Extract invoice data: vendor, date, items, totals."), ("signs", "Read and explain any sign or symbol."), ("surroundings", "Describe the surroundings, text and possible hazards."),
        ("book", "Transcribe the page then summarize in 2 sentences."), ("compare", "Compare the images: similarities and differences."), ("gallery", "Briefly describe and tag each image.")]
    @State var mode = "identify"; @State var imgs: [UIImage] = []; @State var picks: [PhotosPickerItem] = []; @State var out = ""; @State var cam = false; @State var busy = false
    var body: some View { ScrollView { VStack(alignment: .leading, spacing: 10) {
        Picker("Mode", selection: $mode) { ForEach(Self.prompts, id: \.0) { Text($0.0).tag($0.0) } }.pickerStyle(.menu)
        HStack { Button("📸 Take photo") { cam = true }.buttonStyle(.borderedProminent).tint(purple); PhotosPicker(selection: $picks, maxSelectionCount: 4, matching: .images) { Text("🖼 Gallery") } }
        ScrollView(.horizontal) { HStack { ForEach(Array(imgs.enumerated()), id: \.offset) { Image(uiImage: $1).resizable().scaledToFit().frame(height: 140) } } }
        Button(busy ? "Analyzing…" : "Analyze") { run(Self.prompts.first { $0.0 == mode }!.1, false) }.disabled(imgs.isEmpty || busy)
        Button("🔎 Search the web about this") { run("Find reliable info (and typical prices if a product) about: \(out.prefix(300))", true) }.disabled(out.isEmpty)
        Button("Clear") { imgs = []; out = "" }
        Text(out) }.padding() }
        .sheet(isPresented: $cam) { CameraPicker { imgs.append($0); if mode != "compare" || imgs.count >= 2 { run(Self.prompts.first { $0.0 == mode }!.1, false) } } }
        .onChange(of: picks) { _, new in Task { var l: [UIImage] = []; for p in new { if let d = try? await p.loadTransferable(type: Data.self), let i = UIImage(data: d) { l.append(i) } }; imgs = l; if !l.isEmpty { run(Self.prompts.first { $0.0 == mode }!.1, false) } } }
    }
    func run(_ task: String, _ search: Bool) { busy = true; out = "…"; let i = imgs; let fa = Locale.current.identifier.hasPrefix("fa")
        Task { let r = await LLM.ask("\(task) Reply in \(fa ? "Persian" : "English"), concise.", images: search ? [] : i, history: false, search: search, maxTokens: 600); Store.add("user", "[camera:\(mode)]"); Store.add("assistant", r); await MainActor.run { out = r; busy = false } } }
}

struct FinanceView: View {
    @State var amt = ""; @State var cat = ""; @State var entries: [String] = []
    var cats: [(String, Double)] { let start = Calendar.current.date(from: Calendar.current.dateComponents([.year, .month], from: Date()))!.timeIntervalSince1970; var d: [String: Double] = [:]
        for s in entries { let p = s.components(separatedBy: "|"); if p.count >= 4, p[1] == "exp", let t = Double(p[0]), t >= start, let a = Double(p[3]) { d[p[2], default: 0] += a } }; return d.sorted { $0.value > $1.value } }
    var body: some View { List { Section { Text(Fin.report()); if !cats.isEmpty { Chart(cats, id: \.0) { BarMark(x: .value("Amount", $0.1), y: .value("Category", $0.0)).foregroundStyle(purple) }.frame(height: 40 * CGFloat(cats.count)) } }
        Section("Add (manual only – the app never moves money)") { TextField("Amount", text: $amt).keyboardType(.decimalPad); TextField("Category", text: $cat)
            Button("Add expense") { add("exp") }; Button("Add income") { add("inc") } }
        Section("Recent (swipe to delete)") { ForEach(Array(entries.enumerated().reversed().prefix(15)), id: \.offset) { _, e in let p = e.components(separatedBy: "|"); Text("\(p.count > 1 && p[1] == "inc" ? "＋" : "－") \(p.count > 3 ? p[3] : "")  \(p.count > 2 ? p[2] : "")") }
            .onDelete { o in var l = Store.list("fin"); let rev = Array(l.enumerated().reversed().prefix(15)); for i in o { l.remove(at: rev[i].offset) }; Store.setList("fin", l); entries = l } } }
        .navigationTitle("Finance").onAppear { entries = Store.list("fin") } }
    func add(_ t: String) { guard let a = Double(amt) else { return }; Store.push("fin", "\(Date().timeIntervalSince1970)|\(t)|\(cat.isEmpty ? (t == "inc" ? "income" : "other") : cat)|\(a)|"); amt = ""; cat = ""; entries = Store.list("fin") }
}

struct SMSView: UIViewControllerRepresentable {
    let to: [String]; let body: String; @Environment(\.dismiss) var dismiss
    func makeUIViewController(context: Context) -> MFMessageComposeViewController { let c = MFMessageComposeViewController(); c.recipients = to; c.body = body; c.messageComposeDelegate = context.coordinator; return c }
    func updateUIViewController(_ u: MFMessageComposeViewController, context: Context) {}
    func makeCoordinator() -> Co { Co(self) }
    final class Co: NSObject, MFMessageComposeViewControllerDelegate { let p: SMSView; init(_ p: SMSView) { self.p = p }; func messageComposeViewController(_ c: MFMessageComposeViewController, didFinishWith r: MessageComposeResult) { p.dismiss() } }
}
struct SafetyView: View {
    @EnvironmentObject var nav: Nav; @State var eid = Keychain.get("emergency_id"); @State var sms = false; @State var confirm = false; @State var dest = ""; @State var mins = "30"; @State var status = ""
    var contacts: [(String, String)] { Store.list("emergency").compactMap { let p = $0.components(separatedBy: "|"); return p.count >= 2 ? (p[0], p[1]) : nil } }
    var msg: String { "EMERGENCY: I need help. " + (LocationService.shared.last != nil ? "Location: \(LocationService.shared.link). " : "") + eid }
    var body: some View { NavigationStack { List {
        Section("Status") { Text("\(contacts.isEmpty ? "✗" : "✓") Emergency contacts: \(contacts.count)"); Text("\(eid.isEmpty ? "✗" : "✓") Emergency ID"); Text("\(LocationService.shared.last == nil ? "✗" : "✓") Location"); Text("\(Store.bool("privacy_lock") ? "✓" : "✗") Privacy lock"); Text("Alert log:\n" + Store.list("sec_log").suffix(5).joined(separator: "\n")).font(.caption2) }
        Section("Emergency") { Button("🚨 Danger – prepare alert (you confirm)") { confirm = true }.tint(.red); Button(Siren.shared.on ? "🔇 Siren off" : "🔊 Siren on") { Siren.shared.on ? Siren.shared.stop() : Siren.shared.start() }
            Button("📞 Fake call (simulated)") { nav.fake = true }; Text(status).font(.caption) }
        Section("Setup") { NavigationLink("Emergency contacts (name|number)") { ListScreen(key: "emergency", title: "Emergency contacts") }
            VStack(alignment: .leading) { Text("Emergency ID (encrypted in Keychain)").font(.caption); TextEditor(text: $eid).frame(height: 80).onChange(of: eid) { _, n in Keychain.set("emergency_id", n) } } }
        Section("Safe journey") { TextField("Destination", text: $dest); TextField("Minutes", text: $mins).keyboardType(.numberPad)
            Button("Start journey (I'll ask if you arrived)") { Notify.schedule((Double(mins) ?? 30) * 60 + 300, "Did you arrive at \(dest)? Open JARVIS to confirm.", id: "arrival"); status = "Journey started." }
            Button("I arrived") { Notify.cancel("arrival"); status = "Arrival confirmed." }
            Button("Safety check every 4h") { Notify.schedule(4 * 3600, "Safety check: are you OK?", repeats: true, id: "check"); status = "Checks on." }; Button("Stop safety check") { Notify.cancel("check") } }
        Section { Text("JARVIS never sends messages or calls secretly. The Messages app opens with a ready text and you press send. Delivery cannot be confirmed by the app.").font(.caption2) } }
        .navigationTitle("Safety")
        .confirmationDialog("Prepare emergency message with your location?", isPresented: $confirm, titleVisibility: .visible) { Button("Prepare message", role: .destructive) { Store.push("sec_log", "\(Date().formatted(date: .abbreviated, time: .shortened)) prepared: contacts=\(contacts.count), location=\(LocationService.shared.last != nil)", max: 50); if MFMessageComposeViewController.canSendText() && !contacts.isEmpty { sms = true } else { status = contacts.isEmpty ? "Add emergency contacts first." : "This device cannot send SMS." } }; Button("Cancel", role: .cancel) {} }
        .sheet(isPresented: $sms) { SMSView(to: contacts.map { $0.1 }, body: msg) } }
    }
}
struct FakeCallView: View {
    @EnvironmentObject var nav: Nav; @State var accepted = false
    var body: some View { VStack(spacing: 30) { Spacer(); Text(Store.str("fake_name", "Mom")).font(.largeTitle.bold()); Text(accepted ? "call in progress (simulated)" : "incoming call (simulated)").foregroundColor(.gray); Spacer()
        HStack(spacing: 60) { Button { nav.fake = false } label: { Image(systemName: "phone.down.fill").padding(24).background(Circle().fill(.red)) }; Button { accepted = true } label: { Image(systemName: "phone.fill").padding(24).background(Circle().fill(.green)) } }.foregroundColor(.white).font(.title); Spacer() }.frame(maxWidth: .infinity).background(Color.black.ignoresSafeArea()) }
}

struct FilesView: View {
    @State var show = false; @State var url: URL?; @State var out = ""; @State var busy = false
    var body: some View { List { Button("Choose a file (PDF, image, audio, text)") { show = true }; Text(url?.lastPathComponent ?? "No file").font(.caption)
        ForEach([("Summarize", "Summarize this file in 3-5 short sentences."), ("Key information", "Extract names, dates, numbers, amounts, action items."), ("OCR", "Extract all text exactly."), ("Translate", "Translate between Persian and English."), ("Name & category", "Suggest a short file name and one category. Format: name | category")], id: \.0) { a in Button(a.0) { go(a.1) }.disabled(url == nil || busy) }
        Text(out) }.navigationTitle("Files").fileImporter(isPresented: $show, allowedContentTypes: [.pdf, .image, .audio, .text, .json]) { if case .success(let u) = $0 { url = u } } }
    func go(_ task: String) { guard let u = url else { return }; busy = true; out = "…"
        Task { let ok = u.startAccessingSecurityScopedResource(); defer { if ok { u.stopAccessingSecurityScopedResource() } }
            let d = try? Data(contentsOf: u); let mime = UTType(filenameExtension: u.pathExtension)?.preferredMIMEType ?? "application/octet-stream"
            let r: String
            if let d = d, d.count < 12_000_000 { r = mime.hasPrefix("text") || mime.contains("json") ? await LLM.ask("\(task)\n\n\(String(decoding: d.prefix(30000), as: UTF8.self))", history: false, maxTokens: 450) : await LLM.ask(task, file: (mime, d), history: false, maxTokens: 450) } else { r = "Could not read the file (max 12 MB)." }
            Store.add("assistant", r); await MainActor.run { out = r; busy = false } } }
}
struct MediaView: View {
    @StateObject var rec = Recorder(); @State var files: [URL] = []; @State var out = ""
    var body: some View { List { Button(rec.recording ? "⏹ Stop recording" : "⏺ Start recording") { rec.toggle(); DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { files = list() } }
        ForEach(files, id: \.self) { f in VStack(alignment: .leading) { Text(f.lastPathComponent).font(.caption); HStack { Button("📝 Transcribe") { ai(f, "Transcribe this audio exactly, in its original language.") }.buttonStyle(.borderless); Button("🧾 Summarize") { ai(f, "Summarize in 3 short bullets.") }.buttonStyle(.borderless); ShareLink(item: f) } } }
            .onDelete { o in for i in o { try? FileManager.default.removeItem(at: files[i]) }; files = list() }; Text(out) }
        .navigationTitle("Recorder").onAppear { files = list() } }
    func list() -> [URL] { ((try? FileManager.default.contentsOfDirectory(at: Recorder.dir, includingPropertiesForKeys: nil)) ?? []).sorted { $0.lastPathComponent > $1.lastPathComponent } }
    func ai(_ f: URL, _ t: String) { out = "…"; Task { let r = await LLM.ask(t, file: ("audio/wav", (try? Data(contentsOf: f)) ?? Data()), history: false, maxTokens: 600); await MainActor.run { out = r } } }
}

enum Backup {
    static func key(_ pass: String, _ salt: Data) -> SymmetricKey { var k = [UInt8](repeating: 0, count: 32)
        _ = salt.withUnsafeBytes { s in CCKeyDerivationPBKDF(CCPBKDFAlgorithm(kCCPBKDF2), pass, pass.utf8.count, s.bindMemory(to: UInt8.self).baseAddress, salt.count, CCPseudoRandomAlgorithm(kCCPRFHmacAlgSHA256), 120_000, &k, 32) }; return SymmetricKey(data: k) }
    static func export(_ pass: String) -> Data? {
        var d: [String: String] = [:]; for (k, v) in Store.d.dictionaryRepresentation() where k.hasPrefix("l_") || ["user_name", "ai_name", "mode", "lang", "wake", "model"].contains(k) { if let a = v as? [String] { d[k] = (try? String(data: JSONSerialization.data(withJSONObject: a), encoding: .utf8)) ?? "[]" } else if let s = v as? String { d[k] = s } }
        guard let j = try? JSONSerialization.data(withJSONObject: d) else { return nil }; let salt = Data((0..<16).map { _ in UInt8.random(in: 0...255) })
        guard let box = try? AES.GCM.seal(j, using: key(pass, salt)), let c = box.combined else { return nil }; return (salt + c).base64EncodedData() }
    static func restore(_ data: Data, _ pass: String) -> Bool {
        guard let raw = Data(base64Encoded: data), raw.count > 28, let box = try? AES.GCM.SealedBox(combined: raw.dropFirst(16)), let j = try? AES.GCM.open(box, using: key(pass, raw.prefix(16))), let d = try? JSONSerialization.jsonObject(with: j) as? [String: String] else { return false }
        for (k, v) in d { if k.hasPrefix("l_"), let a = try? JSONSerialization.jsonObject(with: Data(v.utf8)) as? [String] { Store.d.set(a, forKey: k) } else { Store.d.set(v, forKey: k) } }; return true }
}
struct SettingsView: View {
    @State var key = ""; @State var bt = ""; @State var pass = ""; @State var exp = false; @State var imp = false; @State var msg = ""
    @AppStorage("backend") var backend = ""; @AppStorage("model") var model = "gemini-2.5-flash"; @AppStorage("lang") var lang = ""; @AppStorage("wake") var wake = "hey jarvis"
    @AppStorage("ha_url") var haUrl = ""; @State var haTok = ""; @AppStorage("user_name") var user = ""; @AppStorage("ai_name") var ai = "JARVIS"; @AppStorage("privacy_lock") var lock = false; @AppStorage("tts_rate") var rate = 50.0
    var body: some View { Form {
        Section("AI") { SecureField(Store.apiKey.isEmpty ? "Gemini API key" : "•••• saved (type to replace)", text: $key); TextField("Model", text: $model); TextField("Backend URL (optional)", text: $backend).textInputAutocapitalization(.never); SecureField("Backend token", text: $bt)
            Button("Save keys") { if !key.isEmpty { Store.apiKey = key; key = "" }; if !bt.isEmpty { Store.backendToken = bt; bt = "" }; msg = "Saved ✓" } }
        Section("Assistant") { TextField("Your name", text: $user); TextField("Assistant name", text: $ai); TextField("Language tag (fa-IR / en-US)", text: $lang).textInputAutocapitalization(.never); TextField("Wake phrase", text: $wake) }
        Section("Modules (turn off what you don't need)") { ForEach(["phone", "tools", "finance", "safety", "vision"], id: \.self) { m in Toggle(m, isOn: Binding(get: { Store.moduleOn(m) }, set: { Store.set("mod_" + m, $0) })) } }
        Section("Privacy & data") { Toggle("Privacy Lock (Face ID/passcode for Safety & Memory)", isOn: $lock)
            Button("Clear conversation history") { Store.setList("hist", []) }; Button("Clear memory") { Store.setList("memory", []) }
            Button("Encrypted backup") { exp = true }; Button("Restore backup") { imp = true }
            Button("Erase everything", role: .destructive) { Store.d.removePersistentDomain(forName: Bundle.main.bundleIdentifier!); Keychain.set("gemini", ""); Keychain.set("backend_token", ""); Keychain.set("emergency_id", "") }
            SecureField("Backup passphrase", text: $pass) }
        Section("Smart home (Home Assistant)") { TextField("Home Assistant URL (http://host:8123)", text: $haUrl).textInputAutocapitalization(.never); SecureField("Long-lived access token", text: $haTok)
            Button("Save token") { if !haTok.isEmpty { Keychain.set("ha_token", haTok); haTok = ""; msg = "Saved ✓" } } }
        Section("Sync with my backend (encrypted, manual)") {
            Button("Upload backup") { Task { if let d = Backup.export(pass) { msg = await Sync.put(d) ? "Uploaded ✓" : "Failed – check backend URL/token" } } }
            Button("Download & restore") { Task { if let d = await Sync.get(), Backup.restore(d, pass) { msg = "Restored ✓" } else { msg = "Failed – wrong passphrase or no backup" } } } }
        Section("Permissions") { Button("Open iOS Settings (mic, speech, camera, location, notifications)") { UIApplication.shared.open(URL(string: UIApplication.openSettingsURLString)!) } }
        Section("Recent errors") { Text(Store.list("errors").suffix(8).joined(separator: "\n")).font(.caption2) }
        Text(msg) }
        .navigationTitle("Settings")
        .fileExporter(isPresented: $exp, document: BackupDoc(data: Backup.export(pass) ?? Data()), contentType: .data, defaultFilename: "jarvis-backup.jbk") { _ in msg = "Backup saved" }
        .fileImporter(isPresented: $imp, allowedContentTypes: [.data]) { if case .success(let u) = $0, u.startAccessingSecurityScopedResource(), let d = try? Data(contentsOf: u) { msg = Backup.restore(d, pass) ? "Restored ✓" : "Wrong passphrase or file" } }
    }
}
struct BackupDoc: FileDocument { static var readableContentTypes: [UTType] = [.data]; var data: Data; init(data: Data) { self.data = data }; init(configuration: ReadConfiguration) throws { data = configuration.file.regularFileContents ?? Data() }; func fileWrapper(configuration: WriteConfiguration) -> FileWrapper { FileWrapper(regularFileWithContents: data) } }
struct MoreView: View {
    var body: some View { NavigationStack { List { NavigationLink("💳 Finance") { Guarded { FinanceView() } }; NavigationLink("📂 Files & documents") { FilesView() }; NavigationLink("🎧 Recorder") { MediaView() }; NavigationLink("⚙ Settings") { SettingsView() } }.navigationTitle("More") } }
}
