import Foundation
enum Logic {
    static func isPersian(_ s: String) -> Bool { s.unicodeScalars.contains { (0x0600...0x06FF).contains($0.value) } }
    static func digits(_ s: String) -> String { String(s.unicodeScalars.map { u -> Character in
        if (0x06F0...0x06F9).contains(u.value) { return Character(UnicodeScalar(u.value - 0x06F0 + 48)!) }
        if (0x0660...0x0669).contains(u.value) { return Character(UnicodeScalar(u.value - 0x0660 + 48)!) }; return Character(u) }) }
    private struct P { let s: [Character]; var i = 0
        mutating func peek() -> Character { i < s.count ? s[i] : "\0" }
        mutating func expr() throws -> Double { var v = try term(); while true { if peek() == "+" { i += 1; v += try term() } else if peek() == "-" { i += 1; v -= try term() } else { return v } } }
        mutating func term() throws -> Double { var v = try pow(); while true { if peek() == "*" { i += 1; v *= try pow() } else if peek() == "/" { i += 1; v /= try pow() } else { return v } } }
        mutating func pow() throws -> Double { let b = try unary(); if peek() == "^" { i += 1; return Foundation.pow(b, try pow()) }; return b }
        mutating func unary() throws -> Double { if peek() == "-" { i += 1; return -(try unary()) }; if peek() == "+" { i += 1; return try unary() }; return try atom() }
        mutating func atom() throws -> Double {
            if peek() == "(" { i += 1; let v = try expr(); if peek() == ")" { i += 1 } else { throw NSError(domain: "p", code: 1) }; return v }
            let st = i; while peek().isNumber || peek() == "." { i += 1 }; guard st != i, let d = Double(String(s[st..<i])) else { throw NSError(domain: "p", code: 2) }; return d } }
    static func calc(_ e: String) -> Double? {
        let c = Array(digits(e).lowercased().replacingOccurrences(of: "×", with: "*").replacingOccurrences(of: "÷", with: "/").replacingOccurrences(of: "x", with: "*").filter { $0 != " " && $0 != "," })
        var p = P(s: c); guard let v = try? p.expr(), p.i == c.count, v.isFinite else { return nil }; return v }
    static func extractExpr(_ t: String) -> String? {
        guard let re = try? NSRegularExpression(pattern: "[0-9+\\-*/x×÷^().\\s]{3,}") else { return nil }; let d = digits(t)
        return re.matches(in: d, range: NSRange(d.startIndex..., in: d)).compactMap { Range($0.range, in: d).map { String(d[$0]).trimmingCharacters(in: .whitespaces) } }
            .filter { $0.contains { $0.isNumber } && $0.contains { "+-*/x×÷^".contains($0) } }.max { $0.count < $1.count } }
    static func fmt(_ d: Double) -> String { d == d.rounded() && abs(d) < 1e12 ? String(Int64(d)) : String(format: "%.4f", d).replacingOccurrences(of: "0+$", with: "", options: .regularExpression) }
    static func millis(_ t: String) -> Double? {
        guard let re = try? NSRegularExpression(pattern: "(\\d+)\\s*(second|sec|ثانیه|minute|min|دقیقه|hour|ساعت)"), let m = re.firstMatch(in: digits(t).lowercased(), range: NSRange(digits(t).lowercased().startIndex..., in: digits(t).lowercased())) else { return nil }
        let s = digits(t).lowercased(); let n = Double(s[Range(m.range(at: 1), in: s)!])!; let u = String(s[Range(m.range(at: 2), in: s)!])
        return n * (["second", "sec", "ثانیه"].contains(u) ? 1000 : ["hour", "ساعت"].contains(u) ? 3_600_000 : 60_000) }
    static func wantsPlan(_ t: String) -> Bool { ["automate", "do the following", "plan and do", "do these steps", "کارهای زیر", "به ترتیب انجام بده"].contains { t.lowercased().contains($0) } }
    static func needsSearch(_ t: String) -> Bool { ["news", "latest", "price", "compare", "search", "who is", "today", "weather", "score", "اخبار", "قیمت", "جستجو", "آخرین", "امروز", "مقایسه"].contains { t.lowercased().contains($0) } }
}
