import Foundation
import UIKit

/// Gemini brain: direct (key in Keychain) or through your own backend. Token-light by default.
enum LLM {
    static func system(_ extra: String) -> String {
        var s = "You are \(Store.str("ai_name", "JARVIS")), a personal AI assistant on the user's phone. Reply in the language of the user's last message (Persian incl. colloquial, or English). Be concise: at most 2 short sentences unless asked for detail. You cannot control the phone yourself; never claim you performed an action. If ambiguous ask ONE short question. If information may be outdated, say so. "
        if !Store.str("user_name").isEmpty { s += "User's name: \(Store.str("user_name")). " }
        s += Modes.prompt
        let mem = Store.list("memory").suffix(10); if !mem.isEmpty { s += " Known about user: " + mem.joined(separator: "; ") + "." }
        s += " Now: \(Date().formatted(date: .complete, time: .shortened))."; if !extra.isEmpty { s += "\n" + extra }; return s
    }
    static func ask(_ text: String, images: [UIImage] = [], file: (String, Data)? = nil, history: Bool = true, search: Bool = false, extra: String = "", maxTokens: Int = 260) async -> String {
        let fa = text.unicodeScalars.contains { (0x0600...0x06FF).contains($0.value) }
        let backend = Store.str("backend").trimmingCharacters(in: .whitespaces).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        guard !Store.apiKey.isEmpty || !backend.isEmpty else { return fa ? "ابتدا کلید Gemini را در تنظیمات وارد کنید." : "Please add your Gemini API key in Settings." }
        var contents: [[String: Any]] = []; var last = "model"
        if history { for (r, t) in Store.recent(6) { let role = r == "user" ? "user" : "model"; if role != last && !(contents.isEmpty && role == "model") { contents.append(["role": role, "parts": [["text": t]]]); last = role } } }
        if last == "user" { contents.removeLast() }
        var parts: [[String: Any]] = images.compactMap { $0.scaled(1024).jpegData(compressionQuality: 0.75).map { ["inline_data": ["mime_type": "image/jpeg", "data": $0.base64EncodedString()]] } }
        if let f = file { parts.append(["inline_data": ["mime_type": f.0, "data": f.1.base64EncodedString()]]) }
        parts.append(["text": text]); contents.append(["role": "user", "parts": parts])
        var body: [String: Any] = ["systemInstruction": ["parts": [["text": system(extra)]]], "contents": contents, "generationConfig": ["maxOutputTokens": maxTokens, "temperature": 0.7]]
        if search { body["tools"] = [["google_search": [String: Any]()]] }
        let model = Store.str("model", "gemini-2.5-flash")
        guard let url = URL(string: backend.isEmpty ? "https://generativelanguage.googleapis.com/v1beta/models/\(model):generateContent" : "\(backend)/gemini?model=\(model)") else { return "Bad backend URL." }
        var req = URLRequest(url: url); req.httpMethod = "POST"; req.timeoutInterval = 60; req.setValue("application/json", forHTTPHeaderField: "content-type")
        if backend.isEmpty { req.setValue(Store.apiKey, forHTTPHeaderField: "x-goog-api-key") } else { req.setValue(Store.backendToken, forHTTPHeaderField: "x-app-token") }
        req.httpBody = try? JSONSerialization.data(withJSONObject: body)
        do {
            let (data, resp) = try await URLSession.shared.data(for: req); let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
            guard code == 200, let j = try JSONSerialization.jsonObject(with: data) as? [String: Any] else { Store.logError("llm", "HTTP \(code)"); return (fa ? "خطای سرویس هوش مصنوعی: " : "AI service error: ") + "\(code)" }
            guard let cand = (j["candidates"] as? [[String: Any]])?.first, let ps = (cand["content"] as? [String: Any])?["parts"] as? [[String: Any]] else { return fa ? "پاسخی دریافت نشد." : "No answer (it may have been blocked)." }
            var out = ps.compactMap { $0["text"] as? String }.joined().trimmingCharacters(in: .whitespacesAndNewlines)
            if search, let ch = (cand["groundingMetadata"] as? [String: Any])?["groundingChunks"] as? [[String: Any]] {
                let src = ch.prefix(3).compactMap { ($0["web"] as? [String: Any]).map { "\($0["title"] as? String ?? "") \($0["uri"] as? String ?? "")" } }
                if !src.isEmpty { out += "\n\n" + (fa ? "منابع:" : "Sources:") + "\n" + src.joined(separator: "\n") } }
            return out
        } catch { Store.logError("llm", error); return fa ? "اتصال به هوش مصنوعی ممکن نشد." : "Could not reach the AI service." }
    }
}
extension UIImage {
    func scaled(_ maxSide: CGFloat) -> UIImage { let s = maxSide / max(size.width, size.height); if s >= 1 { return self }
        let n = CGSize(width: size.width * s, height: size.height * s); return UIGraphicsImageRenderer(size: n).image { _ in draw(in: CGRect(origin: .zero, size: n)) } }
}
