import Foundation
import Security

/// Secrets live in the Keychain; everything else in UserDefaults.
enum Keychain {
    static func set(_ k: String, _ v: String) {
        let q: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrAccount as String: k]
        SecItemDelete(q as CFDictionary); if v.isEmpty { return }
        var a = q; a[kSecValueData as String] = Data(v.utf8); a[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly; SecItemAdd(a as CFDictionary, nil)
    }
    static func get(_ k: String) -> String {
        let q: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrAccount as String: k, kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        var r: AnyObject?; guard SecItemCopyMatching(q as CFDictionary, &r) == errSecSuccess, let d = r as? Data else { return "" }; return String(decoding: d, as: UTF8.self)
    }
}

enum Store {
    static let d = UserDefaults.standard
    static func str(_ k: String, _ def: String = "") -> String { d.string(forKey: k) ?? def }
    static func set(_ k: String, _ v: Any?) { d.set(v, forKey: k) }
    static func bool(_ k: String, _ def: Bool = false) -> Bool { d.object(forKey: k) as? Bool ?? def }
    static func int(_ k: String, _ def: Int = 0) -> Int { d.object(forKey: k) as? Int ?? def }
    static func list(_ k: String) -> [String] { d.stringArray(forKey: "l_" + k) ?? [] }
    static func setList(_ k: String, _ v: [String]) { d.set(v, forKey: "l_" + k) }
    static func push(_ k: String, _ v: String, max: Int = 500) { setList(k, Array((list(k) + [v]).suffix(max))) }
    static func moduleOn(_ id: String) -> Bool { bool("mod_" + id, true) }
    static var apiKey: String { get { Keychain.get("gemini") } set { Keychain.set("gemini", newValue.trimmingCharacters(in: .whitespaces)) } }
    static var backendToken: String { get { Keychain.get("backend_token") } set { Keychain.set("backend_token", newValue) } }
    static var lang: String { get { str("lang", Locale.current.identifier) } set { set("lang", newValue.isEmpty ? Locale.current.identifier : newValue) } }
    static var notes: [String] { get { list("notes") } set { setList("notes", newValue) } }
    static var gameStart: Double { get { d.double(forKey: "gs") } set { d.set(newValue, forKey: "gs") } }
    static func add(_ r: String, _ t: String) { push("hist", "\(r)\u{1}\(t)", max: 60) }
    static func recent(_ n: Int = 6) -> [(String, String)] { list("hist").suffix(n).map { e in let p = e.components(separatedBy: "\u{1}"); return (p[0], p.dropFirst().joined(separator: "\u{1}")) } }
    static var transcript: String { recent(60).map { ($0.0 == "user" ? "▸ " : "◆ ") + $0.1 }.joined(separator: "\n\n") }
    static func logError(_ tag: String, _ e: Any) { push("errors", "\(Date().formatted(date: .abbreviated, time: .shortened)) \(tag): \(e)", max: 30) }
}

/// Smart modes (change assistant behaviour).
enum Modes {
    static let all: [(id: String, title: String, fa: String, prompt: String)] = [
        ("normal", "Normal", "عادی", ""), ("driving", "Driving", "رانندگی", "Driving mode: answer in ONE very short sentence."),
        ("study", "Study", "مطالعه", "Study mode: patient tutor, step by step but brief."), ("gaming", "Gaming", "بازی", "Gaming mode: replies under 12 words."),
        ("focus", "Focus", "تمرکز", "Focus mode: minimal, no small talk."), ("sleep", "Sleep", "خواب", "Sleep mode: calm and very brief."),
        ("training", "Training", "تمرین", "Training mode: energetic brief coach."), ("emergency", "Emergency", "اضطراری", "Emergency mode: calm, direct, safety-first."),
        ("work", "Work", "کار", "Work mode: professional and efficient."), ("cinema", "Cinema", "سینما", "Cinema mode: whisper-brief."),
        ("meeting", "Meeting", "جلسه", "Meeting mode: only essential short replies."), ("travel", "Travel", "سفر", "Travel mode: directions, translation, local tips."),
        ("custom", "Custom", "سفارشی", "")]
    static var current: String { Store.str("mode", "normal") }
    static var prompt: String { current == "custom" ? Store.str("custom_prompt") : (all.first { $0.id == current }?.prompt ?? "") }
}
