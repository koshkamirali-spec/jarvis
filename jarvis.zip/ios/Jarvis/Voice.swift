import Foundation
import Speech
import AVFoundation
/// Hands-free conversation. iOS does NOT allow always-on wake word when the app is closed: this runs while
/// the audio session is active (UIBackgroundModes=audio, started by the user, incl. Shortcut/Action Button/Widget).
/// Wake: "Hey Jarvis" · "Stop Jarvis" pauses · "Continue Jarvis" resumes · "Stop listening" ends.
final class VoiceEngine: NSObject, ObservableObject, AVSpeechSynthesizerDelegate {
    enum S { case off, wake, awake, paused }
    @Published var state: S = .off
    @Published var transcript = Store.transcript
    private let engine = AVAudioEngine(); private let synth = AVSpeechSynthesizer()
    private var recognizer: SFSpeechRecognizer?; private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?; private var silence: Timer?; private var speaking = false
    private var lastActive = Date(); private var started = Date(); private var tapInstalled = false

    func start() {
        SFSpeechRecognizer.requestAuthorization { st in
            AVAudioSession.sharedInstance().requestRecordPermission { ok in
                DispatchQueue.main.async { if st == .authorized && ok { self.begin() } } } }
    }
    func stop() { state = .off; silence?.invalidate(); task?.cancel(); engine.stop(); if tapInstalled { engine.inputNode.removeTap(onBus: 0); tapInstalled = false }; synth.stopSpeaking(at: .immediate); try? AVAudioSession.sharedInstance().setActive(false) }
    private func begin() {
        guard state == .off else { return }
        recognizer = SFSpeechRecognizer(locale: Locale(identifier: Store.lang)); synth.delegate = self
        let s = AVAudioSession.sharedInstance()
        try? s.setCategory(.playAndRecord, mode: .default, options: [.defaultToSpeaker, .allowBluetooth, .mixWithOthers])
        try? s.setActive(true)
        let node = engine.inputNode
        node.installTap(onBus: 0, bufferSize: 1024, format: node.outputFormat(forBus: 0)) { [weak self] b, _ in self?.request?.append(b) }
        tapInstalled = true; engine.prepare(); try? engine.start()
        state = .wake; started = Date(); lastActive = Date(); listen()
    }
    private func listen() {
        guard state != .off, !speaking else { return }
        if state == .wake, Date().timeIntervalSince(max(started, lastActive)) > 30 * 60 { say("Listening stopped to save battery."); stop(); return }
        if state == .awake, Date().timeIntervalSince(lastActive) > 60 { state = .wake }
        task?.cancel(); request = SFSpeechAudioBufferRecognitionRequest(); request?.shouldReportPartialResults = true
        if recognizer?.supportsOnDeviceRecognition == true { request?.requiresOnDeviceRecognition = true }
        var last = ""
        task = recognizer?.recognitionTask(with: request!) { [weak self] r, e in
            guard let self = self else { return }
            if let r = r { last = r.bestTranscription.formattedString
                DispatchQueue.main.async { self.silence?.invalidate(); self.silence = Timer.scheduledTimer(withTimeInterval: 1.3, repeats: false) { _ in
                    let t = last; self.request?.endAudio(); self.task?.cancel(); if !t.isEmpty { self.handle(t) }; self.listen() } } }
            if e != nil && last.isEmpty { DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { self.listen() } }
        }
        if recognizer?.isAvailable != true { DispatchQueue.main.asyncAfter(deadline: .now() + 2) { self.listen() } }
    }
    private func has(_ t: String, _ k: String...) -> Bool { k.contains { t.contains($0) } }
    private func handle(_ text: String) {
        let t = text.lowercased()
        if state == .paused { if has(t, "continue jarvis", "ادامه جارویس") { state = .awake; lastActive = Date(); say("Back.") }; return }
        if has(t, "stop listening", "شنود را خاموش کن") { say("Listening off."); stop(); return }
        if has(t, "stop jarvis", "توقف جارویس") { synth.stopSpeaking(at: .immediate); state = .paused; say("Paused."); return }
        var cmd = text
        if state == .wake {
            guard let w = [Store.str("wake", "hey jarvis").lowercased(), "hey jarvis", "هی جارویس"].first(where: { t.contains($0) }) else { return }
            cmd = t.components(separatedBy: w).last?.trimmingCharacters(in: .whitespaces) ?? ""; state = .awake; lastActive = Date()
            if cmd.isEmpty { say("Yes?"); return } }
        lastActive = Date(); Store.add("user", cmd); speaking = true; task?.cancel()
        Task { let r = await Brain.process(cmd); await MainActor.run { self.speaking = false; self.reply(r) } }
    }
    private func reply(_ r: String) { Store.add("assistant", r); transcript = Store.transcript; say(r) }
    private func say(_ s: String) { speaking = true; task?.cancel(); let u = AVSpeechUtterance(string: s); u.voice = AVSpeechSynthesisVoice(language: Store.lang); synth.speak(u) }
    func speechSynthesizer(_ s: AVSpeechSynthesizer, didFinish u: AVSpeechUtterance) { speaking = false; lastActive = Date(); listen() }
}
