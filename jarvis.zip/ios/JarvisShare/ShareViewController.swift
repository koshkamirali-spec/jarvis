import UIKit
import UniformTypeIdentifiers
/// Screen Intelligence on iOS: Share a screenshot / text / URL -> short spoken+written answer.
/// Add as a Share Extension target. Copy LLM.swift + Store.swift (use an App Group for the API key).
class ShareViewController: UIViewController {
    let label = UILabel()
    override func viewDidLoad() {
        super.viewDidLoad(); view.backgroundColor = .systemBackground
        label.numberOfLines = 0; label.frame = view.bounds.insetBy(dx: 20, dy: 60); label.text = "..."; view.addSubview(label)
        guard let p = (extensionContext?.inputItems.first as? NSExtensionItem)?.attachments?.first else { return }
        let q = "Explain or summarize this briefly; translate if foreign; extract key info."
        if p.hasItemConformingToTypeIdentifier(UTType.image.identifier) {
            p.loadItem(forTypeIdentifier: UTType.image.identifier) { item, _ in
                var img: UIImage?; if let u = item as? URL { img = UIImage(contentsOfFile: u.path) } else if let i = item as? UIImage { img = i }
                Task { let r = await LLM.ask(q, images: img.map { [$0] } ?? [], history: false); await MainActor.run { self.label.text = r } } }
        } else {
            let t = p.hasItemConformingToTypeIdentifier(UTType.url.identifier) ? UTType.url.identifier : UTType.text.identifier
            p.loadItem(forTypeIdentifier: t) { item, _ in
                let s = (item as? URL)?.absoluteString ?? (item as? String) ?? ""
                Task { let r = await LLM.ask(q + "\n" + s, history: false); await MainActor.run { self.label.text = r } } }
        }
    }
}
