# JARVIS for iOS (SwiftUI, iOS 17+) - no floating UI (iOS has none anyway)
1. Xcode > New App "Jarvis" (SwiftUI). Replace sources with ios/Jarvis/*.swift.
2. Info.plist: UIBackgroundModes = [audio]; NSMicrophoneUsageDescription; NSSpeechRecognitionUsageDescription; NSAppleMusicUsageDescription; URL scheme "jarvis".
3. Add a Widget Extension target -> JarvisWidget.swift. Add a Share Extension target -> ShareViewController.swift (+ LLM.swift, Store.swift; share the API key via an App Group).
4. Siri/Shortcuts/Action Button: appear automatically (App Intents). Say "Hey Siri, Ask Jarvis".
Apple limits: no always-on "Hey Jarvis" when the app is closed. Voice runs while the audio session is active (start it from the app, widget, Shortcut or Action Button; Background Audio keeps it alive). Opening other apps / controlling games by voice is not possible on iOS except via Shortcuts.
