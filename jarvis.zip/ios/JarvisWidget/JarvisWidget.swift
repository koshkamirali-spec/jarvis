import WidgetKit
import SwiftUI
struct E: TimelineEntry { let date = Date() }
struct P: TimelineProvider {
    func placeholder(in c: Context) -> E { E() }
    func getSnapshot(in c: Context, completion: @escaping (E) -> Void) { completion(E()) }
    func getTimeline(in c: Context, completion: @escaping (Timeline<E>) -> Void) { completion(Timeline(entries: [E()], policy: .never)) }
}
struct WView: View { var body: some View { VStack { Image(systemName: "mic.fill").font(.title); Text("JARVIS") }.widgetURL(URL(string: "jarvis://listen")) } }
@main struct JarvisWidget: Widget {
    var body: some WidgetConfiguration { StaticConfiguration(kind: "jarvis", provider: P()) { _ in WView().containerBackground(.fill.tertiary, for: .widget) }.supportedFamilies([.systemSmall, .accessoryCircular]) }
}
